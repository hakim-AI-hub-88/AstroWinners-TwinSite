# TwinSite · Engineering handoff (locked architecture)

**Date:** 15 November 2026  
**Project:** TwinSite (formerly ARES), NASA Space Apps planetary analog discovery  
**Decisions:** $0 paid AI inference; provider-specific informed consent for uploaded-content AI; **Simple Analysis is default, not just backup**; 13 specified agent roles plus a deterministic orchestrator.

## Start here: three reports

1. [`reports/01_AI_API_Routing.pdf`](reports/01_AI_API_Routing.pdf) — provider audit, API routing, shared quotas, free-only fallback, demo reserve, upload consent.
2. [`reports/02_Agent_Architecture.pdf`](reports/02_Agent_Architecture.pdf) — all 13 A01-A13 roles, P00-P90 DAG, task IO, deterministic/AI boundaries, audit and release flows.
3. [`reports/03_Simple_Analysis_Engine.pdf`](reports/03_Simple_Analysis_Engine.pdf) — no-AI data processing, feature calculations, QA, scoring, missingness, portfolios, robustness and evidence reports.

Editable Markdown/HTML sources sit beside the PDFs. Do not treat the HTML as a working application; it exists for document regeneration.

## Supporting deliverables

- `configs/provider_registry.yaml`: providers **disabled by default**, model IDs unverified, free-only policy; uses credential variable names without values.
- `configs/quota_policy.json`: quota buckets, demo reserve, bounded AI attempts and fallback.
- `configs/agent_routes.csv`: mapping of A01-A13 to scientific execution and optional inference.
- `configs/env.example`: environment variable names **only**; never commit real keys.
- `contracts/*.schema.json`: structured agent outcomes, optional inference requests, user consent and data-quality verdicts.
- `examples/simple_analysis_reference.py`: **runnable synthetic** mathematical reference for scores, missingness and portfolios, not a NASA integration.
- `validation/test_simple_analysis.py`: tests of reference behavior.
- `validation/go_no_go_checklist.md`: operational and scientific acceptance checklist.
- `diagrams/*.svg` / `.dot`: editable visual workflow diagrams.
- `historical_data_reference/`: source mapping and locked scientific data architecture created before the TwinSite rename. Names may still say ARES; the content remains a scientific reference, not proof of current download success.

## Priority order for Claude / Codex (do not invert)

1. Integrate source-product adapters for a **bounded real Earth DEM + Mars MOLA or lunar LOLA** region, and validate coordinates, units and source provenance.
2. Implement immutable raw assets, typed observations, product-specific QA, repair rules and quarantine.
3. Implement **Simple Analysis** numerical scoring, strict/exploratory missing-data gates, operation eligibility and small-pool portfolio optimization.
4. Wire FastAPI → persistent job worker → report JSON; expose progress/events and safe read-only API views.
5. Build TwinSite frontend mission, maps, analysis, portfolios, activity, reports and public data explorer. **No login/RBAC/settings pages.**
6. Run the full workflow with **all AI providers disabled**; preserve a reproducible real-data demo snapshot.
7. Only then activate optional external AI routes after free-tier, quota-group, model-canary and upload-consent testing.

## Architecture invariants

- No scientific measurement, calibrated confidence, cost or permit may originate solely from an LLM response.
- User-entered estimates are labelled `USER_SCENARIO` and never treated as validated source observations.
- Every feature/candidate/portfolio claim must map to a source, method, unit, scale, time and quality verdict.
- Unknown mandatory evidence blocks strict analysis; exploratory mode reports explicit coverage and mathematical missingness bounds.
- AI availability must not alter scores, candidate eligibility or portfolio membership.
- No paid AI requests, no key rotation within a shared provider quota group to bypass limits, no undocumented subscription CLI use as backend API.
- Private uploaded content requires **affirmative provider- and purpose-specific consent**, with a local non-AI path if refused.
- No general-purpose direct SQL, secret keys or private upload files are exposed via the public data browser.

## Known unverified items (do not invent completion)

Actual generation success of individual VESPER credentials, free-tier model entitlement, remaining quotas, billing configuration, provider project/org grouping, API server host capacity, authenticated NASA granule download, real-data cross-planet validation and actual mission recommendations. Claude's 2026-11-14 inventory used **non-generative** API probes; the synthetic code test is not NASA validation. See each report for exact reasons.

## Local reference self-test

```bash
python -m unittest discover -s validation -v
python examples/simple_analysis_reference.py
```

The tests use explicitly synthetic data. Never present their scores as measurements.

## Decisions to preserve

- **13 roles**, not 13 permanent LLM calls; A06 may fan out into bounded task instances across domains.
- **Process auditor A08 + evidence reviewer A09 + portfolio reviewer A10**, then judge A11, targeted recheck A12, report writer A13.
- The user's original second swarm pass is preserved as an optional independently prompted check, not a required duplicate computation.
- The UI needs no authentication pages; sensitive session-scoped files still need backend access controls and retention.
- Use real source granules and QA before demonstrating a scientific outcome, and show methodology on every report.

## Source priority and disagreement policy

**For the implementation design:** these three latest TwinSite reports and their contracts take precedence over historical ARES planning drafts, especially on default AI behavior, quota handling and user upload privacy. **For the scientific source mapping:** the locked data architecture PDF and source matrix remain the baseline, with each provider/product independently validated during implementation. If a diagram, sample file or model label disagrees with an actual source record or provider documentation, correct the implementation and log the discrepancy; do not guess.
