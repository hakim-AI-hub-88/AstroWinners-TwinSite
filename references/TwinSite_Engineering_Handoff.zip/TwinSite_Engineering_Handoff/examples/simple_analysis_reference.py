"""TwinSite no-AI numerical reference, not a NASA data connector.

All example observations are synthetic and must not be presented as scientific
measurements. Only use with already validated, provenance-backed measurements.
"""
from __future__ import annotations
from dataclasses import dataclass
from itertools import combinations
from typing import Optional


@dataclass(frozen=True)
class Requirement:
    feature: str
    weight: float
    target: float
    tolerance: float
    required: bool = True


@dataclass(frozen=True)
class Observation:
    value: float
    unit: str
    evidence_id: str
    status: str = "valid"


@dataclass(frozen=True)
class Site:
    site_id: str
    features: dict[str, Observation]
    # Cost provided by user or evidence-based rate record; None is UNKNOWN.
    cost: Optional[float] = None
    access: str = "unknown"  # pass | fail | unknown


def feature_similarity(value: float, target: float, tolerance: float) -> float:
    """Simple scalar heuristic; not a probability or a valid spectral metric."""
    if tolerance <= 0:
        raise ValueError("tolerance must be strictly positive")
    return max(0.0, 1.0 - abs(value - target) / tolerance)


def score_site(site: Site, requirements: list[Requirement], *, strict: bool = True,
               min_coverage: float = 0.7) -> dict:
    if not requirements or abs(sum(r.weight for r in requirements) - 1.0) > 1e-8:
        raise ValueError("requirement weights must sum to 1")
    if any(r.weight < 0 or r.tolerance <= 0 for r in requirements):
        raise ValueError("nonnegative weights and positive tolerances required")
    observed, missing = {}, []
    coverage, lower = 0.0, 0.0
    for r in requirements:
        obs = site.features.get(r.feature)
        if obs is None or obs.status != "valid":
            missing.append(r.feature)
            continue
        if not obs.evidence_id:
            raise ValueError(f"missing source evidence for {site.site_id}/{r.feature}")
        s = feature_similarity(obs.value, r.target, r.tolerance)
        observed[r.feature] = {"similarity": s, "evidence_id": obs.evidence_id,
                               "contribution": s * r.weight}
        coverage += r.weight
        lower += s * r.weight
    required_missing = [r.feature for r in requirements if r.required and r.feature in missing]
    eligible = not required_missing and coverage >= min_coverage
    if site.access == "fail":
        eligible = False
    # Unknown access never becomes pass. Strict operational recommendation needs verification.
    if strict and site.access != "pass":
        eligible = False
    return {
        "site_id": site.site_id, "eligible": eligible,
        "missing": missing, "required_missing": required_missing,
        "coverage": coverage, "observed_score": lower / coverage if coverage else None,
        "lower": lower, "upper": min(1.0, lower + 1.0 - coverage),
        "feature_evidence": observed, "cost": site.cost, "access": site.access,
        "confidence_type": "missing-evidence bounds; NOT a calibrated probability",
    }


def portfolios(sites: list[Site], requirements: list[Requirement],
               *, max_sites: int = 2, budget: Optional[float] = None,
               strict: bool = True) -> list[dict]:
    assessed = [(s, score_site(s, requirements, strict=strict)) for s in sites]
    valid = [(s, r) for s, r in assessed if r["eligible"]]
    options = []
    for k in range(1, min(max_sites, len(valid)) + 1):
        for group in combinations(valid, k):
            members = [site.site_id for site, _ in group]
            # Portfolios cover each requirement if at least one site has a strong valid measurement.
            coverage_value = sum(
                r.weight * max((out["feature_evidence"].get(r.feature, {}).get("similarity", 0.0)
                                for _, out in group), default=0.0)
                for r in requirements
            )
            costs = [site.cost for site, _ in group]
            total_cost = sum(costs) if all(c is not None for c in costs) else None
            if budget is not None and (total_cost is None or total_cost > budget):
                continue  # Cannot claim known feasibility when cost is unknown.
            options.append({"sites": members, "science_coverage": coverage_value,
                            "known_cost": total_cost,
                            "cost_status": "known" if total_cost is not None else "unknown",
                            "eligibility": "scientific+access pass"})
    return sorted(options, key=lambda x: (-x["science_coverage"], len(x["sites"]), x["sites"]))


if __name__ == "__main__":
    required = [Requirement("slope_p90", .6, 12.0, 10.0), Requirement("roughness", .4, 0.6, 0.5)]
    earth = [
        Site("SYNTHETIC_A", {"slope_p90": Observation(10.0, "degree", "synthetic:e1"),
                              "roughness": Observation(0.7, "m", "synthetic:e2")}, cost=120, access="pass"),
        Site("SYNTHETIC_B", {"slope_p90": Observation(18.0, "degree", "synthetic:e3"),
                              "roughness": Observation(0.55, "m", "synthetic:e4")}, cost=70, access="pass"),
    ]
    print("Synthetic reference scores", [score_site(s, required) for s in earth])
    print("Synthetic portfolios", portfolios(earth, required, max_sites=2, budget=200))
