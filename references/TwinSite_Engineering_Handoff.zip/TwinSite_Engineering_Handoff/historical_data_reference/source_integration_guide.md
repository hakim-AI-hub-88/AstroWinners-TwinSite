# ARES Source Integration and QA Guide

Updated 2026-11-14. These are official product documentation access routes, not assertions that ARES has fetched all granules.

## Status
- P0: essential to working MVP; P1: reasonable extension; P2: specialized/deferred.
- Source documented != download/auth/coverage validated.
- Any feature without source data remains null.

## Product catalog
### CMR: Common Metadata Repository (CMR) (P0)
- Agency: NASA; body: Earth; type: Catalog metadata
- Official documentation: https://cmr.earthdata.nasa.gov/search/site/docs/search/api.html
- Features: Collection/granule discovery; coverage; versions; download links
- How to access: Public REST collection/granule search; granule downloads may require Earthdata Login.
- Formats: JSON/UMM JSON, XML, STAC
- Procedure: Query collections by short_name/version; query granules with bounding_box and temporal; paginate; inspect distribution URLs and headers.
- Known or plausible issues: Metadata can describe a collection without accessible local granules; partial timeout responses, pagination gaps, provider auth; metadata may omit quality descriptors.
- Treatment: Require matched collection concept ID and version; persist request, page/cursor and hit count; detect timeout/429; validate each download URL and checksum.

### SRTM: SRTMGL1 V003 elevation (P0)
- Agency: NASA/USGS; body: Earth; type: Earth DEM
- Official documentation: https://www.earthdata.nasa.gov/s3fs-public/2025-05/SRTM_Quick_Guide.pdf
- Features: Elevation; derived slope, roughness, local relief
- How to access: Discover through Earthdata CMR / LP DAAC; Earthdata Login may be required for download.
- Formats: HGT/GeoTIFF-equivalent raster, ancillary grids
- Procedure: Select 1-arc-second DEM cells intersecting Earth AOI; load elevations with rasterio; apply geoid/vertical reference and projected metric distance for slope.
- Known or plausible issues: Near-global, not universal, acquisition latitude limits; voids, water/vegetation/building effects; SRTM quick guide documents voids returned where licensed-fill data were removed.
- Treatment: Reject void/no-data, preserve masks, use official void-filling metadata, never treat roof/canopy heights as rock surface; require AOI overlap and coverage fraction.

### POWER: POWER daily point meteorology (P0)
- Agency: NASA; body: Earth; type: Time series
- Official documentation: https://power.larc.nasa.gov/docs/services/api/temporal/daily/
- Features: T2M, PS, WS10M, precipitation, solar radiation; seasonal and historical windows
- How to access: Public documented REST daily point endpoint; no secret for basic point request.
- Formats: JSON, CSV, ASCII, NetCDF
- Procedure: Request point, community, date range and explicit parameters; map daily fields to values with units and source metadata; cache identical grid-cell queries.
- Known or plausible issues: Coarse source grid, mixed original grid supports, temporal coverage differences, fill codes; rate limits; max 20 params for point requests and 1 param for regional.
- Treatment: Inspect parameter metadata, mask fill values, enforce date support, distinguish air temperature from LST, deduplicate equivalent grid cells, track UTC or local solar time.

### MOD11: MOD11A2.061 LST 8-day (P0)
- Agency: NASA LP DAAC; body: Earth; type: Thermal raster time series
- Official documentation: https://lpdaac.usgs.gov/documents/715/MOD11_User_Guide_V61.pdf
- Features: LST_Day_1km, LST_Night_1km, QC_Day, QC_Night, day/night thermal patterns
- How to access: Earthdata CMR / LP DAAC download; Earthdata Login may be required.
- Formats: HDF-EOS raster via Earthdata
- Procedure: Read LST bands and QC bits; apply product scale factor 0.02 Kelvin per stored unit; composite regional daytime and nighttime summaries by actual observation date.
- Known or plausible issues: Cloud gaps, emissivity effects, QA masks, 8-day aggregation, approximate 1-km sampling; MOD11A2 composites are not filtered by daily QA before averaging.
- Treatment: Decode QC mandatory/data/emissivity/LST error bits separately; discard invalid, count valid pixels and coverage; convert K to C only for presentation.

### MOLA: MGS MOLA MEGDR PDS4 (P0)
- Agency: NASA PDS; body: Mars; type: Mars gridded DEM
- Official documentation: https://pds-geosciences.wustl.edu/missions/mgs/megdr.html
- Features: Topographic height, radius, areoid (some grids), observation-count layer
- How to access: Public PDS Geosciences Node maintained PDS4 archive, no runtime key indicated.
- Formats: IMG binary + PDS4 XML labels + ENVI HDR
- Procedure: Choose MEG128 or other grid matching target AOI; download IMG plus XML/HDR; parse sample type, byte order, scaling, map projection and 0-360 longitude conventions.
- Known or plausible issues: Raster spacing is not native shot footprint; interpolated cells, regional count variation, confusion between planetary radius and relative topography, IAU coordinate version.
- Treatment: Prefer final PDS4 bundle and topography component; read observation count; label low-support cells; preserve datum and IAU coordinates; never convert Mars latitude by Earth EPSG assumptions.

### LOLA: LRO LOLA GDR topography (P0)
- Agency: NASA PDS; body: Moon; type: Lunar DEM
- Official documentation: https://pds-geosciences.wustl.edu/missions/lro/lola_faq.htm
- Features: Gridded lunar elevation; relief and slope at supported physical scale
- How to access: Public PDS LRO LOLA archive; use GDR for pre-gridded elevation.
- Formats: PDS IMG, JP2, detached labels
- Procedure: Select an available GDR and polar projection appropriate for a selected Moon AOI; read the PDS label / JP2 auxiliary metadata; extract valid grid cells.
- Known or plausible issues: Pole projection and longitude conventions; data density varies by terrain; DEM pixels are not independent laser shots; large local slopes cannot be resolved everywhere.
- Treatment: Use native lunar geodesy, track valid-cell fraction and nominal grid spacing; do not apply Earth Web Mercator to polar lunar calculations.

### GIBS: Global Imagery Browse Services (P0)
- Agency: NASA; body: Earth; type: Visualization service
- Official documentation: https://nasa-gibs.github.io/gibs-api-docs/access-basics/
- Features: Time-aware optical/browse maps and satellite context
- How to access: Public WMTS/WMS services; capabilities query before selecting layers.
- Formats: WMTS/WMS PNG/JPEG tiles
- Procedure: Read GetCapabilities for available layer IDs, format, projection, tile-matrix set and date; request tiles for map overlay.
- Known or plausible issues: Browse pixels are visual encodings, often false color; dates/layers may be unavailable; tile projection differs.
- Treatment: Do not use rendered colors as calibrated sensor measurements; verify layer dates and license/attribution; show date and resolution.

### DIVINER: LRO Diviner RDR / thermal products (P1)
- Agency: NASA PDS; body: Moon; type: Lunar thermal observations
- Official documentation: https://www.diviner.ucla.edu/data
- Features: Lunar thermal radiance and derived surface temperature
- How to access: Public LRO Diviner archival products; choose reduced or derived data deliberately.
- Formats: PDS RDR/derived files + labels
- Procedure: Choose documented derived thermal product matching target area/time-of-day; parse flags and solar geometry; aggregate to lunar local-time bins.
- Known or plausible issues: Thermal retrieval depends on local solar time, channel, incidence, geometry; raw radiances are not temperatures.
- Treatment: Use published temperature derivation or validated derived product; retain quality/activity flags and bin by appropriate lunar local time.

### HLS: HLS L30/S30 v2.0 (P1)
- Agency: NASA/USGS; body: Earth; type: Harmonized optical reflectance
- Official documentation: https://hls.gsfc.nasa.gov/data-products/
- Features: Reflectance, bare ground / vegetation indices, surface change
- How to access: Earthdata Login generally required for archived cloud product downloads.
- Formats: Cloud Optimized GeoTIFF bands + Fmask
- Procedure: Search L30/S30 tiles and dates; fetch needed COG bands + Fmask; compute NDVI or bare-ground proxy using the documented spectral bands.
- Known or plausible issues: Cloud and shadow contamination, atmospheric correction, sensor resampling, Fmask composite flags; not universally perfect spatial co-registration.
- Treatment: Apply Fmask and product scale/offset; track valid pixel percentages; compare compatible bands and observations of same season.

### EMIT: EMITL2BMIN.001 mineral estimates (P1)
- Agency: NASA LP DAAC; body: Earth; type: Hyperspectral-derived mineral raster
- Official documentation: https://doi.org/10.5067/EMIT/EMITL2BMIN.001
- Features: Mineral IDs, band depths, fit scores, uncertainties; ten dust-related mineral targets
- How to access: NASA Earthdata discovery; Earthdata Login likely for downloads.
- Formats: Science dataset granules, geolocation and QC layers
- Procedure: Search only regions within EMIT coverage; retrieve L2B mineral IDs, uncertainty, GLT x/y and longitude/latitude; sample footprint-linked evidence.
- Known or plausible issues: Not global continuous coverage, selective mineral taxonomy, retrieval uncertainty and challenging geolocation; absence of detection does not mean absence of mineral.
- Treatment: Check coverage and fit/uncertainty; preserve mineral class definitions; classify as unknown outside coverage; never infer full site mineralogy from one pixel.

### MOD13: MOD13Q1.061 vegetation indices (P1)
- Agency: NASA LP DAAC; body: Earth; type: Vegetation index time-series raster
- Official documentation: https://lpdaac.usgs.gov/documents/621/MOD13_User_Guide_V61.pdf
- Features: 250 m NDVI/EVI and per-pixel QA; vegetation / exposed-ground context
- How to access: NASA Earthdata Search / LP DAAC granules, download access may require Earthdata Login.
- Formats: HDF-EOS SDS with pixel QA
- Procedure: Obtain 16-day NDVI/EVI granules and detailed VI QA; apply 0.0001 scale to valid index pixels; use pixel reliability and composite acquisition time.
- Known or plausible issues: Cloud/smoke remnants, composite pixels selected from different days, view geometry differences and false precision if pixels are resampled.
- Treatment: Mask fill and unreliable per-pixel QA before index statistics; treat low NDVI as only a proxy for sparse vegetation, not proof of Martian geology.

### MCD12: MCD12Q1.061 annual land cover (P1)
- Agency: NASA LP DAAC; body: Earth; type: Categorical land-cover raster
- Official documentation: https://lpdaac.usgs.gov/documents/1409/MCD12_User_Guide_V61.pdf
- Features: Land-cover classes and data quality; barren/vegetated screening
- How to access: Earthdata Search / LP DAAC granules, Earthdata Login may be required.
- Formats: MODIS SDS land-cover + QA
- Procedure: Read chosen class legend and QA; calculate category shares within AOI; preserve native year and classification legend.
- Known or plausible issues: 500 m categorical classes can confuse mosaics or seasonal fields; classifications are model results; legends are not interchangeable.
- Treatment: Nearest-neighbor categorical resampling; label annual version; report confidence/QA and classes distribution not false fine detail.

### S2L2A: Sentinel-2 Level-2A (P1)
- Agency: ESA Copernicus; body: Earth; type: Optical surface reflectance
- Official documentation: https://documentation.dataspace.copernicus.eu/APIs/SentinelHub/Data/S2L2A.html
- Features: Multispectral reflectance, bare soil/vegetation, scene classification
- How to access: Copernicus Data Space account/access tokens for many download/processing services.
- Formats: SAFE/JP2 bands, API processed imagery
- Procedure: Search STAC/OData for AOI and date, fetch L2A/SCL/cloud mask, apply band-specific scale; compute supported spectral indices.
- Known or plausible issues: Clouds, shadows, cirrus; bands have different native resolutions, SCL model errors and reflectance artifacts.
- Treatment: Mask SCL cloudy/shadow/snow per research goal, use consistent resolution, report cloud fraction; do not treat reflectance as absolute rock mineral ID.

### COPDEM: Copernicus DEM GLO-90/GLO-30 (P1)
- Agency: Copernicus; body: Earth; type: Earth DEM
- Official documentation: https://documentation.dataspace.copernicus.eu/APIs/SentinelHub/Data/DEM.html
- Features: Elevation; fallback relief and terrain descriptors
- How to access: Sentinel Hub Process API and account; GLO-30 access may require CCM registration.
- Formats: DEM raster via Sentinel Hub processing
- Procedure: Request DEM type with explicit demInstance; check entitlement before relying on 30-m version; document replacement/fill data.
- Known or plausible issues: GLO-30 Public may be unavailable to user; GLO-30 gaps may be infilled by GLO-90; zero values over missing tiles/ocean.
- Treatment: Do not infer all pixels are 30-m precision; reject no-source areas; record source resolution and product license.

### CRISM: MRO CRISM MTRDR/TER/TRDR (P1)
- Agency: NASA PDS; body: Mars; type: Mars hyperspectral imagery
- Official documentation: https://pds-geosciences.wustl.edu/missions/mro/crism.htm
- Features: VNIR/SWIR spectra and mineral-related spectral signatures
- How to access: Public PDS Geosciences CRISM archive.
- Formats: PDS4 calibrated cubes, labels, supporting geometry
- Procedure: Choose corrected TER or map-projected MTRDR where available; read product SIS, band wavelengths and masks; subset selected Mars AOI.
- Known or plausible issues: Instrument artifacts, dust, atmospheric effects, differing observation geometries and data versions; limited target coverage.
- Treatment: Use recommended corrected products; align spectral wavelengths and sensor response before comparison with EMIT; report no valid match if unsupported.

### GPM: GPM IMERG Final daily V07 (P2)
- Agency: NASA; body: Earth; type: Precipitation time-series raster
- Official documentation: https://disc.gsfc.nasa.gov/datasets/GPM_3IMERGDF_07/summary
- Features: Daily precipitation rate, uncertainty, observation counts
- How to access: NASA GES DISC archive; Earthdata Login may be needed for protected access.
- Formats: NetCDF
- Procedure: Select valid daily files/AOI; extract precipitation and valid retrieval count and randomError; aggregate only over aligned periods.
- Known or plausible issues: Final product arrives with multi-month latency; daily values are rates mm/day; sparse microwave sampling and uncertainty.
- Treatment: Use V07 documentation; preserve units/rate-versus-total distinction; mask low-coverage cells; do not call historical final product real-time.

### S1GRD: Sentinel-1 GRD SAR (P2)
- Agency: ESA Copernicus; body: Earth; type: Radar backscatter
- Official documentation: https://documentation.dataspace.copernicus.eu/APIs/SentinelHub/Data/S1GRD.html
- Features: Radar texture, roughness proxies, surface changes
- How to access: Copernicus Data Space OData/STAC / Sentinel Hub APIs with appropriate account.
- Formats: SAFE, TIFF/processed backscatter
- Procedure: Fetch GRD by orbit/polarization/geometry, apply radiometric calibration, terrain correction and speckle filtering when justified.
- Known or plausible issues: Speckle, layover, shadow, incidence-angle dependence, different polarizations; GRD loses phase.
- Treatment: Compare same polarization/incidence regimes; log calibration and correction; do not interpret raw amplitudes as physical terrain roughness.

### RADARSAT1: RADARSAT-1 open archive (P2)
- Agency: Canadian Space Agency; body: Earth; type: Historic SAR
- Official documentation: https://www.asc-csa.gc.ca/eng/satellites/radarsat1/data-access.asp
- Features: Historical radar observations and surface-change support
- How to access: Open Government Licence, downloads via NRCan EODMS or AWS S3 per CSA guidance.
- Formats: Archive-specific SAR product packages
- Procedure: Search EODMS for selected historical AOI and acquisition conditions; inspect product processing level and calibration.
- Known or plausible issues: Older radar geometry/resolution and inconsistent inter-sensor comparability; analysis-ready processing availability varies.
- Treatment: Preserve orbit/beam and product processing metadata; calibrate before comparative analyses; mark historical-only.

### LROC: LRO LROC images (P2)
- Agency: NASA PDS; body: Moon; type: Planetary optical imagery
- Official documentation: https://pds-geosciences.wustl.edu/missions/lro/
- Features: Lunar visual context, crater/rock texture hypotheses
- How to access: PDS archive / LROC data node from official LRO mission directory.
- Formats: PDS imagery and associated metadata
- Procedure: Find mission LROC linked archive, select image and accompanying labels for Moon AOI; use as context and for validated feature algorithms only.
- Known or plausible issues: Illumination/phase variations, shadows, local image resolutions and raw pixels without geocorrection.
- Treatment: Keep acquisition geometry; avoid rock-size or mineral claims without calibrated geometry/classifier validation.

### MINIRF: LRO Mini-RF radar (P2)
- Agency: NASA PDS; body: Moon; type: Lunar radar mapping
- Official documentation: https://pds-geosciences.wustl.edu/dataserv/holdings.html
- Features: Radar texture, backscatter, possible polar volatile research context
- How to access: Public PDS LRO Mini-RF holdings.
- Formats: PDS calibrated/radar map products
- Procedure: Choose map-projected calibrated mosaic with applicable radar metadata; align with selected LOLA lunar area.
- Known or plausible issues: Radar signatures are not unique indicators of ice; acquisition geometry and polarization matter.
- Treatment: Treat potential ice as a hypothesis, not a demonstrated resource; use dedicated calibration/interpretation literature.

## Expected code/source separation
- Raw source byte snapshots in object storage, immutable and checksum-addressed.
- Cleaned features in keyed tables, versioned by algorithm/config/inputs.
- Report generator consumes validated feature records and limitation flags only.

## Prioritization
1. First actual Earth dataset + one actual planetary reference.
2. Quality masks, coordinate/temporal alignment, and null preservation.
3. One reproducible comparison and bounded portfolio, then UI.
4. Additional products only after working end-to-end release gate.
