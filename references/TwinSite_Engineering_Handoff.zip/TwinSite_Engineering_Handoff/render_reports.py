from pathlib import Path
from markdown_it import MarkdownIt
from weasyprint import HTML
import re
ROOT=Path(__file__).resolve().parent
MD=MarkdownIt('commonmark', {'html':True, 'linkify':True}).enable('table').enable('strikethrough')
STYLE='''
@page { size: A4; margin: 18mm 16mm 19mm; @bottom-left { content:"TWINSITE · ENGINEERING HANDOFF / 2026"; font-family: DejaVu Sans; font-size:7.2pt; color:#727b7e; } @bottom-right { content:counter(page); font-family: DejaVu Sans; font-size:8pt; color:#727b7e;} }
* { box-sizing: border-box; }
body { color:#20282A; font: 9.15pt/1.55 "DejaVu Sans", sans-serif; }
h1 { font-size:22pt; line-height:1.17; color:#17232b; padding-bottom:8px; border-bottom:3px solid #b96d45; margin:0 0 16px; letter-spacing:-.35px; }
h2 { color:#a45933; font-size:13.7pt; line-height:1.24; margin:22px 0 9px; break-after:avoid; border-left:3px solid #c27a53; padding-left:9px; }
h3 { color:#273638; font-size:10.6pt; margin:13px 0 6px; break-after:avoid; }
p { margin: 6px 0 9px; overflow-wrap:anywhere; }
li { margin:3px 0; }
ul,ol { padding-left:22px; margin: 7px 0 12px; }
strong { color:#15282e; }
a { color:#ad643e; text-decoration:none; overflow-wrap:anywhere; }
a:hover { text-decoration:underline; }
table { width:100%; border-collapse:collapse; table-layout: fixed; margin: 10px 0 15px; font-size:7.55pt; line-height:1.32; }
thead { display:table-header-group; }
tr { break-inside:avoid; }
th { background:#19292f; color:#fff; text-align:left; padding:7px 7px; vertical-align:top; font-weight:bold; }
td { border-bottom:1px solid #dce0df; padding:6px 7px; vertical-align:top; overflow-wrap:anywhere; }
tbody tr:nth-child(even) td { background:#f2f4f3; }
blockquote { margin:12px 0; padding:10px 14px; background:#f5ede7; border-left:4px solid #bd714b; font-size:9pt; }
blockquote p { margin:0; }
code { color:#8c4e30; font:8pt/1.25 "DejaVu Sans Mono", monospace; overflow-wrap:anywhere; }
pre { background:#15242b; color:#e5ecec; padding:10px 13px; border-radius:6px; white-space:pre-wrap; overflow-wrap:anywhere; font-size:7.7pt; line-height:1.42; }
pre code {color:#e5ecec; font-size:7.4pt;}
img {display:block; max-width:100%; max-height:145mm; margin:12px auto 14px; object-fit:contain; }
hr { border:0; border-top:1px solid #dde1df; margin:19px 0; }
.cover { height:235mm; padding:23mm 10mm; display:flex; flex-direction:column; justify-content:space-between; page-break-after:always; }
.cover .kicker {font-size:10pt; letter-spacing:3px; color:#B46A42; font-weight:bold;}
.cover h1 {font-size:34pt; border:none; max-width:150mm; padding-top:25mm; line-height:1.16;}
.cover .sub {font-size:14pt; color:#566365; max-width:130mm; line-height:1.5;}
.cover .meta {border-top:1px solid #C5CBCA; padding-top:15mm; color:#6F7D7F; font-size:9pt;}
'''
items=[('01_AI_API_Routing','AI API & Routing','Zero-cost providers · quotas · safe fallback'),('02_Agent_Architecture','Agent Architecture','13 roles · orchestration · typed contracts'),('03_Simple_Analysis_Engine','Simple Analysis','No-AI scientific engine · scoring · portfolios')]
for slug,title,sub in items:
    f=ROOT/'reports'/f'{slug}.md'
    md=f.read_text()
    htmlbody=MD.render(md)
    # A few markdown-to-HTML links are intentionally plain URLs and become wrapped if explicit.
    cover=f'<section class="cover"><div><div class="kicker">TWINSITE  /  NASA SPACE APPS</div><h1>{title}</h1><div class="sub">{sub}</div></div><div class="meta">Engineering specification · 15 November 2026<br/>Read with the companion reports, configuration registry and acceptance tests.<br/>No secret keys included.</div></section>'
    full=f'<!DOCTYPE html><html><head><meta charset="utf-8"><style>{STYLE}</style></head><body>{cover}{htmlbody}</body></html>'
    htmlfile=ROOT/'reports'/f'{slug}.html'; htmlfile.write_text(full)
    outfile=ROOT/'reports'/f'{slug}.pdf'
    HTML(filename=str(htmlfile),base_url=str(htmlfile.parent)).write_pdf(str(outfile))
    print(outfile.name, outfile.stat().st_size)
