# TwinSite package validation record

- PDF source reports produced with WeasyPrint from included Markdown; three reports rendered and visually spot-checked.
- The included numerical reference is **synthetic only** and does not call external AI or NASA endpoints.
- `python -m unittest discover -s validation -v`: **7 tests passed** for scoring, missing evidence, access constraints, costs, portfolio complementarity, weight validation, and evidence-ID requirement.
- Provider model-list/credential tests are **from the supplied VESPER inventory**, not repeated by these documents. Actual inference capacity, remaining free quotas and registered model eligibility **not verified**.
- All provider routes default **disabled**. Set `TWINSITE_LLM_ENABLED=false` for the demonstration fallback test.
- No credential values are stored in this package. Only environment variable identifiers appear.
- Data-source catalog is a planning source mapping; full Earth–Moon/Mars scientific download and validation remain implementation tasks.
