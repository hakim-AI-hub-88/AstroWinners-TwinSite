from pathlib import Path
import sys, unittest
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'examples'))
from simple_analysis_reference import Requirement, Observation, Site, feature_similarity, score_site, portfolios

class ScientificCoreTests(unittest.TestCase):
    def setUp(self):
        self.req = [Requirement('slope', .7, 10.0, 5.0), Requirement('rough', .3, 1.0, .5)]
    def test_scalar_score(self):
        self.assertAlmostEqual(feature_similarity(12,10,5),.6)
    def test_missing_required_blocks(self):
        r=score_site(Site('A', {'slope':Observation(10,'degree','x')},access='pass'),self.req)
        self.assertFalse(r['eligible']); self.assertEqual(r['missing'],['rough']);self.assertAlmostEqual(r['coverage'],.7)
    def test_unknown_access_blocks_strict(self):
        s=Site('B', {'slope':Observation(10,'degree','x'),'rough':Observation(1,'m','y')},access='unknown')
        self.assertFalse(score_site(s,self.req)['eligible'])
    def test_evidence_required(self):
        with self.assertRaises(ValueError):
            score_site(Site('C',{'slope':Observation(10,'degree','')},access='pass'),self.req)
    def test_cost_unknown_not_zero(self):
        s=Site('D',{'slope':Observation(10,'degree','x'),'rough':Observation(1,'m','y')}, cost=None,access='pass')
        self.assertEqual(portfolios([s],self.req,budget=100),[])
    def test_portfolio_complements(self):
        a=Site('A', {'slope': Observation(10,'degree','a'),'rough':Observation(1.4,'m','b')},cost=40,access='pass')
        b=Site('B', {'slope': Observation(13,'degree','c'),'rough':Observation(1,'m','d')},cost=50,access='pass')
        opts=portfolios([a,b],self.req,max_sites=2,budget=100)
        multi=next(o for o in opts if len(o['sites'])==2)
        self.assertAlmostEqual(multi['science_coverage'],1.0)
        self.assertEqual(multi['known_cost'],90)
    def test_weight_sum(self):
        with self.assertRaises(ValueError):
            score_site(Site('X',{},access='pass'),[Requirement('slope',.6,10,1)])

if __name__=='__main__':unittest.main()
