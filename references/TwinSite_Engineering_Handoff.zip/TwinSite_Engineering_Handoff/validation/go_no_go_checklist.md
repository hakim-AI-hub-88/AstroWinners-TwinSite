# TwinSite final AI API go/no-go checklist

## Credential + provider safety
- [ ] Resolve provider quota bucket identities (account/project/org), dedupe aliases, respect service terms.
- [ ] Confirm each model ID from that credential's actual model catalog, feature support, and present free-tier pricing.
- [ ] Verify billing route cannot charge (no pay-as-you-go model / no paid fallback / no auto top-up).
- [ ] Perform **one low-token generation canary only when free and allowed**, record latency, result schema, usage headers.
- [ ] Fetch latest account usage or use conservative unknown-quota policy; old VESPER ledger cannot be trusted.
- [ ] Check structured output and image support on the exact model when needed.
- [ ] Check no key is logged or exposed; inventory only records env var names.

## User uploads and no-login privacy
- [ ] Default external-AI upload sharing OFF.
- [ ] Before every external request with upload-derived content, display selected provider, data excerpt/category, purpose, retention/terms link, and a toggle to decline.
- [ ] Revalidate the consent and provider selection server-side; do not allow another provider through fallback without consent.
- [ ] Send only needed, redacted snippets; maintain source/page IDs.
- [ ] Read-only data browser shows curated public data. User uploads are session-scoped, not public.
- [ ] Remove user data after declared retention or user-requested deletion.

## Demo resilience
- [ ] A report and portfolio render with all AI providers disabled.
- [ ] Reserve >=60% of verified remaining free capacity for demo; do not assume a quota reset.
- [ ] Typical analysis uses 0–2 AI requests; strict maximum 4 optional calls.
- [ ] User-facing progress reflects actual deterministic phases and AI skips.
- [ ] Model/API 429, 401, 403, 5xx and invalid JSON tested with controlled mocks.
- [ ] No retry chain crosses the shared quota bucket or selected upload-consent boundary.
- [ ] Capture frozen verified-science demo dataset and screen recording.

## Scientific evidence
- [ ] Agent responses include citation/feature IDs, no unsourced scientific numbers.
- [ ] Deterministic validators reject invalid units, missing mandatory inputs, fabricated sources, duplicate evidence.
- [ ] Final release judge cannot overrule critical quality failures.
