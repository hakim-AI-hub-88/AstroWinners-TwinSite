# TwinSite | AI API routing architecture

**FINAL ENGINEERING SPECIFICATION** · Revision 1.0 · 15 November 2026  
**Policy:** zero paid inference; external processing of uploaded content requires explicit, provider-specific consent  
**Inputs:** VESPER credentials inventory (14 November 2026), TwinSite feasibility package, agency/data architecture and official provider documentation.

> **Executive decision.** TwinSite is scientifically functional with **zero AI calls**. All numerical analysis, geospatial computation, quality gates, portfolio optimization, confidence descriptors and publication eligibility are deterministic. External AI calls only annotate imagery/documents, investigate exceptions, improve explanations or polish a factual report. This is a verified *design decision*, not a claim that API credentials have been exercised end to end.

## 1. What's actually available

Claude's read-only VESPER inventory found 49 environment assignments, including duplicates and non-LLM credentials. The table below refers to **usable credential groups**, not independent free quotas. HTTP 200 from a model-list or token-verification endpoint does **not** prove the selected model can generate or that remaining capacity is available.

| Provider | Inventory evidence | Decision for TwinSite inference | Limiting unknown |
|---|---|---|---|
| Cloudflare Workers AI | Six token/account pairs verified for catalog access | **Primary optional text**, only on confirmed Workers Free accounts and eligible free models | Current neurons consumed; model/account billing eligibility; exact per-request neuron usage |
| Groq | Five keys list models successfully | **Secondary optional text/review**, after a tiny free canary | Current organization/project rate limits and remaining token/request allowance |
| Google Gemini | Six distinct keys returned model lists; reserved `GEMINI_API_KEY` alias must stay tooling-only | **Optional vision or public-data narrative** only after validating model, free tier and project IDs | Current project quotas; whether configured model IDs are enabled/free; data-use terms |
| OpenRouter | Two keys with inventory-reported zero usage | **Last-resort free text** using explicit `:free` model IDs | Same-account grouping, model availability and free rate caps; user-upload consent |
| Mistral | Nine keys list models | **CONDITIONAL, disabled pending test** | Mistral documents limited developer API requests in Free mode; model-, account-, and billing-specific free entitlement and remaining usage are not verified by model-list checks |
| NVIDIA NIM | Two keys list models | **Disabled pending terms and free-balance check** | Prototyping access/credit eligibility and actual model support |
| Ollama Cloud | Three keys return model tags | **Disabled pending quota and zero-billing verification**; local Ollama can be an independent optional route | Hosting limits, account entitlements, ability to execute chosen model |
| ElevenLabs | Six audio/speech keys | **Excluded from scientific analysis** | Not required, save capacity |
| Anthropic/Claude subscriptions | Two VESPER tokens plus a CLI account | **Development only** | Subscription/CLI login is not an Anthropic API key or guaranteed production inference entitlement |
| Codex/ChatGPT Plus | OAuth login, no `OPENAI_API_KEY` | **Development only** | ChatGPT subscription does not supply API credits |

**Do not count 49 as 49 inference quotas.** Google aliases duplicate one key, provider limits are often per project/org, and VESPER's usage ledger is stale. Hard-block paid models or accounts with an unknown billing path. In particular, do not rotate keys within the same quota scope in response to `429`.

## 2. Overall AI design and integration

![AI routing and fallback](../diagrams/router.svg)

**Architecture:** `FastAPI -> mission orchestrator -> deterministic worker -> optional AI task -> router -> approved provider -> schema validator -> evidence store`. The orchestrator owns task ordering, state, idempotency, retry budgets and release gates. Provider-specific drivers own API protocol details. No LLM can run arbitrary shell, SQL mutations, download arbitrary hosts or change processing code.

### Hard requirements

1. **Free-only hard gate:** Provider route must be pre-approved as $0 for the exact account, model and feature; do not infer pricing from the fact that a key works.
2. **Quota groups:** Keys are assigned to the *real* account/project/organization scope, not independent buckets merely because names differ.
3. **Privacy classes:** `PUBLIC_AGENCY`, `USER_UPLOAD_CONSENTED`, and `PRIVATE_OPERATIONS`. External AI may see user uploads only for the named provider/purpose approved for that run. `PRIVATE_OPERATIONS` includes secrets, raw credentials, internal health logs and is never sent externally.
4. **No paid fallback:** Paid/free mixed gateways can only receive explicit free model IDs and a validated zero-billing route.
5. **Deterministic output contract:** Agent response must be valid against typed JSON schema, with cited evidence IDs and explicit uncertainty. Agent-generated measurements are not trusted.
6. **Bounded execution:** Initial deployment allows one concurrent LLM call, at most four optional inference calls per mission and at most two total attempts per AI task across all providers.
7. **Demo reserve:** Protect at least 60% of **verified** remaining free allowance *per quota group* from non-demo traffic. If remaining usage is unknown, disable ordinary optional inference and use Simple Analysis.
8. **User control:** Auto and Custom Analysis work with external AI disabled. The public UI never displays credentials and contains no login/RBAC/settings page.

## 3. Exact router process

**Step 0 - Determine necessity.** Every phase first executes its deterministic handler. The orchestrator creates an AI work unit only if the handler emits a legitimate `optional_ai_need` (e.g., `explain_scientific_anomaly`, `annotate_uploaded_photo`, or `narrative_polish`). Data cleaning, numerical feature extraction, comparison and portfolio selection never require an AI work unit.

**Step 1 - Data policy.** Classify every input fragment. For a user upload, require an affirmative run-scoped consent record specifying provider(s), purpose, data subset, and applicable provider terms. Consent to Gemini does not authorize silent fallback to Groq.

**Step 2 - Capability.** Check whether the exact model supports the requested task: text JSON, image, document, or mixed modality. `model list` success is insufficient; run a single small *free* canary after account settings permit it.

**Step 3 - Quota and billing.** Check live per-project/org budgets, known response headers, reserved capacity, token estimate and the hard no-spend switch. The same quota limiter serves every agent sharing the underlying account.

**Step 4 - Execute.** One in-flight request initially. Time out; record provider request ID and actual token/neurons if returned. Redact all credentials, prompts containing uploaded user data and private operational content from public logs.

**Step 5 - Validate.** Parse JSON; validate known enums, citation IDs, ranges and document/observation references. Invalid prose or invented citations cause a single bounded repair or skip. Never copy a generated number into scientific measurement tables.

**Step 6 - Fail safely.** On complete exhaustion, operator disable, privacy mismatch or provider error, return the deterministic artifact and an `ai_enrichment_skipped` event. The report/portfolio remains available.

## 4. Provider route policy

| Capability | First choice | Second choice | Final fallback |
|---|---|---|---|
| Short source-selection explanation | Cloudflare verified-free text | Groq verified-free text | Template based on source metadata |
| Image/photo qualitative annotation | Gemini *verified free vision* | Another independently verified free vision route only if consented | No annotation; raw calibrated bands still processed deterministically |
| Quality-issue explanation | Cloudflare verified-free text | Groq verified-free text | Rule-code description catalog |
| Scientific narrative synthesis | Groq verified-free text | Cloudflare verified-free text | Deterministic evidence summary |
| Independent narrative review | Groq verified-free text | Cloudflare verified-free text | Cross-check claims against feature and source IDs |
| Report prose polishing | Cloudflare verified-free text | Explicit free Gemini route | Deterministic report template |
| Scoring, portfolio, QA, math, charts, logging | **NO LLM** | **NO LLM** | Deterministic Python |

Current inventory includes configured model labels such as `gemini-3.6-flash`, `openai/gpt-oss-120b` and `@cf/openai/gpt-oss-120b`. Treat every configured ID as a *candidate* and revalidate the exact identifier against that account's live catalog before enabling it. Do not assume a model name implies free access.

## 5. Quota budgeting and demo guarantee strategy

No architecture can guarantee uninterrupted external inference while remaining on free tiers. We can guarantee the **analysis/demo does not depend on external inference**.

- Reserve **60%** of verified remaining usage for the final live demo; allocate **25%** to essential pre-demo tests; keep **15%** as operator-controlled emergency allowance. These percentages are operating policy, not reported account balances.
- Typical mission: **0 AI calls** if no qualitative analysis is needed; otherwise target **1 synthesis + 1 prose call**. Allow image annotation only where the user explicitly requested and consented to it.
- Upper hard budget: **4 total optional AI calls per run**, including all agents but not retries; retries additionally capped to one extra attempt per task and must fit quota reserve. For an API-critical demo, prefer 0 calls.
- Precompute *one real, reproducible NASA-data mission* and keep its source snapshots, comparison table, portfolio, explanatory findings and PDF fully accessible offline.
- Don't pre-purchase anything, don't assume daily quota reset, don't use subscription CLI tokens as undocumented automated backends, and don't enable auto-upgrade/top-up.
- Groq's actual rate-limit headers may expose remaining RPD and TPM, but daily *tokens* and other budgets still need console/ledger review. Google limits are project-based and reset at Pacific midnight; Cloudflare free allowance resets at 00:00 UTC.

### Routing error matrix

| Failure | Response | What the orchestrator does |
|---|---|---|
| `401` | Credential bad | Disable credential, no same-key retry |
| `403` / billing-required | Entitlement/privacy | Disable route, flag operator action; never pay |
| `429` | Rate/quota exceeded | Honor `Retry-After`; cool down shared quota group; do **not** rotate same-account keys to bypass |
| `404` model ID/retired | Missing model | Disable model, try independently allowed model with capability test |
| `5xx`/timeout | Transient | At most one bounded backoff; then allowed alternative or Simple Analysis |
| Invalid JSON/unsupported claims | Contract failure | One constrained retry if quota allows, else deterministic template |
| Consent mismatch | Privacy failure | Don't call provider; deterministic output |
| Free capacity unknown | Budget uncertainty | Disable optional inference outside manual one-call free canary |

## 6. User-upload processing policy, without login pages

- Before external AI sees an upload or upload-derived excerpt, display **which provider**, exact purpose, categories or sample of data transmitted, data minimization notice and the provider's data/privacy terms. Consent must default **OFF** and be separately recorded per run, provider and purpose.
- If the user declines, locally parse CSV/GeoTIFF/NetCDF/PDF tables using approved deterministic parsers. Unsupported narrative extraction is marked `unavailable`, not guessed.
- A no-login site can still protect upload artifacts: use high-entropy run IDs or private capability tokens with short expiry, scope all artifact reads to the run, sanitize filenames, limit sizes, and prevent public-indexing and directory listing. Do not publish arbitrary uploaded data through the Data Explorer.
- External fallback to a different provider requires its own consent. Never send raw API credentials, personal/secret tokens, unredacted health logs, or database connection strings to any model.
- Users must be able to download and delete their run artifacts according to the published retention policy. Operator-only provider-health records stay in backend VM tools.

## 7. Minimal reference configuration

Configuration in `../configs/provider_registry.yaml` is **disabled by default** until runtime verification; `../configs/quota_policy.json` specifies hard budgets and denial cases; `../configs/agent_routes.csv` maps roles to deterministic handlers and optional inference; `../configs/env.example` includes variable names only. Never commit actual credential values.

**Deployment switches:**

```env
TwinSite_INFERENCE_MODE=free_only
TwinSite_LLM_ENABLED=false
TwinSite_LLM_CONCURRENCY=1
TwinSite_MAX_OPTIONAL_AI_CALLS_PER_RUN=4
TwinSite_DEMO_RESERVE_FRACTION=0.60
TwinSite_EXTERNAL_UPLOAD_AI_DEFAULT=off
TwinSite_ALLOW_PAID_FALLBACK=false
```

## 8. Preflight decisions and acceptance

| Check | Evidence required | Go/no-go |
|---|---|---|
| Free model/account | Pricing and billing plan + account configuration | Unknown => route disabled |
| Model text or vision support | Catalog plus one small allowed free generation canary | Unknown => role disabled |
| Quota group identity | Provider project/org/account ID, no values in public docs | Unknown => do not multiply key quotas |
| Remaining daily allowance | Current headers/dashboard/local ledger | Unknown => preserve all optional budget for demo |
| Upload consent | Server-stored provider-specific record | Missing => no external upload traffic |
| Offline mission | Same snapshot produces report and portfolio with AI disabled | **Required** |
| Scientific integrity | LLM output never changes measurements, scores or release status | **Required** |

## 9. Official reference links and caveats

- Gemini limits: https://ai.google.dev/gemini-api/docs/rate-limits — project quotas, model-specific limits, Pacific-time reset.
- Gemini pricing/data policy: https://ai.google.dev/gemini-api/docs/pricing — free vs paid and data-use restrictions (especially important for user uploads).
- Groq limits: https://console.groq.com/docs/rate-limits — organization ceilings, requests/tokens per window and headers.
- Groq projects: https://console.groq.com/docs/projects — project limits are bounded by organization ceilings.
- Cloudflare Workers AI pricing: https://developers.cloudflare.com/workers-ai/platform/pricing/ — Workers Free 10,000 neurons/day; verify each model's eligibility.
- OpenRouter free models: https://openrouter.ai/collections/free-models — explicit `:free` model routes; daily/request caps.
- Mistral Free API limits: https://help.mistral.ai/en/articles/698531-why-am-i-hitting-api-rate-limits-and-how-do-i-increase-them — Free mode is documented with limited testing/prototyping API limits; actual account entitlement and zero-charge route must be confirmed.
- NVIDIA development APIs: https://build.nvidia.com/settings/credits — verify actual account entitlements.

**Final verdict:** **Sufficient for optional AI enrichment, not sufficient to promise always-on AI during the hackathon.** TwinSite's core succeeds because Simple Analysis runs without inference; AI extends the evidence presentation, never determines scientific truth.


## 10. Deployment contract and API capability checks

**Required router interface:** `route(request: OptionalAIRequest) -> AIOutcome`. Request fields: `run_id`, `agent_id`, `capability` (`text_json|vision_annotation|narrative`), `data_class`, `provider_allowlist`, `consent_id`, `token_estimate`, `priority` (`dev|demo|emergency`), `input_artifact_ids`, and `idempotency_key`. The router returns structured status `completed|skipped|failed`, `provider`, `model`, `quota_bucket`, `output_artifact_id`, `usage`, `failure_class`, and audit references. Source measurements may never originate from this interface.

**Model canary:** An authenticated `GET /models` is insufficient. Before enabling a route, do one permitted, minimal inference request with a toy, non-sensitive prompt, validate structured output and actual usage headers, confirm that no billing was triggered, and record quota scope. Only test vision separately if A02 needs it.

**Account grouping:** Resolve real Google project IDs (including the `GEMINI_API_KEY`/`GOOGLE_API_KEY` alias), Groq organization IDs, Cloudflare account IDs, OpenRouter account/organization ownership, and Mistral organization IDs. Do not assume that keys with different names have independent budgets. The inventory lists 49 assignments but includes duplicates and services unrelated to scientific inference; the counted free capacity is **unknown**.

**Mistral correction:** Current official Mistral help documents a limited Free mode suitable for evaluation and prototyping, with organization-level request/token limits. A prior internal note saying Free mode cannot call the API is too categorical. Do not enable Mistral until the user's specific account/model is verified to allow a strictly $0 completion.

**Gemini privacy:** Gemini's published Free tier may use submitted content to improve products. User-provided data must not be routed there without provider-specific, informed consent. Do not default to Gemini as a private-data backup. Consent applies to excerpts and extracted/upload-derived content too.

**Simple Analysis ownership:** The deterministic engine is the source of truth for numerical/temporal/geospatial features, comparisons, confidence descriptors, constraints, Pareto optimization and report facts. AI roles cannot overwrite it. A whole mission must finish with `TWINSITE_LLM_ENABLED=false`.

## 11. Free-tier capacity accounting and release check

At mission creation, snapshot each eligible quota group (`group_id`, `model_id`, `window_start`, `window_end`, `hard_limit`, `measured_usage`, `reserved_units`, `allowed_new_usage`, `last_checked_at`). When only a published limit is known, mark `remaining_verified=false` and avoid non-demo calls. Model tokens, requests, neuron units and credits are **separate unit families** and cannot be summed as a single "credit" balance.

Reserve policy: 60% of **verified remaining** allowance for the demonstration, 25% for essential tests and 15% for emergencies. This is a planning policy, not a promise of remaining capacity. Retain an offline, real-data mission snapshot. At report generation, use source-backed template prose if provider access is unavailable.

| Deployment gate | Required evidence | Failure behavior |
|---|---|---|
| Account free entitlement | Provider dashboard and exact model pricing | Disabled |
| Valid generation | Single controlled free canary, schema check | Disabled |
| Quota scope | Provider project/org/account ID | Treat as shared, no key multiplication |
| Remaining budget | Current dashboard, usage headers, local consumption ledger | Hold optional calls |
| Privacy consent | Per-run, provider-specific grant and payload summary | No external submission |
| Resilience | Same mission succeeds with all providers off | Block public demo release if absent |

## 12. Source fidelity and reference documentation

**Internal source:** Claude's `VESPER_credentials_inventory(1).md`, generated 2026-11-14 23:11, checked model catalogs and token verification endpoints but deliberately performed no generation calls. Two Claude subscription tokens were not probed. VESPER quotas recorded before Nov 14 are stale.

**Primary documentation, checked November 2026:**

- Cloudflare Workers AI: https://developers.cloudflare.com/workers-ai/platform/pricing/ (10,000 free neurons/day, reset 00:00 UTC, some paid-only models).
- Gemini rate limits: https://ai.google.dev/gemini-api/docs/rate-limits (per-project; midnight Pacific reset).
- Gemini pricing and free-tier data terms: https://ai.google.dev/gemini-api/docs/pricing .
- Groq: https://console.groq.com/docs/rate-limits (organization-level limits).
- OpenRouter: https://openrouter.ai/collections/free-models (`:free` models, 50 requests/day on free account; failed calls count).
- Mistral: https://help.mistral.ai/en/articles/698531-why-am-i-hitting-api-rate-limits-and-how-do-i-increase-them (limited Free-mode API).
- Ollama Cloud: https://www.ollama.com/pricing (free starter credits; no assumption of remaining balance).

**Not independently verified:** real remaining balances, current model-specific free entitlement for each user's credentials, generation success, privacy settings of each account, quota group identities, deployment health and production suitability.
