# TwinSite | Simple Analysis engine: no AI

**Scientific computation and fail-safe engine · 15 November 2026**  
**Contract:** Simple Analysis is the **default source of numerical truth** for all runs. It is not a reduced-quality mode. AI may provide explanations and annotations, but disabling all AI APIs must not affect measurements, rankings, eligibility or portfolio membership.

![Deterministic analytical flow](../diagrams/simple.svg)

## 1. What Simple Analysis handles, without any model API

| Input class | Libraries and method | Outputs | Invalid/unknown behavior |
|---|---|---|---|
| CSV, JSON, Parquet tables | pandas/pyarrow, Pydantic validation | Typed rows, summaries, joins | Reject schema mismatch; preserve nulls |
| Earth and planetary DEMs | Rasterio/GDAL/NumPy/pyproj; PDS labels | Slope, relief, roughness distributions | Mask voids; unsupported local scale => unavailable |
| Geospatial vectors | GeoPandas/Shapely/PostGIS | Intersections, land-cover/area fractions, distances | Invalid geometry => quarantine or approved repair |
| Time series | pandas/Xarray grouped by qualified time standard | Extremes, seasonal windows, trend descriptors | Missing periods => report coverage; no guessed values |
| Optical/thermal multiband | Product decoder, QA mask, scale/offset | Physically calibrated measurement layers | Rendered RGB / false color not treated as numerical truth |
| Spectra (advanced) | Wavelength calibration, response harmonization, documented distance | Compatible spectra comparisons | Incompatible bands/process levels => block comparison |
| Planetary target features | PDS/LOLA/MOLA/MEDA/Diviner parsers by product | Target descriptors with body, units, scale, time | Wrong coordinate convention => block |
| User mission constraints | Pydantic + explicit units/currency/time | Hard/soft criteria and scenario ranges | Invalid input => field-level error |
| Candidate scoring | NumPy/pure Python, versioned distance functions | Per-feature scores, coverage, evidence ranges | Missing required feature => strict failure |
| Portfolio optimization | Enumerated combinations for small pools; OR-Tools later | Pareto alternatives and complementary coverage | Unknown budget => do not claim affordable |
| Data QC and logs | Deterministic rules, digests, timestamps | Quality verdicts and audits | Critical issue => quarantine |
| Reports/charts | Jinja2/HTML, PDF, CSV, JSON; map layers | Traceable pros/cons and reproducible exports | Unsupported claims omitted with explanation |

**What it never does:** invent mineral identities from generic images, estimate real soil cohesion from RGB images, assert permits from map appearance, guess fuel prices or staffing costs, turn missing data into zero, or fabricate statistical confidence percentages.

## 2. Required source data and the source-to-feature bridge

Core inputs: NASA Earthdata CMR granule metadata and authenticated product downloads where needed; SRTMGL1 Earth elevation; PDS MOLA Mars elevation or LOLA lunar topography; NASA POWER climate/time series; MODIS MOD11A2 land-surface temperature for environmental missions. Diviner and MEDA are mission-dependent thermal/atmosphere target sources, GIBS supplies visual context. Other imagery, geology, spectra and resource indicators stay optional until adapter and coverage validation succeeds.

Each **feature definition** must declare `feature_id`, physical quantity, valid bodies, canonical unit, `source_product_ids`, format decoder, QA mask, spatial support, observation period, derivation and uncertainty method, comparison metric, requiredness and threshold/tolerance. This registry determines *what is scientifically comparable* before any scoring.

The mission's mandatory scientific features must be satisfiable using actual agency observations or a documented derivation. If not, the user can change the mission scope, or the system produces an insufficient-evidence result. **User inputs are allowed for budget, equipment and planning assumptions, not to masquerade as measured lunar/Martian geology or temperature.**

## 3. Data acquisition and strict quality processing

1. **Select:** Use bounded AOI, target body, target time interval and verified product ID. Record native coordinate convention and any collection version.
2. **Discover:** Query product catalog; check actual asset/granule coverage before download. Save API response and continuation cursor.
3. **Snapshot:** Download selected granules with size budget; store original bytes, checksums, source URL, product version, access date, license and processing level.
4. **Decode:** Parse product-specific labels, scale/offset, fill values, physical units, band naming, QA bits, local time and georeferencing.
5. **Validate:** Compare schema and source metadata; reject undocumented conversion, coordinate assumptions and invalid ranges. Never silently interpolate missing instrument measurements.
6. **Repair:** Apply only allowlisted, deterministic transforms and record before/after; maximum two repair attempts per asset by default. Unknown calibration or CRS => quarantine.
7. **Feature extraction:** Calculate actual normalized descriptors with method version and spatial/temporal support; save coverage fraction, uncertainty if provided, source asset IDs and quality issues.
8. **Freeze:** Accepted features become immutable versioned inputs; weight and portfolio changes reuse them. Changed source data trigger dependent recalculation only.

`QualityVerdict` = `ACCEPT | REPAIR_ALLOWED | QUARANTINE | INSUFFICIENT`. This is distinct from a mission's scientific eligibility and a site's legal/operational feasibility.

### Specific source traps

| Product | Required handling |
|---|---|
| **SRTMGL1** | NoData, voids, 30 m-class grid, latitude coverage, vertical reference; slope in metric projected coordinates |
| **POWER** | Source variable units, `fill_value`, cell resolution, UTC/local solar time, effective day period, provider query limits |
| **MOD11A2** | Day/night subdatasets, documented temperature scale factor, QA interpretation, cloud/invalid observations, eight-day temporal composites |
| **MOLA** | PDS label, latitude/longitude convention, areoid vs radius, interpolation and actual terrain scale |
| **LOLA** | Lunar body geodesy, polar projection, DEM product quality/error, sampling density |
| **Diviner** | Calibrated channel, physical units, local-time sampling; documented invalid sentinels |
| **MEDA** | Rover-specific location, Mars sol conversion, data gaps and sensor quality flags |
| **HLS/EMIT/CRISM** | QA, geometry, proper band calibration and intersensor compatibility; do not infer from false-color previews |

## 4. Spatial, temporal and unit comparability

A descriptor is comparable only if the measurement semantics are appropriate. NASA DEM elevation/slope can support terrain similarity but **Earth elevation above sea level and Mars elevation relative to an areoid are not physically interchangeable**. Compare local relief and distributional slope at common supported scales when mission objectives justify them. Planetary coordinates must never be passed as Earth EPSG:4326 search bounds without body-aware conversion.

**Terrain:** calculate slopes using physical horizontal distances with native/equivalent metric local projections, not naive degrees-to-meters. For a region, retain percentiles (p10/p50/p90), slope histograms, valid-area fraction, roughness distribution and footprint size. Avoid falsely improving precision by upsampling a coarse DEM.

**Time:** never compare unqualified yearly means with a one-hour rover observation. Explicitly label historic climatology vs concurrent measurement vs forecast. Daylight/illumination effects and lunar local time matter. Date bins must preserve observation counts and effective support; Mars sols require correct calendar conversion.

**Spectra:** compare physically compatible sensor responses, calibrated reflectance/radiance units, wavelength overlap and atmospheric corrections. An RGB or reversed-color image is a display product, not an independent spectral dataset. Without calibrated overlapping source data, the spectral feature is unavailable.

## 5. Mission profile and scoring model

Mission configuration has `target(s)`, `features[{id,weight,tolerance,required,min_quality}]`, `min_coverage`, `hard_constraints`, `user_scenario`, `site_count`, `max_budget`, `time_window`, and `analysis_mode` (`strict|exploratory`). Auto and Custom choose how parameters are initialized; both execute the same deterministic scientific engine.

For comparable feature i at candidate x and target t, define a documented normalized distance `d_i(x,t)` and mission tolerance `tau_i > 0`. A simple scalar feature score is:

`s_i(x,t) = max(0, 1 - d_i(x,t) / tolerance_i)`

This is an **engineering similarity heuristic**, not calibrated probability and not necessarily suitable for distributions; histogram distances or domain-specific distances must use their own documented tolerances. Weights must be nonnegative and sum to one. Do not mix independent units without normalization or combine related features without correlation review.

Let `O` be the subset of valid comparable features. Define:

- **Evidence coverage** `C = sum(w_i for i in O)`.
- **Observed-only score** `S_obs = sum(w_i*s_i for i in O)/C`, only when `C>0`.
- **Conservative contribution** `L = sum(w_i*s_i for i in O)`.
- **Possible upper bound** `U = L + (1-C)` under the explicit assumption all feature scores belong to [0,1].

`[L,U]` are mathematical bounds due solely to missing features, **not confidence intervals**. They must not be titled `95% confidence`. A required missing feature blocks a **strict** mission assessment. Exploratory mode may show scores qualified by C, L and U, alongside `not_verified`. Distinguish operational `PASS|FAIL|UNKNOWN` separately from scientific fit.

### Pro/con extraction

Generate pros from observed high feature contributions and mission thresholds; cons from observed mismatches or failed constraints; gaps from unavailable measurements; and limitations from non-reproducible physics such as lunar gravity/vacuum or Martian atmospheric composition. Every statement includes `evidence_ids`, method version and severity. Never have an LLM invent benefits.

## 6. Time-window analysis

For each Earth site, compute time-binned features from actually observed daily/8-day measurements. Match against a mission's accepted *environmental test requirements* (which might differ from literal Martian climate). For each period show `valid_days`, `available_days`, missingness, empirical suitability, extremes, and historic recurrence where data are adequate. A seasonal window is **a historical descriptive result, not a forecast**. Never claim a future day is guaranteed to reproduce another planet.

Illustrative pseudocode:

```python
valid = observations[observations["qa_passed"]]
monthly = valid.groupby(["site_id", "year", "month"]).agg(
    value_median=("value", "median"),
    valid_days=("date", "nunique"),
)
monthly["coverage"] = monthly.valid_days / expected_days
monthly.loc[monthly.coverage < min_coverage, "value_median"] = float("nan")
```

## 7. Scientific and operational feasibility are different gates

Scientific features determine fidelity for a *specified test objective*. Operational eligibility uses permits, protected status, travel access, required equipment, safety, available dates and budget. These can be **user-defined constraints or externally sourced, current, verified measurements**. A user-provided budget is a preference/constraint, not an Earth-observation fact. If permission is unknown, show `UNKNOWN`; do not silently treat it as granted.

Cost/effort estimates must provide currency, date, source, required people/equipment and scenario bounds. If absent, report a cost-free scientific ranking and a portfolio with **budget feasibility unknown**. Do not fabricate the lowest-cost result.

## 8. Portfolio selection and multi-objective trade-offs

A portfolio P is a set of eligible Earth sites that collectively covers the required Earth-based tests. Let test dimension j have priority a_j; let site i's lower-bound verified suitability for dimension j be q_ij. A simple coverage objective is:

`V(P) = sum_j (priority_j * max_site_suitability_for_dimension_j)`

Add a documented redundancy penalty to avoid selecting near-identical sites; apply source-backed or user-supplied costs only when available and comparable. Enforce hard max site count, budget, access and calendar constraints **before** optimizing. Multi-dimensional Pareto results should surface highest science, lower effort, lower cost *when cost is supported*, and robust alternatives. Do not collapse unknown costs to zero.

For a shortlist of ≤12 sites with max 3 sites, exhaustive combinations are small enough to enumerate reproducibly. At most 12 + 66 + 220 = 298 nonempty 1-to-3-site combinations. For large global pools use a documented optimization solver, bound scope and report whether the answer is optimal or approximate. A user requesting a second portfolio should reuse the exact same frozen source snapshot and exclude already-returned combinations, without rerunning NASA acquisition.

## 9. Robustness, validation and reporting

Tests required for a credible result:

- **Control sites:** compare against independently documented analog references and deliberately unsuitable candidates, with clear mission applicability.
- **Missingness:** remove mandatory fields and confirm strict ranking blocks; exploratory reports bounds.
- **Unit conversion:** Kelvin/Celsius, slope degree/radian, longitude direction, physical pixel sizes.
- **QA:** invalid MODIS fill/quality flags, SRTM voids, planetary label errors.
- **Sensitivity:** perturb approved feature weights, rerun, report rank range and selection frequency.
- **Source-family exclusion:** remove one family such as MODIS and see whether key claims survive.
- **Portfolio:** verify no duplicate observations counted twice, budgets respected, no unapproved site.
- **Repeatability:** pinned input snapshot, random seed (if used), method and code version yield the same output.
- **Offline:** disable *all* LLM credentials and all source endpoints, load a previously verified real-data snapshot and reproduce the results.

The result JSON must include scores, quality/verdicts, source-level evidence identifiers, time windows, pros/cons, uncertainty/missingness, disqualified candidates, candidate portfolios, model/source versions, and machine-readable methodology. PDF and UI views are pure renderings of the same frozen artifact.

## 10. Which tasks an AI agent can help, without contaminating results

| Agent role | Simple Analysis is responsible for | Optional AI may do |
|---|---|---|
| A01 | Source matching/query planning | Explain source relevance |
| A02 | Sensor-calibrated extraction | Qualitative visual description |
| A03/A04 | Rule-based cleaning and quality predicates | Explain unusual flags |
| A05 | Arithmetic from user-sourced rates | Explain assumptions |
| A06 | Feature extraction and comparison | Highlight already measured relationships |
| A07 | Join, dedupe, cross-domain synthesis | Readable factual synthesis |
| A08/A10/A11/A12 | Event integrity, portfolio constraints, release checks | Focused narrative only where allowed |
| A09/A13 | Claim evidence checks and report templates | Prose review and polish |

On provider `401`, `403`, `429`, outage, billing-required response, privacy mismatch or quota reserve: **skip optional AI, retain entire scientific result** and append an `AI_ENRICHMENT_SKIPPED` event. No result's scientific score changes because a free provider is unavailable.

## 11. Suggested functional interfaces

```python
acquire_source(query: SourceQuery) -> RawAsset
validate_asset(asset: RawAsset) -> QualityVerdict
decode_product(asset: RawAsset, profile: ProductProfile) -> TypedObservationSet
clean_observations(data: TypedObservationSet, rules: RuleSet) -> CuratedObservations
extract_features(data: CuratedObservations, scope: AOI) -> list[FeatureObservation]
compare_candidate(target: TargetProfile, earth: EarthSite, mission: MissionProfile) -> ComparisonResult
check_eligibility(site: EarthSite, constraints: Scenario) -> FeasibilityResult
rank_sites(results: list[ComparisonResult], scenario: Scenario) -> list[SiteResult]
build_portfolios(sites: list[SiteResult], scenario: Scenario) -> list[PortfolioResult]
sensitivity_check(results: list[SiteResult], scenario: Scenario) -> RobustnessResult
render_evidence_report(result: MissionResult) -> ReportArtifacts
```

**The data types named above are interface contracts to implement, not claims that the functions already exist in TwinSite.** API worker calls them through task boundaries; heavy geospatial processing belongs in the job worker, not synchronous FastAPI handlers.

## 12. Storage, cache and frontend contracts

Use immutable source files in object/persistent file storage, and Postgres/PostGIS for source IDs, job records, curated feature vectors, constraints, analyses and report manifests. Keep `raw_assets` and `cleaned_assets` as different versions, not silently overwrite the originals. Use a stable `run_id` across Analysis, Portfolios, Maps, Reports and Activity pages.

The no-login application must expose **read-only public agency datasets and sanitized run evidence** through controlled endpoints (`/datasets`, `/datasets/{id}/rows`, `/runs/{id}/features`, `/runs/{id}/events`). User upload artifacts must not be globally enumerable or searchable; use short-lived session/capability tokens and enforce access on server even without user accounts. Do not expose arbitrary database SQL or root database credentials in the browser.

**Cache invalidation:** input hash includes source product/asset versions, AOI, time window, feature method version, parameter hash, and code commit. Weight-only changes invalidate comparisons and portfolios but reuse acquisition and feature extraction. New source granules invalidate their dependent features. Report prose version changes invalidate only render artifacts.

## 13. Build order and acceptance

1. Create `FeatureDefinition`, `FeatureObservation`, `QualityVerdict`, `MissionProfile` and `MissionResult` contracts.
2. Test *one real Earth DEM + one real Mars/Moon DEM* with bounded, verified AOIs; check coordinates, units and QA.
3. Implement clean → features → strict evidence gate → per-feature comparisons → simple site ranking.
4. Add small-pool portfolios, missingness bounds, pros/cons and report template.
5. Wire FastAPI job, worker, persistent progress and read-only UI views.
6. Add POWER/MODIS environmental features and historical windows if product validation passes.
7. Only then enable optional consented AI annotations, summary and review.

**Go/no-go demonstration:** Given a pinned, measured source snapshot and AI globally disabled, TwinSite returns reproducible ranked candidates, reasons, at least one portfolio, uncertainty/gaps and an inspectable report. If this fails, optional agent work is not ready.

## 14. Scientific limitation statement

Simple Analysis provides **reproducible algorithmic decisions**, not automatic physical truth. A terrain similarity score needs mission-defined tolerances; observed Earth conditions do not reproduce lunar gravity, vacuum or Martian pressure; small-scale obstacles and lab measurements remain unavailable when data resolution/coverage is insufficient. Do not title a heuristic similarity as a calibrated "confidence percentage". Show source-quality, completeness and robustness as separate indicators.

## 15. Primary references

- NASA Earthdata search/CMR: https://cmr.earthdata.nasa.gov/search/site/docs/search/api.html
- NASA POWER daily service: https://power.larc.nasa.gov/docs/services/api/temporal/daily/
- NASA SRTMGL1: https://search.earthdata.nasa.gov
- NASA MODIS MOD11A2: https://ladsweb.modaps.eosdis.nasa.gov/missions-and-measurements/products/MOD11A2/
- NASA MOLA PDS: https://pds-geosciences.wustl.edu/missions/mgs/megdr.html
- NASA LOLA: https://pds-geosciences.wustl.edu/missions/lro/lola.htm
- NASA PDS search: https://pds.nasa.gov

See the earlier source-specific `ARES_Locked_Data_Architecture_2026-11-14.pdf` for the predecessor name and its data mapping. That scientific registry remains the baseline until a new product is actually validated. No real-data integration success is claimed in this document.
