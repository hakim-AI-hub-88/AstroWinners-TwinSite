# TwinSite | Agent and orchestration architecture

**Implementation specification 1.0 · 15 November 2026**  
**Scope:** the user's original 13-role pipeline, tightened for reliable science and free-only API use. **Orchestrator is not agent #14.** AI is an optional capability; a named role can execute without an LLM.

> **Mission invariant:** The numerical scientific truth is produced by validated data adapters and Simple Analysis. Agents can select sources, propose bounded operations, assess completeness and explain evidence. They cannot manufacture measurements, run unrestricted code, change mission weights silently, or override hard release gates.

![The 13 role pipeline](../diagrams/agents.svg)

## 1. Core vocabulary

| Term | Meaning | Persistence |
|---|---|---|
| **Mission** | One analysis request, target region(s), objective, data policy and constraints | `missions` row |
| **Run** | Versioned execution against a frozen configuration and data snapshot | `runs` row |
| **Phase** | Stable P00-P90 workflow milestone | `phase_runs` row |
| **Task** | Idempotent unit with typed inputs, result and resource budget | `tasks` row |
| **Agent role** | A01-A13 policy and schema, not necessarily a model instance | `agent_invocations` row |
| **Evidence artifact** | Immutable source, measurement, feature or validation finding | object store + artifact table |
| **Verdict** | Typed result of a quality or review rule; never a lone boolean | `verdicts` row |
| **Retry** | New bounded attempt of the same task, with reason and lease fencing | `task_attempts` row |
| **Optional AI enrichment** | Text/image annotation only; no scientific measurements | `ai_outcomes` row |

### P00-P90 phases

`P00 Register → P10 Acquire → P20 Decode/Visual → P30 Clean → P40 Quality Gate → P50 Characterize/Scenario → P60 Analyze 1 → P70 Synthesize/Analyze 2 → P80 Audit/Review/Judge → P90 Publish`.

- **P00:** Validate body/region, one site or zone per participating planet, mission objective, data policy, user-entered parameters and consent; freeze mission hash and dependencies.
- **P10:** Search bounded catalogs, acquire permitted granules, snapshot raw bytes/metadata with checksums. No global bulk downloads.
- **P20:** Decode calibrated instrument products; vision model may add *qualitative* annotations to supported imagery, clearly labeled as hypotheses.
- **P30:** Deterministic product-specific normalization and allowlisted repair; preserve raw values and transformation log.
- **P40:** Quality gates with `ACCEPT | REPAIR_ALLOWED | QUARANTINE | INSUFFICIENT` and issue codes. Repair loop max 2 attempts per asset by proposed default.
- **P50:** Derive features and link scenarios; costs/timelines/permits remain user inputs or evidence-backed external data, never invented.
- **P60:** Parallelize independent data **partitions**, not raw multimodal assets inside LLM prompts. Domain processors consume curated feature tables.
- **P70:** Combine evidence, identify relations and correlations, compute site/portfolio trade-offs. Analyze 2 is a distinct *cross-domain synthesis* rather than blindly rerunning all P60 prompts.
- **P80:** Three distinct reviewers check process, evidence and portfolio. A11 release decision; A12 one targeted recheck if warranted.
- **P90:** Freeze report, sources, results, logs, and front-end views. Publish qualifying claims only.

## 2. Responsibility matrix: all 13 roles

| Role | Assigned job | Canonical non-AI handler | When an external AI call is defensible |
|---|---|---|---|
| **A01 Source Curator** | Match mission features and AOI/time to approved datasets | Source registry + coverage predicates | Explain a *source selection*, with URLs and limits |
| **A02 Visual Interpreter** | Handle imagery/document annotations | Raster sensor decoder, image metadata, format parser | Describe visible patterns in consented images; **never infer physical measurements from display colors** |
| **A03 Cleaning Planner** | Identify specific cleaning rules needed | Rule mapper: product + issue → allowlisted transform | Explain ambiguous flags; may propose but never execute new code |
| **A04 Quality Reviewer** | Assess coverage, validity and repair action | Schema, QA, unit, coordinate and provenance predicates | Brief commentary on an exception; never approve a failed gate |
| **A05 Scenario Estimator** | Assemble operational scenarios | User-supplied rates + fixed arithmetic | Explain assumptions; cannot invent prices, permits or travel times |
| **A06 Domain Analyst** | Compute mission feature contributions by domain and partition | Numerical/geospatial Python functions | Summarize noteworthy patterns in a bounded evidence slice |
| **A07 Synthesis Analyst** | Join domain findings, conflicts, complementarity | Deduplication + weighted/constraint aggregation | Convert findings to a narrative with citations |
| **A08 Process Auditor** | Verify stage completion, chronology, missing tasks | DAG/event and artifact manifest assertions | **None necessary** |
| **A09 Evidence Reviewer** | Check report claims against supporting measurements | Structured claim-to-evidence checks | Independent language critique of already grounded claims |
| **A10 Portfolio Reviewer** | Check hard constraints, scenario stability and diversity | Recompute portfolio objective and feasibility | **None necessary** |
| **A11 Release Judge** | Final outcome: release/qualified/recheck/block | Deterministic gate policy | Optional *explanation* only, not decision authority |
| **A12 Targeted Rechecker** | Investigate one focused discrepancy | Redo one parser/feature/test with pinned input | Interpret unresolved documentary discrepancy if sources available |
| **A13 Report Writer** | Render evidence-based results and exports | JSON/HTML/PDF/CSV template renderer | Polish wording while numerical claims remain immutable |

**A06 fan-out:** one role, N task instances keyed by `(run_id, domain_id, spatial_partition_id, feature_set_hash, method_version)`. Do not confuse this with N different agents each independently inventing a conclusion. Partition by domain or geography only when records can be reconciled. One observation appearing in two partitions counts once unless it is intentionally reused for separate mission targets, in which case lineage preserves the shared source.

## 3. Canonical inputs and outputs per role

All A01-A13 outputs use the `AgentResult` schema in `../contracts/agent_result.schema.json`. Common required properties are `run_id`, `agent_id`, `phase_id`, `task_id`, `input_artifact_ids`, `output_artifact_ids`, `status`, `summary`, `evidence_ids`, `issues`, `proposed_actions`, `created_at`, `method_version` and `ai_used`.

| Agent | Critical input | Required output | Failure / guardrail |
|---|---|---|---|
| A01 | Approved source registry, AOI, time, requirements | Bounded `SourceQuery[]` with product IDs | No unapproved provider or global scrape |
| A02 | Image URI, sensor bands, processing level, consent if uploaded | `VisualAnnotation[]`, pixel/page references | Image-only labels cannot become numeric mineral claims |
| A03 | Product QA issues, allowed transforms | `RepairProposal[]` mapping issue code to rule ID | No arbitrary Python, CRS guessing or silent imputation |
| A04 | Cleaned candidate + QA report | `QualityVerdict` + unresolved issues | Quarantine on critical missing metadata |
| A05 | User rates/budget, external source IDs | Bounded scenario ranges or `unknown` | No fabricated or unqualified dollar figure |
| A06 | Validated Earth/target features by domain | Per-feature distance, similarity, evidence, gaps | No scores from absent features |
| A07 | Deduplicated findings, target weights | Cross-domain synthesis, trade-offs, conflicts | Check correlated features and double counting |
| A08 | Event stream, task manifests, leases | Chronology/completeness findings | Hard-block missing mandatory stages |
| A09 | Claim list and feature/source IDs | Supported/unsupported claims with severity | No unsupported explanations accepted |
| A10 | Portfolio candidates, budget/time/access constraints | Constraint checks, Pareto/robustness findings | Independently recompute key constraints |
| A11 | QA gates + three reviewer decisions | `RELEASE | QUALIFIED_RELEASE | TARGETED_RECHECK | BLOCK` | Critical gate failure forces BLOCK |
| A12 | One disputed finding and pinned snapshot | Focused check result; one recommendation | Bounded single issue; max one recheck initially |
| A13 | Frozen result artifact and citations | Report sections, exports, assumptions, gaps | Cannot mutate scores or source records |

## 4. Original user's Analysis 1 / Analysis 2 semantics

The user's initial blueprint specified two passes of the same analysis swarm with fresh instructions and memory, followed by a three-review process and a judge. **Preserved concept:** Two separate analytical concerns exist and the second can trigger a targeted repeat. **Default implementation:** P60 performs calculations once and P70 synthesizes their relationships. A fresh-prompt re-analysis is *not mandatory*, because it duplicates cost and creates correlated hallucinations; allow `SECOND_PASS_REQUIRED=true` only for a defined conflict or benchmark requirement. It uses the same frozen evidence, independent prompt version and a fresh context, but outputs *differences and open questions*, not replacement measurements.

The three reviewers are exactly A08/A09/A10, supported by the optional focused A12 rechecker. A11 decides based on fixed release policy. P90 A13 produces a reproducible report.

## 5. Orchestrator (separate, deterministic)

The orchestrator is a Python module/service within the backend worker, not a free-form LLM. Its responsibilities:

1. Maintain a versioned dependency DAG and emit durable progress/events.
2. Freeze mission inputs, target body/coordinate conventions, dataset versions and source hashes.
3. Assign idempotent task keys and partition work by bounded site/feature groups.
4. Enforce CPU/memory/network, token/neurons, disk, queue and provider limits.
5. Save immutable artifacts, provenance and quality verdicts atomically.
6. Manage retries with attempt count, bounded exponential backoff, no infinite reclean loops.
7. Detect stuck tasks using leases/heartbeats, and handle cancellation/restart without double publishing.
8. Gate P60 on accepted P40 data, P70 on required P60 outputs, and P90 on P80 release.
9. Apply privacy and provider consent before every external AI call, including fallback routes.
10. Provide front-end timelines from actual task progress, not model-generated percentages.
11. Keep a private provider-health/traffic log separate from user-facing scientific logs.
12. Reuse upstream artifacts when a user requests another portfolio based on the same measurements.

**Recommended MVP limits:** one active mission, two simultaneous source downloads, one raster/CPU-heavy job, one external LLM request, bounded queued runs. These are conservative starting settings, not measured VM limits.

### Retry decisions

| Failure | Action | Maximum |
|---|---|---|
| Transient source 5xx | Backoff, resume chunks, or use cached immutable snapshot | Fixed per-task budget |
| Provider 429 | Cooldown actual quota group; no within-bucket rotation | No immediate retry |
| Missing QA field | Product-specific fallback only if documented, else quarantine | 0 speculative repairs |
| Unit conversion mismatch | Verify declared original units; approved conversion | Two cleaning attempts overall |
| AI response malformed | Validate, bounded single constrained retry; otherwise template | Two attempts across providers |
| Critical scientific inconsistency | Focused deterministic replay; release BLOCK if unresolved | One targeted recheck |

## 6. Typed verdict and action system

**Quality status:** `ACCEPT`, `REPAIR_ALLOWED`, `QUARANTINE`, `INSUFFICIENT`, `FAILED`. `repair_required` can be derived for UI, but the stored verdict must preserve issue codes, severity, references and next rule. Explicitly track missing critical evidence; do not reinterpret an `unknown` feasibility as a `pass`.

**Review status:** `PASS`, `WARN`, `FAIL`, `UNKNOWN`. **Judge action:** `RELEASE`, `QUALIFIED_RELEASE`, `TARGETED_RECHECK`, `BLOCK`. The judge may lean toward release for *low-severity writing or stylistic issues* only. A critical invalid unit, missing required source or failed hard constraint never qualifies for release.

**Task states:** `PENDING`, `READY`, `LEASED`, `RUNNING`, `RETRY_WAIT`, `SUCCEEDED`, `FAILED`, `QUARANTINED`, `CANCELLED`, `SKIPPED`. Public UI reads those as a timeline with committed artifacts and attempts. All raw logs require redaction before display.

## 7. Evidence graph and independence

- All results point to a source dataset (provider, product, granule), file checksum, spatial AOI, observation time, QA flags and processing/version IDs.
- Agents must return evidence IDs, never only natural-language citations. `A09` rejects orphan claims.
- Different agents inspecting the **same source observation** do not constitute independent evidence. Deduplicate measurements by `(source_granule_id, feature_id, footprint_id, observation_time, algorithm_version)`.
- P70 performs a correlation audit where slope, ruggedness and roughness are derived from the same DEM, so they are not mistaken for independent support.
- Report a candidate's evidence completeness, uncertainty, stability under weight perturbations and known infeasible mission conditions separately.

## 8. Local versus external work

**Always local, no AI:** source download/validation; HDF/GeoTIFF/PDS4 decoding; numeric arrays and time series; reprojection; QA masking; feature extraction; scientific comparison; constraints; cost arithmetic; portfolio enumeration; visual charts and maps; process auditing; scientific release gates.

**Optional external AI:** qualitative photo text, ambiguous PDF prose summary, anomaly explanation, independent language critique and polished report prose. External providers cannot read user uploads unless explicit per-run, provider-specific consent exists. When consent is declined, local parsing continues; if the requested qualitative interpretation cannot be supported, label it unsupported.

**Zero-cost constraints:** all routes disabled until current free model/account/generation tests pass. Build must work with no inference credentials. The 13 roles may report `ai_used=false` while their deterministic handlers complete successfully.

## 9. Acceptance tests before opening TwinSite publicly

| Test | Expected outcome |
|---|---|
| Disable all AI keys, rerun pinned source snapshot | Same scores, portfolios and evidence-based report |
| Duplicate an entire A06 partition | De-duplicated results; no false confidence boost |
| Mask a mandatory PDS/DEM field | Quality gate blocks strict scoring and lists missing input |
| Swap slope unit degrees/radians | Unit conversion verified or quarantine, not silent match |
| Force all three review agents to disagree | Deterministic A11 applies severity policy and requests bounded check/block |
| Inject unrelated AI-generated numeric value | Evidence validator refuses it in feature table |
| Invalidate A03 repair rule | No code execution; quarantined input with issue code |
| Kill worker during portfolio stage | Job safely resumes or fails with recorded reason; no duplicate publication |
| Trigger 429 on one account and supply two keys from same quota bucket | Shared cooldown; no key circumvention |
| Upload image without provider consent | No external request; local fallback or clear unsupported outcome |
| User requests second portfolio | Reuse unchanged source/features; optimize alternative with excluded set |

## 10. Implementation assignment for Claude / Codex

**Workstream 1, data engineer:** implement P10-P50 adapters and validation; use actual product test granules. **Workstream 2, analysis engineer:** implement A06/A07/A10 deterministic scoring and portfolio functions with unit tests. **Workstream 3, backend engineer:** implement DAG task lifecycle, typed evidence records, persisted progress and safe routing. **Workstream 4, UI engineer:** mission setup, maps, results, portfolios, activity and source explorer using the same run ID. **Workstream 5, verification/reports:** P80 gates, P90 report template and real-data demonstration. No role should attempt to build all scientific domains without a validated source mapping.

**Build order:** frozen schema → bounded NASA acquisition → quality gates → simple analysis → report → frontend wiring → optional AI. Code review must verify every new feature preserves this order.

## 11. Source inputs and known limitations

This specification preserves the 13 roles listed in `ARES_NASA_Feasibility_Architecture.zip` / `docs/agent_registry.csv`, the user's two-pass and three-review requirements, and the consent/zero-paid budget decisions. The predecessor ARES acronym appears only in historical file paths; the current project is **TwinSite**. Runtime quotas, model availability and true scientific validity of individual candidate locations are not yet demonstrated by the inventory. No one may label the example dataset results as measured NASA science.
