# Package validation

## Completed checks

| Check | Result |
|---|---|
| Python regression tests | 39 passed under Python 3.9 and Python 3.12 |
| Numerical reproducibility | CLI and HTTP-worker outputs match for the fixture |
| Input/result schemas | Three JSON Schemas checked, request/result/quality examples validated |
| HTTP workflow | Submit, repeat, conflicting request, worker completion, events, result and report passed |
| Browser workflow | Required selection, explicit run, evidence report, alternative portfolio, Earth-first custom analysis, Earth/Mars zones, all portfolio modes and both map projections passed |
| Browser errors | Zero uncaught page errors in the successful workflow |
| Public NASA/partner probes | POWER, CMR, PDS search, MOLA collection, GIBS and CDSE catalog returned successfully |
| Official challenge resources | Eleven resource links recovered and inspected |
| Dependency research | Sixteen registry metadata records retrieved |
| Main report | 18 PDF pages rendered and visually inspected, with standalone HTML and editable Markdown |
| Diagram assets | Seven Mermaid sources and five rendered PNG diagrams |

The sample's top portfolio is synthetic A plus B. Six feasible portfolios were found under its configured constraints. The result includes 50 seeded weight-perturbation scenarios. `sample_run/result.json`, `sample_run/report.html`, `test_results.txt`, `checks.json`, `ui_checks.json` and `sample_ui.png` provide the corresponding artifacts.

## Corrections made during validation

Concurrent initial database setup exposed a SQLite journal-mode race. The unnecessary mode mutation was removed and a concurrent-initialization test now covers this path. A cross-version floating-point summation difference was resolved with explicit accurate summation. Browser checking exposed the unavailable current-version CDN bundle path, so the sample was pinned to the verified browser distribution. The UI completion message now waits until the corresponding result is displayed.

## Remaining verification

Authenticated source downloads, real model inference, provider account limits, production hosting, tenant authorization, source-driven scheduling, arbitrary document ingestion and scientific field-site suitability were outside the runnable sample's validation scope. Their design and implementation requirements are documented. The sample data is synthetic and the 23-hour roadmap assumes three concurrent contributors, with a reduced one-person path.

Archive extraction, local-link checks and SHA-256 verification are recorded in `archive_checks.json` after final packaging. The package checksum list covers all files other than the checksum list itself and the final archive-check record.

Selection regression checks cover at most one site-or-zone selection per body, automatic Earth comparison for Moon/Mars, explicit target choice for Earth, no direct Moon–Mars edge, two independent Earth comparison edges with distinct target values, exact target location matching, missing target evidence, Earth footprint filtering, invalid body/coordinate pairing, antimeridian bounds and idle startup. The three-body result retains one Earth anchor and separate Moon/Mars reference profiles in `three_body_run/`. The browser was exercised for Mars, Moon and Earth-with-both entry flows.

## Multi-location zone revision

Eight additional unit checks cover both analysis modes, standalone/combined/both output filtering, multiple reference locations, balanced body priorities, zone containment, dateline geometry, invalid selection kinds and infeasible combined-only requests. The synthetic zone fixture retains Earth candidates A/B/C and four planetary reference locations across Moon and Mars. `zone_run/result.json`, `zone_run/report.html` and `zone_ui.png` preserve the outputs. The browser exercised Earth and Mars zone entry and all three portfolio modes with no uncaught page errors.

The sample accepts rectangular zones and supplied observations. Freeform map drawing, real raster-derived candidate discovery, spatial field-site deduplication and route-aware shared costs remain documented integrations. These limits distinguish tested reference behavior from the full design.
