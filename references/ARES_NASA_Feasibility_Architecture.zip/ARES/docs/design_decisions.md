# Architecture decision record

| ID | Decision | Reason and consequence | Revisit trigger |
|---|---|---|---|
| D01 | One modular application with a dedicated worker | Fits the available integration time and keeps phase boundaries explicit | Independent scaling or deployment becomes necessary |
| D02 | Immutable raw objects plus versioned cleaned features | Supports repair, audits and replay without destructive updates | Retention policy changes |
| D03 | One relational database with logical layers | Simplifies consistency between tasks and artifacts | Different security or throughput requirements emerge |
| D04 | Deterministic scientific computation | Numerical outputs are inspectable and reproducible | A validated learned estimator outperforms a defined baseline |
| D05 | Two optional LLM runtime roles in MVP | Fits evaluation and token budgets | Role-level benchmarks establish incremental benefit |
| D06 | Typed findings and evidence IDs for all agents | Enables validation and rejection of unsupported claims | New modalities need extended evidence locators |
| D07 | Quality gates can block | Critical invalid evidence cannot support release | A domain owner changes a documented quality policy |
| D08 | Two safe repair passes maximum | Bounds cost and avoids repeated destructive changes | Empirical repair data supports another limit |
| D09 | No automatic unit or CRS guessing | Ambiguous inputs are quarantined for mapping | An adapter provides reliable explicit metadata |
| D10 | Missingness bounds and coverage alongside scores | Prevents a sparse record from gaining unexplained advantage | Validated probabilistic models are available |
| D11 | Eligibility gates precede preferences | Mandatory access and mission criteria remain enforceable | User selects an exploratory scenario with disclosed unknowns |
| D12 | Exact small-pool portfolio enumeration | Easy to audit and reproduce | Candidate pool or constraints exceed bounded execution |
| D13 | Cross-source deduplication before review | Avoids counting repeated agent outputs as additional evidence | Independent measurement identity is established |
| D14 | Shared quota buckets across credentials | Represents provider-level capacity correctly | Provider quota semantics change |
| D15 | Capability-tested model fallback | A route must preserve task requirements | Provider adds or retires a model |
| D16 | MapLibre Earth 2D/globe first | One map engine covers the initial navigation requirements | Planetary terrain or rich 3D Tiles become necessary |
| D17 | Controlled evidence views for user access | Preserves tenant authorization and query bounds | Research collaborators need governed bulk access |
| D18 | Local synthetic reference implementation | Delivers reproducible engineering behavior without hidden credentials | Validated source feature tables are ready |
| D19 | One selected site or zone per body with Earth-centered comparisons | Planetary selections automatically retrieve Earth analogs; Earth selections require target-body choices | User revises the comparison policy |
| D20 | Explicit first request after selection | Deployment initializes an idle application and creates zero analysis jobs | User requests a run |

| D21 | Separate target-location observation profiles | Retains every reference location within a zone and equal body priority | Target-priority policy needs extension |
| D22 | Bounded Earth catalog search | Controls automatic analog discovery workload while preserving multiple output candidates | Coverage and retrieval benchmarks justify expansion |

## Major unresolved decisions

The team must choose the exact rover test requirement, target location, AOI boundaries, approved target feature tolerances, source products, deployment platform, actual runtime model IDs, and the primary event resource used for eligibility. Suggested defaults in this package support rapid implementation and remain editable. A domain reviewer must approve any scientific claim of suitability or discovery.

## Zone extension decisions

A top-level selection may be a site or a multi-location zone. Candidate locations within the zone remain independently identifiable. Standalone and combined results are selected explicitly, with both as the default. The maximum sites parameter limits membership of a portfolio, while independent caps bound analyzed locations. Revisit sample rectangular geometry and equal reference-location weighting when validated polygon processing and a defensible spatial sampling policy are available.
