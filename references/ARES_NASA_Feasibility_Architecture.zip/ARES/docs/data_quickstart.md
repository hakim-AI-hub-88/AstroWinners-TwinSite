# Data quickstart and interpretation guide

## First scientific vertical slice

Start by selecting one small site or zone on a body, resolve the Earth–Moon or Earth–Mars relationship, then submit the request. For the first real-data slice, choose a rover-mobility objective with a selected lunar or Martian reference and a bounded Earth analog catalog. Earth-first users choose the target body explicitly; an optional exact planetary anchor overrides its disclosed preset reference. Define a physical comparison scale and terrain tolerances before collecting observations. Acquire one Earth elevation product and one planetary terrain product, then calculate slope and roughness distributions at a common supported scale. Add climate context only as an Earth operational feature. Retain footprints, quality masks and source time intervals.

### Earth terrain

The checked CMR query returned SRTMGL1 V003 under collection concept ID `C2763266360-LPCLOUD`. Its metadata reported acquisition during February 2000 and coverage from 56 degrees south to 60 degrees north. These details are preserved in `research/live_samples/cmr.json`. Polar candidates beyond that coverage need a different terrain product. Collection IDs and revisions should be resolved again when building a fresh snapshot.

```text
GET https://cmr.earthdata.nasa.gov/search/collections.json?short_name=SRTMGL1&version=003&page_size=1
```

The next query is a granule-search template. Its AOI is illustrative and it was not executed during package validation.

```text
GET https://cmr.earthdata.nasa.gov/search/granules.json?collection_concept_id=C2763266360-LPCLOUD&bounding_box=-6.1,30.9,-5.9,31.1&page_size=10
```

Inspect data links, provider authorization, quality documentation and completeness headers. Acquire a small relevant tile or supported subset. SRTM heights, horizontal sampling and vertical datum need product-aware handling before deriving terrain features. The metadata supplies a user-guide link and product DOI. [SRTM product DOI](https://doi.org/10.5067/MEaSUREs/SRTM/SRTMGL1.003)

### Planetary terrain

For a Mars reference, the MOLA collection identifier is `urn:nasa:pds:mgs_mola_topography_derived:data_meg128`. The research folder records the specific collection probe as well as a general PDS search probe. A label describes data type, scaling, map projection, body reference and the linked product. Select a small target area and retain the PDS product label with the bytes. [MOLA archive](https://pds-geosciences.wustl.edu/missions/mgs/megdr.html)

```text
GET https://pds.nasa.gov/api/search/1/products/urn:nasa:pds:mgs_mola_topography_derived:data_meg128
```

A lunar profile instead uses a selected LOLA terrain product and, where relevant, Diviner thermal data. A mission freezes every selected body and region. Multiple references retain separate profiles before an explicit aggregation step. Preserve that target's planetary geodesy even when Earth and target features are compared as numeric distributions. [LRO archive](https://pds-geosciences.wustl.edu/missions/lro/)

### Earth environment

The checked POWER request provides seven days of T2M and PRECTOTCORR at longitude -6, latitude 31, with UTC explicitly selected. Read units from the response parameter metadata and the source fill value from its header. The raw response is in `research/live_samples/power.json`. Seven days provide a connector demonstration. A seasonal decision needs a suitable longer record and a documented aggregation method.

```text
GET https://power.larc.nasa.gov/api/temporal/daily/point?parameters=T2M,PRECTOTCORR&community=AG&longitude=-6&latitude=31&start=20240101&end=20240107&format=JSON&time-standard=UTC
```

T2M represents near-surface air temperature. Surface-temperature comparisons should use a suitable surface product such as MODIS LST and account for quality, observation time and surface emissivity. A short historical weather extract cannot establish climatic suitability. [POWER daily service](https://power.larc.nasa.gov/docs/services/api/temporal/daily/) [MOD11A2 catalog](https://developers.google.com/earth-engine/datasets/catalog/MODIS_061_MOD11A2)

## Feature extraction recipe

1. Verify raw checksum, product identifier, variable name, body, CRS, acquisition time and units.
2. Decode scale/offset and quality flags from that product's documentation. Map declared fill values to null.
3. Choose a suitable local metric analysis grid for each body. Check horizontal and vertical references.
4. Select a comparison window large enough for the coarser supported source. Aggregate the finer data to that support.
5. Compute the feature using a fixed algorithm and record the algorithm version and window size.
6. Record observed coverage and uncertainty. Keep source pixels or product regions addressable through evidence IDs.
7. Validate a small area against an independent calculation or trusted tool before expanding.
8. Export feature observations and feed the deterministic mission scorer.

Slope and roughness at different window sizes are different features. Declare the neighborhood, interpolation and masking rules. An initial mobility profile can compare median slope and upper-tail slope separately, with their correlation considered when assigning weights. The sample's `slope_deg` and `roughness_m` are illustrative scalar descriptors with invented values.

## Understanding the sample in five minutes

`implementation/examples/mission.json` has three main fields. `data_status` identifies the demonstration fixture. `mission` defines canonical units, targets, tolerances, weights and constraints. `sites` contains coordinates, access state, scenario cost/days and observations.

For synthetic site A, slope exactly matches the target, roughness is four meters away from a three-meter target with a six-meter tolerance, and dry fraction differs by 0.3 with a 0.5 tolerance. Its lower utility is approximately 0.647. Site D has only the slope feature, so its weighted coverage is 0.45 and it fails the minimum coverage gate. Site E fails access despite ideal synthetic feature matches. A and B form the top sample portfolio through complementary coverage within the supplied budget.

The engine result includes contributions with source IDs, missing features, failures, site bounds, portfolio coverage vectors and scenario-selection counts. Read those fields before looking at a combined objective. The deterministic HTML report exposes the same result record for inspection.

## Product adapters to add after the MVP

Add NetCDF/xarray and HDF adapters for chosen thermal or environmental products, PDS4 adapters for selected planetary products, and a windowed Rasterio path for elevation or calibrated bands. Each adapter needs fixtures with source quality flags and known expected values. Add document extraction with page-level evidence after the numeric upload path is stable. Add a vision model only when a labeled validation set establishes the usefulness of its proposed feature.
