# Site selection and Earth-centered comparison

This document incorporates the final user clarification and governs the request contracts, pipeline, sample and UI. The user selects at most one small site or multi-location zone per body. A site is a bounded area with a stable ID, body, coordinate convention and version. Production supports a polygon or point with radius; the sample uses a small bounding box.

## Permitted journeys

| Starting selection | Additional choice | Comparison performed |
|---|---|---|
| One Mars site or zone | Earth is automatic | Earth candidate sites against its Mars reference locations |
| One Moon site or zone | Earth is automatic | Earth candidate sites against its Moon reference locations |
| One Earth site or zone | User chooses Mars | Contained Earth candidates against disclosed Mars reference locations |
| One Earth site or zone | User chooses Moon | Contained Earth candidates against disclosed Moon reference locations |
| One Earth site or zone | User chooses Moon and Mars | Separate Earth–Moon and Earth–Mars comparisons |
| One selected site or zone on each participating body | Earth remains the comparison center | One or both permitted Earth comparison edges |

There is no direct Moon–Mars comparison. The API also accepts one Moon anchor and one Mars anchor together: both automatically compare against Earth candidates in separate edges. Earth-only requests without a planetary choice are incomplete. Duplicate selected sites on a body are rejected. Optional selected planetary anchors override the corresponding preset reference; their evidence must resolve to the exact selected site or to reference locations contained within the selected zone.

## Single site or multi-location zone

The user may select a single site or a zone containing multiple locations. The previous one-site restriction now applies to the top-level selection per body: that selection can be a zone. A zone is a geographic search/analysis boundary; each contained location retains its own identity, measurements, eligibility and score. A portfolio can contain one location, several separate standalone recommendations, or a combination of multiple locations.

An Earth zone restricts eligible Earth candidate locations to that footprint. A planetary zone supplies multiple reference locations for Earth analog comparisons. Planetary-only selections automatically retrieve relevant Earth candidates from a recorded catalog. Both auto and custom modes use these rules. Auto uses versioned screening/default parameters; custom allows supplied observations, weights, tolerances, bounds and constraints. The sample evaluates supplied candidate/reference records. Automatic raster-based location discovery and polygon drawing remain integration tasks.

`portfolio_mode` controls the requested output: `standalone` ranks single-location options; `combined` ranks groups of at least two distinct candidates; `both` returns both categories. The default is both. `max_sites` is the maximum membership of one portfolio, independent of the number of locations in a zone. If only one candidate is eligible, a combined-only run returns no feasible portfolio. Never fill a requested group with an ineligible site. Explanations show individual merits, combined coverage, redundancy, cost and unresolved limitations.

Distinct field sites within a zone may be complementary portfolio members. Several sampled cells of the same field site are observations of that site, and must be consolidated before optimization to avoid artificial diversity or duplicated costs. Production uses canonical field-site IDs, overlapping-footprint checks and shared-access/travel models. The synthetic zone fixture contains three distinct candidate IDs in one Earth zone, with additive scenario costs; it does not demonstrate measured field boundaries or route costs.

A small planetary zone reduces target processing; an Earth analog search still needs a precomputed catalog, metadata screening and a capped shortlist. Record catalog version, eligible search regions, screening method, candidate cap, exclusions and retrieval completeness. Selected Earth footprints and planetary reference footprints use separate coordinate systems and queries.

Earth-first users choose Moon, Mars or both. When no exact planetary selection is supplied, resolve disclosed versioned reference locations from the mission preset. A selected planetary site requires its exact reference location; a selected planetary zone permits reference locations wholly within that zone. The sample uses explicitly synthetic references. Choosing the scientifically best planetary reference automatically requires later validation.

## Explicit start and shared workflow

Deployment initializes an idle application and zero jobs. A site choice prepares a draft. Both auto and custom analysis require a separate Run request. Auto fills supported mission defaults; custom accepts edited weights, tolerances, observations and constraints. Both use the same validation, quality, comparison, portfolio and report pipeline. Durable workers may resume an already submitted run after restart.

Freeze anchors, resolved target profiles, comparison edges, Earth search policy, data snapshots and parameters into the mission hash. Every task receives the scope hash plus its relevant anchor, target and candidate IDs. Source requests use the relevant planetary footprint or shortlisted Earth footprint and requested time interval. Shared tiles can include a documented computational halo. Never spatially intersect Earth candidates with lunar or Martian coordinates. Documentation retrieval must record its relevance to the selected mission.

## Comparison contract and aggregation

`scope.locations` contains 1–3 top-level selections, at most one per body. Each has `kind: "site"` or `kind: "zone"`; omitted kind means site for compatibility. If Earth is present, `scope.compare_with` must contain Moon, Mars or both. Otherwise it can be omitted or equal `["Earth"]`. `target_profiles` contains 1–12 reference-location profiles, covering every active target body. A profile carries its location, unit-bearing observations and source IDs. Location IDs are unique within each body. Reference boxes must be wholly contained in selected planetary zones; a single-site selection still requires an exact match.

The comparison matrix is Earth candidate × target body × reference location × feature. The sample gives each requested body equal total priority, splits that priority equally across its reference locations, then applies normalized base feature weights. Adding more sampled locations on one body does not automatically increase that body's overall priority. For one profile on a body, keys retain `Body/feature`; multiple profiles use a JSON tuple string `[body, location_id, feature_id]` to avoid collisions. Contributions expose those identities separately plus both source IDs. Required missing reference evidence fails eligibility, while optional missing comparisons reduce coverage. Production may use quality/area-aware reference weights, but must disclose them and account for spatial correlation.

The optimizer evaluates allowed standalone and combined candidate sets under budget, duration, eligibility and membership constraints. `portfolios` contains the best ten requested alternatives overall; `standalone_portfolios` and `combined_portfolios` each retain up to ten so both categories remain inspectable. Each item has a `kind`. The sample maximizes target-feature coverage with cost and redundancy penalties. A combined score is computed for the group; it is not a sum of individual ranks. Production adds per-reference mandatory coverage gates when every location must be served. Earth fieldwork costs are counted once per canonical site; space mission costs are outside this budget.

Changing the selection, reference locations or output mode creates a new mission version. Production reuses compatible source features and recomputes affected scoring/optimization stages. Optional monitoring still requires explicit activation. Sensitivity frequencies remain descriptive, and shared spatial observations require a correlated uncertainty model before probability claims.

## Workload limits and maps

Sample limits: up to 3 anchors, up to 12 planetary reference-location profiles, 12 Earth candidates, 12 base feature definitions, 3 portfolio members and 50 sensitivity scenarios. Bounding boxes span over zero and at most two degrees per axis; bundled single sites span 0.1 degree and the Earth zone spans one degree. These are software demonstration limits. Production uses physical area, decoded pixels/bytes, resolution, source coverage and time window. A small AOI cannot recover detail absent from a coarse source. Dateline bounds need split queries or wrapped polygons; polar geometry needs body-appropriate projection.

The UI starts with no selected radio button and a disabled Run action. Earth entry additionally requires a planetary checkbox. Planetary entry automatically selects the Earth comparison relationship. The map displays Earth candidates; the report displays planetary reference bounds separately. Lunar/Martian 2D and 3D selectors remain planned integrations. The API accepts all allowed site/zone configurations. The minimal UI offers a single-site or multi-location-zone example, portfolio output mode, and one primary selection; remaining targets use disclosed profiles. Custom zone coordinates can be submitted through JSON/CLI. Interactive freehand/polygon selection remains a production UI task.

## Updates and acceptance

Changing an anchor, target choice or preset creates a new scope and invalidates dependent tasks. Weight-only changes reuse source features in production. Another-portfolio requests preserve the snapshot and exclude prior sets. Optional monitoring begins only after explicit activation and follows the frozen comparison/search policy. Startup never launches the first analysis.

Regression checks additionally cover multi-location zones in both analysis modes, reference containment, output-mode filtering, equal target-body weight with unequal reference counts, dateline zones and empty combined results. Earlier checks cover automatic Earth comparisons for Moon/Mars, explicit Earth target choice, duplicate body rejection, direct Moon–Mars rejection, both Earth edges with distinct target values, missing target evidence, exact target location matching, Earth footprint restriction, dateline crossing and idle startup. These verify software behavior using synthetic observations. Scientific suitability still needs source validation and domain review.
