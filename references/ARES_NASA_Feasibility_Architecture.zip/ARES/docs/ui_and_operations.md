# UI and operating runbook

Deployment shows an idle location selector. Both modes require a selected site or zone and explicit Run request. At most one site-or-zone selection per body is allowed. Moon/Mars selection automatically compares Earth analogs; Earth selection requires Moon, Mars or both. The only edges are Earth–Moon and Earth–Mars.

## User journeys

### Auto-analysis

Choose one bounded site or zone per participating body and the allowed Earth-centered comparison relationships, select a versioned mission preset, inspect the scoped data snapshot, explicitly start a run, follow phase progress, and inspect the first portfolio. The results show coverage, operational status, quality findings and source links. Requesting an additional portfolio preserves upstream artifacts and excludes previously returned sets. A source-update refresh creates a new mission version with a comparison to its predecessor.

### Custom analysis

Choose bounded locations first, then choose a preset as a starting point or define a supported objective. Adjust tolerances, weights, budget, duration and required features. Select the shared cleaned snapshot or upload a supported dataset. The upload preview shows inferred column mappings for confirmation, required units and rejected rows. User choices can resolve ambiguous mappings. Mandatory validation still applies. The same scoring and reporting path then runs.

## Screen specification

| Screen | Primary controls | Required feedback |
|---|---|---|
| Mission Setup | Bounded locations, bodies, mode, objective, scenario and data selection | Validity of configuration and estimated workload |
| Explorer | Map, filters, sorted list and layer dates | Source resolution, missingness and selected site footprint |
| Site Evidence | Feature values, source references, contribution plots | Unknowns, comparison scale and quality flags |
| Portfolio | Site-set alternatives, budget and coverage matrix | Gaps, operational assumptions and scenario stability |
| Mission Activity | Phase timeline, event details and artifact list | Queue state, retry count, completion units and errors |
| Operator Health | Provider routes, worker status and storage | Quota cooldowns, disabled credentials and failure trends |

Use a restrained high-contrast layout with Inter or the application's existing font, accessible focus rings, a colorblind-friendly sequential scale, and icons accompanied by text. Use visible labels for unknown, synthetic, measured and estimated values. Scores should have sensible precision, generally two decimals for similarities and whole percentages for coverage. An editable table provides equivalent map selection for keyboard and screen-reader users.

## Map implementation

Use the site's Earth GeoJSON point or AOI polygon as the selection object. A point preview represents an AOI centroid. The detailed view renders the full footprint. Use a consistent legend and common feature scale when comparing sites. GIBS layers come from capabilities. Log the layer ID, date and tile matrix set used in a report screenshot.

The sample map uses a MapLibre globe toggle and the library's demonstration basemap. It requires internet access for those assets. Production should select an appropriately licensed and provisioned basemap, retain attribution, and package the library through the frontend build. A globe preview provides geographic navigation. DEM terrain and Moon/Mars mapping remain later integrations.

## Incident handling

| Symptom | Operator action | User result |
|---|---|---|
| Data provider unavailable | Reuse a valid cached snapshot or defer acquisition | Show source age and pending refresh |
| Model provider unavailable | Use deterministic report template | Scientific scores remain available |
| Repeated cleaning failure | Quarantine affected asset and inspect rule ledger | Explain coverage loss or blocking feature |
| Worker died | Reclaim expired lease with a new attempt | Show recovery event and updated estimate |
| Database unavailable | Stop new tasks and retain uncommitted temp artifacts | Retryable availability message |
| Storage nearly full | Pause acquisition and remove expired temp objects | Existing committed evidence remains readable |
| Credential invalid | Disable the credential and alert operator | Use another eligible route or defer |
| No feasible portfolio | Return causes and closest exploratory alternatives | Explain which constraints cannot be met |

## Hour-zero readiness check

Confirm the registered event's submission requirements, chosen NASA resource, actual remaining clock time, team owners, VM memory and persistence, deployment rights, and provider entitlement. Test one tiny request per enabled route. Record the exact returned model IDs and quota scope. Set an application spend ceiling before enabling paid calls.

## Submission verification

Freeze code and data versions. Include attribution and a concise limitations section. Demonstrate one actual calculated result, one rejected candidate, and one change in scenario. Export a report and preserve a short recording for network failure. Submit through the official event interface and save confirmation. This package does not submit a project on the team's behalf.

## Multi-location zone controls

Offer single-site selection or a zone containing multiple locations. Production supports drawing/editing a body-aware boundary with an area/workload preview, then showing proposed candidate footprints and exclusions. Auto mode uses a documented mission preset; custom mode exposes supported parameters and input mappings. Both require Run. Show individual candidate evidence alongside standalone and combined portfolio lists, including membership, constraints, coverage, redundancy and cost. `max_sites` controls each combination. The current browser sample supplies prebuilt site/zone choices; freeform map drawing remains planned.
