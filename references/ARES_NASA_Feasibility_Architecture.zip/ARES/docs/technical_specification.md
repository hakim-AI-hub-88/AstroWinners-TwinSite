# ARES technical specification

The selected-location workflow in `selected_location_workflow.md` governs every phase. Initial deployment is idle. An explicit user request freezes at most one site-or-zone selection per body, resolved target profiles and permitted Earth comparison edges before analysis is scheduled. Earth search can use a bounded catalog automatically when a planetary site is selected.

## 1. Execution and storage model

The production topology consists of a static frontend, an authenticated API, a durable worker, Postgres/PostGIS, and an artifact store. One VM may host the API and worker as separate processes. Deploy the database and files on persistent storage. Give the worker its own CPU and memory allowance. The sample implements a local HTTP adapter and SQLite job store to keep setup reproducible with the Python standard library.

The principal relations are sources, assets, transformations, feature_observations, mission_specs, mission_anchors, mission_comparisons, snapshots, tasks, task_attempts, events, findings, portfolios and reports. A snapshot freezes source revisions, feature versions, target profiles, comparison edges, Earth search policy, mission configuration, algorithm version and model routes. Asset bytes live outside relational rows. Store immutable object references and SHA-256 digests in rows.

Acquisition writes to an attempt-specific temporary object, hashes the downloaded bytes, validates length and expected content type, and moves the object into a content-addressed location. A database transaction publishes the manifest. A periodic collector removes unreferenced temporary objects after a retention interval. Retries can reuse the same verified digest. Published records cannot refer to partially written files.

## 2. Phase contracts

| Phase | Required input | Committed output | Failure and invalidation |
|---|---|---|---|
| P00 Register | MissionSpec with bounded selections, user request, actor and idempotency key | Mission ID and frozen scope/input hash | Invalid units, unknown feature or inconsistent budget returns 422 |
| P10 Acquire | SourceQuery, AOI, time and byte ceiling | AssetManifest with source revision and hash | Retry transient transport, stop on unauthorized access |
| P20 Decode | Manifest and adapter version | Typed observation batch and extraction evidence | Unknown product or encoding quarantined |
| P30 Clean | Observation batch and rule registry | New cleaned version and transformation ledger | Preserve raw snapshot and stop unsafe repair |
| P40 Quality Gate | Cleaned version and quality policy | QualityVerdict and accepted snapshot | Two repair passes maximum, then quarantine |
| P50 Characterize | Accepted data, target and feature registry | FeatureObservation records and scenario assumptions | Required feature absence blocks eligible status |
| P60 Analyze | Feature records and mission preferences | SiteResult, contributions and missingness | Recompute on target, weights or feature change |
| P70 Synthesize | Unique SiteResults and constraints | PortfolioResult alternatives and sensitivity | Empty feasible set is a valid result with causes |
| P80 Review | Artifact manifest and findings | ReviewSummary with blocking issue IDs | Targeted retries have bounded scope and budget |
| P90 Publish | ReleaseDecision and artifact hashes | Immutable report and result manifest | Commit only after final invariant checks |

A phase output is valid only when schema version, mission ID, snapshot hash and required references agree. Store schema validation errors as structured findings. Data from separate snapshots cannot be merged by the reviewer merely because site names match.

## 3. Agent coordination

Specialty workers own a domain such as terrain, thermal behavior, spectroscopy or field operations. Partition computation by stable spatial cell and product/time range. When neighboring pixels are required, read a documented halo and discard duplicate halo outputs. Global statistics use an explicit reduction step. Each partition records its expected membership and coverage count so dropped work is detectable.

An analysis agent receives an ArtifactBundle containing compact statistics, validated evidence references, the mission profile, the quality verdict and allowed actions. It receives a token-limited extract of relevant data. Raw rasters remain behind approved analytical functions. The agent response must follow the AgentFinding schema and refer only to supplied evidence IDs. Outputs are rejected for unknown IDs or unsupported numerical claims.

The process auditor checks required-task completion and dependency chronology. Evidence Reviewer A09 and Portfolio Reviewer A10 inspect distinct responsibilities and a small shared sample to detect inconsistent interpretation. A11 Release Judge consolidates findings and requests A12 Targeted Rechecker for a specific unresolved question. The release gate enforces mandatory invariants even when the judge recommends continuing.

Memory is run-scoped. Each analytical pass gets a new structured input bundle with the prior artifacts explicitly included. Persist prompts, route/model identifiers, visible output and tool summaries when policy permits. Record reproducibility limits for nondeterministic generation. Repeatable numerical results come from the deterministic engine.

## 4. Job state machine and recovery

States are queued, running, retry_wait, succeeded, failed, cancelled and quarantined. Quarantined applies to data tasks. A job moves from queued to running through an atomic claim. The claim increments an attempt counter and sets worker ID, lease deadline and fencing token. Each state transition appends an event in the same transaction.

Production workers heartbeat every 15 seconds with a 90-second lease as a starting policy. A worker may commit only if its token still matches the task row. Reclaim only expired leases. A late worker's commit is rejected. Limit attempts per task and total attempts per mission. Cancellation sets a flag checked between bounded chunks and before commit. Already committed artifacts remain available for inspection.

An idempotency key is scoped to user and endpoint. The request hash is derived from canonical JSON. Same key and same hash returns the existing mission. Same key and different hash returns 409. Keep idempotency records at least as long as the retry window. Snapshot identity is independent of idempotency identity.

After explicit activation for a selected scope, production source schedules poll revision metadata with overlap windows and deduplicate product versions. Preserve both last attempted and last completed watermarks. A failed scan cannot advance the completed watermark. Debounce changes for the same snapshot and allow one outstanding refresh per mission preset. Conditional requests may reduce traffic where providers support them.

## 5. Provider routing contract

Route selection uses the configured ordered list after filtering for task capabilities, input confidentiality, model availability, quota reservations and monetary budget. Each route has a provider, credential alias, quota_group, model ID, endpoint, deadline, maximum input and output tokens, allowed modalities and breaker state. Secret values remain outside route files.

| Failure | Routing action | Logging and retry |
|---|---|---|
| 400/422 malformed request | Return caller error or repair approved schema once | Preserve validation details without payload secrets |
| 401 invalid credential | Disable credential and consider next authorized credential | Operator event and credential alias |
| 403 entitlement or policy | Disable affected route pending diagnosis | Avoid repeated attempts with equivalent credentials |
| 404 retired/missing model | Refresh allowed model registry and canary fallback | Record previous and replacement model IDs |
| 408/network/5xx | Bounded retry with full jitter, then alternate eligible route | Maximum total attempts per task |
| 429 request/token limit | Respect Retry-After and pause quota group | Shared limiter across all keys in that group |
| 429 daily/spend limit | Defer or select independently authorized budgeted route | Flag quota exhaustion with reset estimate |
| Invalid structured output | One schema repair, then capability-tested fallback | Count against the same task budget |
| Context too large | Reduce retrieval bundle or split by validated partition | Preserve required evidence, never silently truncate |

Implement token reservation before dispatch. Reserve estimated input plus maximum output, then reconcile with actual usage. Hold a conservative reservation if usage is unknown after timeout. Treat Retry-After according to each provider's format and units. HTTP Retry-After may be seconds or a date. Adapter-specific retry fields require parsing from documented response structures.

Use three consecutive transient failures to open a circuit for an initial 60-second cooling period, then permit one half-open canary. These are tunable ARES defaults. A model canary checks a tiny typed response, evidence-ID retention and required modality. A new route must pass the same application contract as the primary route. Mid-task provider changes create a new attempt and attach a route-change event.

The sample routing module is a deterministic policy demonstrator. It returns decisions and cooldowns. Provider HTTP adapters, distributed token reservations and real inference are integration work. No provider accounts were available to verify actual inference or billing limits.

## 6. Capacity plan

Start with 12 Earth candidates, three feature families, one or two target bodies with up to 12 reference-location profiles, at most three sites per portfolio, 50 MB of CSV uploads, and selected raster windows capped at 512 MB decoded per worker. The local sample has a smaller 1 MB HTTP request ceiling and 12 candidates. These limits are application defaults, independent of provider limits.

A 2048 by 2048 float32 band is about 16 MiB. Six such bands occupy 96 MiB before masks, reprojection buffers, Python overhead and intermediate arrays. Reserve at least four times the raw window bytes as an initial memory estimate and measure actual peak RSS. A modest 2-vCPU, 4–8 GB VM is a starting engineering target for small windows. A low-memory free host should use precomputed features and small JSON payloads.

LLM budget example uses 12 candidate summaries × 1,500 input and 300 output tokens, one synthesis at 6,000/1,000, and three reviews at 3,000/500 each. The total is 33,000 input and 6,100 output tokens before retries or image tokens. Cost equals input_tokens/1e6 × published_input_price plus output_tokens/1e6 × published_output_price plus tool and image charges. Capture actual model prices and hard app limits before enabling routes. This token estimate is a capacity scenario.

Avoid feeding the full raw/cleaned database to a model. The largest artifacts should move once into storage and be referenced thereafter. Use windowed COG reads when the endpoint supports range requests. Store feature tables as Parquet for scale and JSON for compact API responses. Deduplicate requests by native data cell and observation period.

## 7. Data and estimate dictionary

Every FeatureObservation records its selected anchor or derived candidate ID, scope hash, feature ID, site/AOI ID, body, value or null, unit, uncertainty representation, support geometry, nominal resolution, acquisition interval, source asset IDs, quality codes, method/version, missing reason and transformation IDs. Estimates additionally carry basis, currency/base year where relevant, low/central/high values, and assumed dependencies.

Earth GeoJSON uses longitude then latitude in WGS84. Planetary geometry is a body-specific record with explicit CRS and conventions. Earth GeoJSON cannot implicitly describe Mars or Moon coordinates. Site identity uses a stable ID plus geometry version. Name similarity may suggest a match but spatial joins and record provenance establish it.

Observation time, source publication time, ingestion time and analysis time are separate timestamps. Time zones and local solar time are explicit. Climatic normals, dated observations and forecasts have separate feature meanings. Reports must disclose the validity window of any operational forecast and the climatological period of longer-term comparisons.

## 8. Frontend-to-backend interactions

POST `/v1/missions` returns an accepted mission and status URL. GET `/v1/missions/{id}` returns state and summary. GET `/v1/missions/{id}/events?after=N` returns cursor-ordered events. GET `/v1/missions/{id}/result` returns a committed result or a pending response. POST `/v1/missions/{id}/alternatives` creates a new optimization request referencing the same snapshot. GET `/v1/assets/{id}` returns authorized metadata and a signed download when allowed.

The browser uses server-validated constraints. Slider changes can preview locally but committed rankings come from the backend. Every displayed result carries the snapshot and algorithm version. When data refreshes, preserve the old result and offer the new version explicitly. The activity view uses event cursors so reconnecting users do not lose status changes.

The sample exposes missions, events, result and example routes under its documented smaller API. API-contract.md distinguishes sample endpoints from planned endpoints. Custom JSON uses the same engine as the bundled example. CSV import is available through the CLI. Document uploads and authenticated user isolation remain production work.

## 9. Security and observability implementation

Production authentication can use the hosting provider's OIDC integration. Map verified subject to tenant and role. Apply object-level authorization to each resource. Use parameterized SQL and schema limits. Signed artifact links expire and expose only the requested object. The operator log contains provider aliases and health events, with authorization headers and query-string secrets removed.

Parsers run with restricted filesystem access, no network and explicit CPU/memory/time budgets. Document extraction preserves page and table references. Disable XML entity expansion and follow no document-embedded URLs. CSV uploads require a mapping step and preview. Extension checks are supplemented by content checks. Source download adapters validate both hostname and resolved address after redirects.

Emit mission.created, task.started, task.retry_scheduled, data.quarantined, route.disabled, quality.failed, artifact.committed, mission.completed and mission.failed events. Each includes a trace ID, timestamp, schema version and safe summary. The event store is authoritative for progress. Telemetry exporters may sample traces without dropping required audit events.

## 10. Testing and release guide

Test fixture calculations by hand for one site and one portfolio. Test missing values, zero weights, invalid units, NaN/infinity, duplicate site IDs, source duplication, impossible budgets, hard failures, unknown access, alternative exclusion and deterministic seeds. Test idempotency conflicts and queue replay. Inject provider 429 and 401 decisions. Keep scientific validation and software validation recorded separately.

For deployment, run the worker under a supervisor with persistent storage, configure authentication at the API, load only authorized secrets, execute public-source canaries, and run a frozen mission. Restart the worker and confirm recovery. Load-test with the intended number of users and record peak memory and provider calls. Freeze exact code, environment, data and prompt versions for the demonstration.

## Primary technical references

- CMR pagination and throttling are documented by NASA. [CMR](https://cmr.earthdata.nasa.gov/search/site/docs/search/api.html)
- Atomic queue claims can use Postgres locking. [Postgres SELECT](https://www.postgresql.org/docs/18/sql-select.html)
- Task acknowledgement and idempotency semantics need explicit configuration. [Celery tasks](https://docs.celeryq.dev/en/stable/userguide/tasks.html)
- Heavy scientific computation needs appropriate execution isolation. [FastAPI](https://fastapi.tiangolo.com/tutorial/background-tasks/)
- Current provider quota scopes determine failover capacity. [Gemini](https://ai.google.dev/gemini-api/docs/rate-limits) [OpenAI](https://developers.openai.com/api/docs/guides/rate-limits) [Claude](https://platform.claude.com/docs/en/api/rate-limits)

## Zone processing extension

P00 freezes site/zone kind, geometry, selected bodies, portfolio mode and workload caps. P10 queries the Earth zone or capped Earth shortlist plus relevant planetary zones. P50 partitions each zone into supported candidate/reference locations and preserves their footprint and parent selection ID. P60 emits the candidate/reference/feature matrix; P70 enumerates standalone or combined sets according to the requested mode. P90 publishes both categories when requested. Every stage remains identical for auto and custom modes after input/default resolution.

Keep spatial resolution and physical support explicit when proposing locations. Candidate records are distinct field-site entities, not arbitrary raster pixels. Deduplicate spatially equivalent sites, consolidate subsite measurements and estimate shared logistics before claiming portfolio diversity. Small-zone boundaries can contain many high-resolution cells: budget candidate counts, raster windows and pairwise comparisons as well as area. The sample uses supplied point candidates, rectangular reference footprints and twelve-reference/twelve-candidate caps. Production polygon support and sampling-quality validation remain required.
