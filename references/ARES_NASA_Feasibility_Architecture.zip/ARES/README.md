# ARES feasibility and architecture package

Prepared 14 November 2026 and revised for the final selected-location requirement. ARES accepts at most one selected site or zone per body. Moon/Mars selections automatically compare with Earth analogs; Earth selections require Moon, Mars or both. It returns Earth candidate portfolios and evidence reports. Both modes start after location selection and an explicit request.

Read `docs/selected_location_workflow.md` for the updated scope and start behavior.

## Start here

1. Read `ARES_Report.pdf` or `ARES_Report.html` for the feasibility verdict, architecture, scientific method, and 23-hour plan.
2. Use `docs/requirements.csv`, `docs/agent_registry.csv`, and `docs/roadmap.csv` to divide implementation work.
3. Read `docs/data_quickstart.md` for concrete source queries and sample interpretation. Read `docs/technical_specification.md` for execution, security, retry, and data-contract details.
4. Run the sample under `implementation/`. Its README states exactly what runs and what needs implementation.
5. Review `research/api_inventory.csv`, `research/sources.csv`, and `research/api_live_validation.json` before selecting integrations.
6. Inspect `validation/validation_report.md` for the checks performed on this package.

## Scope and assumptions

The requested 23 hours is treated as an engineering time budget. Staffing is assumed to be three people who can work concurrently. With one person, follow the reduced plan in the report. Hosting access and AI subscriptions came from the referenced conversation. Their quotas, balances, and deployment capabilities were unavailable for authenticated verification.

The package contains a runnable deterministic sample and a full-system design. The synthetic fixture demonstrates calculations and failure behavior. Its coordinates and measurements do not establish real analog suitability. Public API probe responses provide genuine source-access evidence separately. A scientific field-site ranking still requires validated Earth and planetary measurements.

## Directory guide

| Directory | Contents |
|---|---|
| `docs` | Technical specification, decisions, requirements, roles, roadmap, UI and operations |
| `diagrams` | Editable Mermaid diagrams and rendered architecture/pipeline diagrams |
| `contracts` | JSON Schemas, examples, SQL and HTTP contract |
| `research` | Primary-source register, API/dependency inventories and live probe records |
| `implementation` | Runnable Python sample, local web interface, source connector and tests |
| `validation` | Execution results, deliverable checks and archive integrity record |

All local links use paths relative to this package so it can be moved after extraction. The report has a standalone HTML version with embedded diagrams and a printable PDF.
