# ARES
## NASA Space Apps feasibility and architecture

Research snapshot · 14 November 2026 · Engineering window · 23 hours

### Executive verdict

ARES is technically achievable as a staged decision-support platform. A credible 23-hour deliverable consists of one mission profile, one selected site or multi-location zone per participating body and Earth-centered comparisons, a reproducible feature pipeline, explicit data-quality gates, deterministic site and portfolio scoring, an evidence report, and an interactive map. The complete autonomous multi-agent system, arbitrary document interpretation, global imagery analysis, validated field logistics, and exhaustive scientific assurance exceed this window.

The proposed implementation should use one application, one durable job worker, and modular analytical functions. Two optional language-model roles can summarize evidence and review explanations. A larger swarm becomes useful after shared contracts, validated measurements, and reproducible scoring exist. Accounts alone do not determine runtime capacity. API access, model permissions, quotas, compute, and integration time determine practical throughput.

The official 2026 event page lists November 14–15 and submission closure on November 15 at 11.59 PM local time. This roadmap uses the requested 23 hours from the team's actual start. The official challenge asks participants to identify and characterize terrestrial analogs using Earth, Moon, and Mars data. The official challenge body and its 11 resource links were recovered through a direct HTML request after the initial web-reader error. The resource list is preserved in research/challenge_resources.csv. Confirm local event requirements in the registered event interface before submission. [Event schedule](https://www.spaceappschallenge.org/2026/) [Challenge](https://www.spaceappschallenge.org/2026/challenges/permanent-moon-base-locations-and-mars/)

### How to interpret this package

Provider facts have linked primary sources. Proposed numerical budgets, scoring functions, thresholds, architecture choices, and staffing estimates are ARES engineering decisions. Public requests were tested and recorded in `research/api_live_validation.json`. Documentation review establishes a published interface. A successful metadata response establishes only that specific request. Authenticated model inference, large downloads, and deployment quotas remain unverified.

The sample demonstrates deterministic scoring, data rejection, portfolio diversity, mission persistence, progress events, and an offline report. Its measurements are synthetic. Actual source responses are preserved as separate research samples. This package supplies the plan and sample implementation requested. It does not constitute completed scientific validation of candidate regions.

## 1. Product definition and scientific boundary

ARES characterizes one selected site or zone per participating body, explains mission relevance, and compares Earth with Moon, Mars or both. Selecting a Moon or Mars site automatically retrieves relevant Earth analog candidates. Selecting an Earth site requires the user to choose Moon, Mars or both. Earth–Moon and Earth–Mars are the only comparison relationships. Outputs retain evidence reports, pros and cons, scenarios and complementary Earth candidate portfolios.

An analog is purpose-dependent. A site useful for traversability tests can have weak mineralogical similarity. A cold-arid site can support operational rehearsals while offering limited fidelity to planetary pressure or gravity. Represent mission objectives independently, including mobility, geological sampling, resource prospecting, habitat operations, and communications. Each objective has features, tolerances, required evidence, and excluded inference types.

Every analysis begins with a site or zone choice and an explicit Run request. Both custom and auto-analysis use this same trigger and workflow. Deployment opens an idle selection screen and creates no analysis jobs. At most one site-or-zone selection may be made on each body; a selected zone can contain multiple locations. A run may include all three bodies as two separate Earth-centered comparisons. If an Earth-first user chooses a planetary body without an exact target site, the system resolves disclosed, versioned preset reference locations on that body. A selected planetary anchor takes precedence over its preset.

A selection may be a single site or a zone with multiple locations. Each contained location retains its evidence and individual score. Auto mode uses the mission's default screening and parameters; custom mode uses supported user inputs. Earth zones bound the candidate pool. Moon/Mars zones provide separate reference locations for Earth analog comparison. The system can return standalone candidates, combined multi-location portfolios, or both. A portfolio's membership limit is separate from the number of locations analyzed in the zone.

Planetary-only selections automatically search a recorded Earth catalog. Use a precomputed index and bounded shortlist for the hackathon. Small target geography does not by itself make global Earth imagery processing cheap. Record catalog version, screening criteria, search limits and omissions. A supplied shortlist demonstrates comparison; scientific discovery needs validated retrieval and feature extraction.

Start with a rover-mobility profile, terrain statistics at comparable physical scales, optional bare-ground context and Earth climate summaries for field planning. Every anchor and resolved target carries its body, boundary and coordinate convention. Planetary coordinates never serve as Earth search bounds. Details and request examples appear in `docs/selected_location_workflow.md`.

![Earth-centered comparison routing](diagrams/comparison_routing.png)

The regional hypothesis around Jbel Saghro from the prior discussion can be included as an area to investigate. Suitability, accessibility, and scientific novelty remain open questions. The same evidence requirements apply to every candidate. No score should presume that a local candidate will win.

## 2. Feasibility by capability

| Capability | 23-hour decision | Acceptance condition |
|---|---|---|
| NASA source ingestion | Implement one Earth connector and one bounded planetary extract | Raw snapshot, product identifier, units and provenance retained |
| Cleaning and validation | Implement schema, unit, missing-value and quality checks | Invalid records quarantined with explicit reason |
| Candidate discovery | Implement regional screening if feature data are ready by hour 5 | Candidate derives from recorded grid/AOI search |
| Custom analysis | Implement weights, constraints and validated CSV | Input errors explain the affected row and field |
| Auto-analysis | Implement a versioned mission preset and on-demand run | Same snapshot and config reproduce the result |
| Portfolio optimization | Implement exhaustive search for a small candidate pool | Complementarity, budget and eligibility respected |
| Reports and provenance | Implement deterministic report | Every measured claim links to feature and source |
| 2D map | Implement | Site selection, footprints and evidence synchronized |
| 3D navigation | Add after core acceptance | Earth globe toggle, with flat-map fallback |
| Full agent swarm | Design and stage later | Role-specific benchmarks and bounded retries |
| UV, hyperspectral and radar inference | Use validated products when ready | Sensor-aware extraction and evaluation |
| PDF and DOCX interpretation | Defer ingestion automation | Page evidence, extraction verification and isolation |
| Cost and timeline estimates | Accept user scenarios | Currency, base date, source and uncertainty supplied |
| Autonomous repair | Restrict to approved deterministic transforms | Bounded loop, lineage and quarantine |
| Worldwide exhaustive ranking | Defer | Coverage audit, compute plan and scientific validation |

Selecting small planetary targets reduces target acquisition and processing. Earth discovery becomes manageable when a cached catalog and capped shortlist bound the search. Multi-body product decoding and scientific comparability still determine whether each requested comparison is feasible. The full system can be built incrementally over several development cycles. An initial pilot could take roughly 6–12 weeks for a small experienced team, followed by domain validation. This is a planning range dependent on dataset access and science scope. The hackathon plan assumes three contributors and approximately 50–60 effective person-hours within 23 elapsed hours. One contributor should target the CLI, a cached evidence report, a small map and a limited demonstration.

## 3. End-to-end architecture

![ARES system architecture](diagrams/architecture.png)

After location selection and an explicit run request, the browser submits a mission specification and receives a mission identifier immediately. An API validates ownership and configuration, writes the job and event atomically, and returns HTTP 202. A worker claims ready tasks, loads immutable data references, runs the pipeline, stores results, and publishes progress. The browser polls in the MVP. Server-sent events can later provide cursor-based updates.

Store original rasters and documents in object storage or a persistent local data directory. Store checksums, locations, metadata, jobs, feature records, findings, and decisions in relational tables. Use Postgres with PostGIS for the deployed system. The runnable sample uses SQLite for a single local worker. Raw and cleaned data are separate immutable versions linked by provenance. A physical second database adds little value during the hackathon.

Raw observations enter an append-only acquisition stage. Product-aware decoding generates typed measurements. Deterministic cleaning creates a candidate cleaned version. A quality gate either accepts it, requests an allowlisted repair, or quarantines it. Feature extraction feeds scientific comparisons and scenario estimates. Portfolio scoring produces recommendations. Review tasks attach findings. A release gate publishes the report and the exact snapshot identifier.

CPU-heavy raster work belongs in worker processes with bounded memory. In-process web background tasks lack the isolation needed for sustained geospatial work. The production queue can use Postgres leases initially, then a mature job framework when scheduling requirements justify it. [FastAPI background tasks](https://fastapi.tiangolo.com/tutorial/background-tasks/) [Postgres queue locking](https://www.postgresql.org/docs/18/sql-select.html)

## 4. Named phases and agents

![ARES pipeline and quality gates](diagrams/pipeline.png)

Every run uses a versioned pipeline with stable phase names. P00 Register validates one site-or-zone selection per body, resolves Earth–Moon/Earth–Mars edges and target profiles, and requires an explicit request. P10 Acquire snapshots sources. P20 Decode extracts supported scientific and document content. P30 Clean transforms units and flags. P40 Quality Gate assesses repair or quarantine. P50 Characterize creates features and operational assumptions. P60 Analyze computes mission-specific comparisons. P70 Synthesize combines unique evidence and selects portfolios. P80 Review inspects claims and completeness. P90 Publish freezes results.

The full design has 13 named roles. A01 Source Curator selects approved data. A02 Visual Interpreter proposes image-derived labels. A03 Cleaning Planner selects transforms. A04 Quality Reviewer interprets quality findings. A05 Scenario Estimator prepares sourced operational ranges. A06 Domain Analyst is instantiated by specialty and partition. A07 Synthesis Analyst resolves relationships across findings. A08 Process Auditor checks completion and chronology. A09 Evidence Reviewer checks scientific claims. A10 Portfolio Reviewer checks constraints and sensitivity. A11 Release Judge proposes a release decision. A12 Targeted Rechecker evaluates disputed findings. A13 Report Writer renders evidence-backed narrative.

These roles share typed artifacts through the orchestrator. A06 workers can process different partitions in parallel. Global aggregation deduplicates records by source observation, feature, algorithm version, and footprint. Deliberate duplicate analysis provides a diagnostic comparison. Agreement among multiple agents examining the same observation does not increase the number of independent measurements.

Analysis 2 should synthesize interactions, conflicts, coverage and Pareto trade-offs. Repeating the entire first pass with fresh prompts adds cost and correlated error. Use independent methods or held-out checks where practical. The three review agents produce findings with evidence references and severity. The judge can release, release with limitations, request a bounded recheck, or block. A preference for progress may resolve low-severity editorial issues. Critical invalid units, missing required evidence, broken lineage, or failed constraints block release automatically.

The orchestrator owns state transitions, leases, resource reservations, retries, cancellation, provider health, dependency invalidation, and final artifact publication. It can be deterministic application code. A language-model planner receives a limited tool catalog and proposes tasks. The orchestrator validates those proposals before execution. Complete role inputs, outputs and timeout budgets appear in `docs/agent_registry.csv`.

## 5. Data ingestion, vision and cleaning

Metadata discovery precedes download. Each source adapter accepts an area, time interval, product identifier, resolution requirement, and byte budget. It records the query, product version, checksum, access time, attribution, license reference, and any authentication scope. Prefer derived geophysical products for the first implementation. Download only selected granules or windows where supported.

Supported scientific formats should be introduced deliberately. CSV and GeoJSON carry tabular and geometry records. GeoTIFF and Cloud Optimized GeoTIFF carry georeferenced rasters. NetCDF and HDF require variable, scale-factor, quality-bit and dimension interpretation. PDS labels carry planetary product structure and reference-body metadata. Arbitrary files remain outside an adapter's accepted schema until mapped explicitly.

Scientific decoding runs before cleaning. Apply product-specific scale and offset, fill masks, valid ranges and quality bits. Preserve the source values. Keep a transformation ledger recording each rule, software version, reason and affected cells. Avoid generic outlier removal when real extremes are relevant to the mission.

Vision has three distinct inputs. Calibrated spectral bands support validated numerical extraction. Derived image products support visual context. Uploaded photographs support hypotheses and qualitative annotations. Record wavelength range, bandpass, units, acquisition time, georeferencing, sensor, and processing level. Color reversal and false-color rendering are display transforms. Their pixels require the original calibration and mapping before quantitative interpretation. Thermal, ultraviolet, optical and radar observations need separate product-aware methods.

A general vision model can describe visible patterns or extract document tables. Its proposed features enter a review queue with image or page references and an extraction method. Spectral mineral comparisons need atmospheric handling, common wavelengths, instrument-response convolution, continuum treatment, and a validated reference library. The USGS spectral library supplies documented reference measurements for this purpose. [USGS spectral library](https://www.usgs.gov/labs/spectroscopy-lab/usgs-spectral-library)

Use at most two repair passes per asset as an ARES default. Allow safe fixes such as explicit unit conversion, declared sentinel-to-null mapping, encoding normalization, or exact duplicate elimination. Missing coordinate reference systems, conflicting location identities, suspicious georeferencing and unknown calibration require quarantine or a human mapping decision. A quality verdict includes issue codes, severity, evidence references, eligible repairs, remaining uncertainty and next action. A boolean can be derived for legacy callers, but the persisted record retains the richer state.

## 6. Earth and planetary data sources

| Source | Intended use | Practical constraint |
|---|---|---|
| Earthdata CMR | Collection and granule discovery | Download authorization depends on the data provider |
| NASA SRTMGL1 V003 | Earth terrain features | Coverage and latitude-dependent sampling require checks |
| NASA MOD11A2 V061 | Surface thermal context | Eight-day, 1 km product with quality filtering |
| NASA POWER | Earth meteorological context | Coarse spatial support and historical time alignment |
| PDS MOLA | Mars terrain reference | Product labels, planetary coordinates and interpolation |
| PDS LOLA and Diviner | Lunar terrain and thermal references | Product-specific scale, local time and polar geometry |
| NASA GIBS | Browse imagery and map overlays | Visualization layers and availability vary by date |
| Copernicus Data Space | Sentinel products and supplemental DEMs | Account quotas and separate catalog/processing interfaces |
| ESA, JAXA and CSA catalogs | Later complementary observations | Validate access, licensing and processing before scheduling |

CMR responds with metadata and supports pagination. It can return partial results with a timeout header, so a successful HTTP response still needs completeness checks. Rate throttling can return 429 with a retry delay. Store the pagination cursor and completed search bounds. [CMR API](https://cmr.earthdata.nasa.gov/search/site/docs/search/api.html)

POWER permits up to 20 parameters in a daily point query and one parameter in a regional query. Its own tutorial describes meteorology at 0.5 by 0.625 degrees and solar data at 1 by 1 degree. These values describe broad environmental support. Inspect each returned product's metadata because variables and processing versions can differ. The docs warn against excessive concurrent or redundant cell requests. Use an explicit UTC or local-solar-time setting. [POWER daily API](https://power.larc.nasa.gov/docs/services/api/temporal/daily/) [POWER access guidance](https://power.larc.nasa.gov/docs/tutorials/service-data-request/api/)

PDS search exposes a public product API, but its documentation warns that holdings may be incompletely populated. Retain direct node/product adapters as a fallback. MOLA's migrated PDS4 collection provides terrain products at 128 pixels per degree. Distinguish interpolation and instrument footprint from raster spacing. Lunar records must retain their body and native coordinate conventions throughout processing. [PDS search](https://nasa-pds.github.io/pds-api/guides/search/endpoints.html) [MOLA archive](https://pds-geosciences.wustl.edu/missions/mgs/megdr.html)

GIBS publishes WMTS, WMS and related map services. Read layer identifiers, formats, tile matrices and available dates from capabilities. Earth imagery should use the matching projection endpoint. NASA's general API portal currently states that the legacy Earth and Mars Rover APIs are archived. ARES should use GIBS and PDS interfaces appropriate to its scientific tasks. [GIBS access](https://nasa-gibs.github.io/gibs-api-docs/access-basics/) [NASA API portal](https://api.nasa.gov/)

The Copernicus general-user quota table lists Sentinel Hub monthly allowances of 10,000 requests and 10,000 processing units, with per-minute limits of 300 each. The same table lists separate data-download constraints and service-specific footnotes. Those published limits do not establish the user's account entitlement. Configure the lower of the provider limit and the ARES traffic budget. [Copernicus quotas](https://documentation.dataspace.copernicus.eu/Quotas.html)

## 7. Robust scientific comparison

Define a feature registry before scoring. Each feature specifies its physical meaning, canonical unit, spatial support, time aggregation, acceptable source products, quality flags, extraction algorithm, and mission relevance. Example features include slope distribution, multiscale terrain roughness, exposed-ground fraction, thermal range, seasonal precipitation and spectral similarity. Each has an explicit missing-data policy.

Use Earth-specific and planet-specific processing to generate comparable descriptors. Resample continuous measurements with appropriate aggregation and categorical masks with categorical rules. Compute slope using horizontal and vertical units in meters in a suitable local projection. Select a common spatial scale supported by both sources. Upsampling a coarse Mars DEM supplies no additional fine terrain evidence. Keep polar areas out of Earth Web Mercator analysis. Record longitude direction, latitude convention, ellipsoid or sphere, and vertical reference for planetary data.

A simple bounded feature similarity is s = max(0, 1 - distance / tolerance). Tolerance comes from the mission's test requirement or a documented design choice. Use distribution distances for terrain histograms and sensor-aware spectral metrics for spectra. Normalize preferences against fixed reference scales so adding an unrelated candidate cannot silently alter every score.

For comparable observed features, let w sum to one. Report observed similarity S = sum(w × s) / C, with coverage C = sum(w for observed features). Also report conservative utility L = sum(w × s) and upper possibility U = L + 1 - C. These bounds describe missing evidence under a stated [0,1] similarity assumption. They are not calibrated probability intervals. Required-feature failures produce an eligibility failure. A minimum-coverage gate prevents a candidate with a single excellent observation from outranking well-characterized sites without qualification.

Treat feasibility independently. Eligibility uses pass, fail, and unknown states for permissions, prohibited activity, site access and mandatory resources. Cost, effort and duration can be preferences or hard constraints according to the mission. If costs are unknown, report the portfolio's budget feasibility as unknown. Operational estimates require a source, currency, base date, scenario bounds and confidence basis. A language model may assemble supplied rates and formulas. Unsupported precise prices remain unknown.

Describe pros and cons as traceable feature contributions, violated thresholds, mismatches and gaps. Record each statement's feature IDs and sources. A climate limitation can affect field scheduling without implying a geological mismatch. Correlated features should be grouped or downweighted after a correlation audit, especially when multiple derived metrics come from the same raster.

## 8. Portfolio objective and confidence

Retain an Earth-site-by-planetary-target-by-feature matrix. The sample implements a separate profile for each reference location. Criteria retain target body, reference location and feature. Each requested body receives equal total priority, divided equally among its reference locations, with normalized feature weights inside each location. The same Earth measurement can support both comparisons, with its source ID preserved. Target observations also retain source IDs. Missing required target evidence blocks eligibility. Production may add explicit target priorities or worst-case aggregation, with per-target coverage gates when every target is mandatory. These alternatives remain design options.

All portfolio members are Earth analog candidates. One or both planetary sites provide comparison targets. Cost and duration therefore describe Earth fieldwork, with each field site charged once. The sample uses synthetic target profiles and additive scenario costs; extraction from actual planetary products and scientifically validated candidate retrieval remain integration work.

Choose `standalone`, `combined` or `both` as the portfolio output mode. Standalone options have one candidate; combined options have two or more. Both categories retain separate ranked lists as well as the overall ranking. A combined-only request with insufficient eligible candidates returns an empty result with its constraints. Consolidate multiple measurements of one physical field site before optimization; distinct sites in the same zone can be separate members.

For an eligible portfolio P, compute test coverage V(P) = sum over test dimensions of a_j × max over sites in P of lower-bound similarity(i,j). This encourages complementary coverage. Apply a redundancy penalty for overlapping capability vectors and a normalized cost penalty when a comparable cost scenario exists. Impose budget, site-count, duration, season, mandatory capability and geographic constraints explicitly. The chosen objective coefficients belong to a versioned scenario.

For 12 sites and a maximum of three sites, exhaustive enumeration evaluates 298 nonempty combinations. This is simple enough to inspect and test. For larger pools, introduce integer programming or a documented approximate algorithm and report its optimality gap or approximation limitations. Joint logistics include route-dependent travel, shared equipment and mobilization costs. The sample uses additive scenario cost only, which is explicitly labeled.

Return several nondominated alternatives such as highest test coverage, lower cost, lower effort, and lower sensitivity. When a user requests another portfolio, preserve the data snapshot, exclude previously returned site sets, and rerun the portfolio stage. A weight change invalidates scoring and optimization. A changed data product invalidates dependent features and analyses. A new observation relevant to an activated selected scope can create a new mission version under that run’s refresh policy. Changing selected locations creates a new scope and invalidates dependent acquisition, features and analysis. No startup analysis runs on deployment.

Confidence needs multiple fields. At feature level retain measurement uncertainty, source quality, completeness and method-validation status. At site level report weighted coverage and sensitivity. At portfolio level report feasibility status, minimum contributing evidence coverage, coverage gaps and frequency of selection across defined scenarios. An overall quality index can be a clearly labeled heuristic. An agent's self-rating supplies no calibration evidence.

Use at least three robustness checks in the MVP. Perturb weights by a documented range and renormalize. Remove one source family at a time. Evaluate pessimistic and optimistic missing-data and cost scenarios. If measurement distributions exist, sample them with a fixed seed and preserve spatial correlation blocks. Report rank ranges and selection frequencies as scenario stability. Probability language requires calibration against relevant held-out observations.

Validate the scoring logic with known controls, deliberately unsuitable cases, injected missing values, changed units and duplicated observations. Hold out geographic regions for learned components to limit spatial leakage. A successful engineering test establishes code behavior. Scientific validation requires domain review and external measurements.

## 9. Orchestration, traffic and recovery

Anchors, resolved target profiles, allowed comparison edges and Earth retrieval policy are frozen in the mission hash and every task payload. A mission is a directed acyclic graph of tasks plus bounded repair edges. Each task has a stable key derived from snapshot hash, parameters, code version and partition. Results are immutable. Claiming a task creates an attempt with a lease and heartbeat. Completion stores the artifact reference and state transition in one transaction. Expired leases can be reclaimed with a fencing token so a late worker cannot publish stale results.

Use at-least-once execution with idempotent writes. Avoid assuming exactly-once behavior across a queue, filesystem and database. Write object artifacts under attempt-specific names, verify their checksums, then publish the manifest reference transactionally. Downstream tasks read only committed versions. Cancellation marks pending work cancelled and requests cooperative cancellation of running tasks. Retry budgets are shared across all layers to prevent multiplication of attempts. [Celery task semantics](https://docs.celeryq.dev/en/stable/userguide/tasks.html)

Suggested hackathon limits are one active mission, two concurrent source requests, one raster worker, one LLM request, and 20 queued missions. These are conservative starting settings to profile on the actual VM. Use a bounded queue and return a retryable capacity response when full. Download in chunks, reserve disk capacity, set timeouts, and cache by product and cell identity. Avoid storing raster arrays in queue messages or prompts.

Progress comes from completed work units within a frozen task plan. Publish current phase, completed units, total units, queue position, retries, last heartbeat and an estimated completion range. A repair creates a new attempt and updates the estimate transparently. Large downloads use bytes received where a reliable total exists. Indeterminate work uses a phase status. Logs alone cannot establish exact completion percentages.

## 10. Multi-key and model failover

Define credentials by provider, project or organization, quota bucket, supported model, allowed data class and capability. Ordered keys satisfy the requested first-available behavior only after eligibility and quota checks. A 401 disables the affected credential pending correction. A 403 triggers entitlement review. A transient 429 waits for the provider's retry delay and reserves capacity against the shared quota scope. Exhausted daily or spend quota can defer the task or select an independently authorized provider within the approved budget. A 5xx or timeout uses bounded exponential backoff and a circuit breaker.

A 404 or model-retirement response invalidates that route. Resolve the next explicitly configured model, check capabilities, run a small contract canary, and record the change. Schema failures receive one constrained retry before using a validated alternative or deterministic template. Invalid requests should be repaired at the caller. Record provider request IDs and failure class in the private provider-health log.

Gemini limits apply per project. OpenAI limits are scoped by organization and project and vary by model and usage tier. Claude documents organization-level limits with workspace controls. Multiple credentials sharing a quota bucket therefore require one coordinated limiter. Failover capacity must be established from actual account entitlements. [Gemini limits](https://ai.google.dev/gemini-api/docs/rate-limits) [OpenAI limits](https://developers.openai.com/api/docs/guides/rate-limits) [Claude limits](https://platform.claude.com/docs/en/api/rate-limits)

GitHub Models was retired on July 30, 2026, according to current GitHub documentation. Existing Copilot access can support development work. Choose a supported inference provider for ARES runtime roles. Model names, prices and account availability should be captured during deployment using the provider catalog and dashboard. The example routing configuration intentionally requires deployment-specific model IDs. [GitHub Models status](https://docs.github.com/en/github-models)

The deterministic sample needs zero external secret keys. A practical hosted MVP usually needs one Earthdata credential for protected downloads, one inference credential if narration is enabled, and application/database/storage credentials supplied by the host. Add one independently authorized inference credential for provider failover. Copernicus credentials are needed only when its selected access route requires them. A Cesium ion token is needed only for selected ion assets. Agent count does not determine key count.

## 11. Security, privacy and evidence access

Assign mission ownership on the server. Authorize every mission, event, artifact and dataset read. Team operators can inspect provider health and sanitized operational traces. Users can inspect their mission's raw and cleaned evidence through controlled, paginated views and expiring artifact links. Full database access should be represented through authorized data views, query limits and export permissions.

Treat source text, uploaded documents, image OCR and agent outputs as untrusted content. Use schema validation, tool allowlists, restricted egress, and separate read/write roles. Keep provider credentials in server-side secrets. Prevent agents from generating shell commands or changing analytical code during a mission. Log concise execution summaries, evidence and decisions. Retain no private internal model reasoning.

Upload handling needs MIME and signature checks, bounded file and expansion sizes, isolated parsers, disabled external references and macros, and safe download names. Generated CSV exports must neutralize formula-like strings. Outbound downloads use approved hosts and verified public addresses at each redirect to prevent SSRF. Render report text with HTML escaping and restrict active content. [OWASP uploads](https://cheatsheetseries.owasp.org/cheatsheets/File_Upload_Cheat_Sheet.html) [OWASP prompt injection](https://cheatsheetseries.owasp.org/cheatsheets/LLM_Prompt_Injection_Prevention_Cheat_Sheet.html)

The local sample binds to loopback and uses synthetic inputs. Internet deployment requires the production authentication, upload isolation, persistent storage and rate controls documented in the technical specification. User uploads should have a documented retention choice and an explicit provider-data policy before they are sent to external models.

## 12. Observability and operating targets

Use structured logs, traces and metrics with mission ID, task ID, attempt ID, phase, snapshot hash, code version, provider route ID and request ID. Separate scientific findings from infrastructure failures. Track queue age, task latency, error rate, repair count, data bytes, memory, disk space, quota reservations, token use and cost. OpenTelemetry supplies standard concepts for traces, metrics and logs. [OpenTelemetry primer](https://opentelemetry.io/docs/concepts/observability-primer/)

Suggested alert thresholds are worker heartbeat absent for 90 seconds, queued mission waiting over five minutes, repeated credential failure, disk below 20 percent free, and task retry exhaustion. These are initial operating policies. Tune them using measured behavior. Suggested acceptance targets are cached mission completion under two minutes, local status refresh under two seconds, and successful resume after a worker restart. The package validation states which targets were actually exercised.

A private health screen should show each provider's readiness, recent errors, quota scope, last successful request and cooldown deadline. Public mission screens should show task status and understandable failure messages. Redact tokens, authorization headers, signed URLs and personal content. A mission report includes unresolved quality findings and source freshness even when the application is healthy.

## 13. UI, 2D and 3D maps

Use five primary views. Mission Setup selects a site or a multi-location zone on each participating body and chooses standalone, combined or both portfolio outputs. Earth entry requires Moon, Mars or both; planetary entry automatically compares Earth analogs. The user then sets objective, time, constraints and data snapshot. A visible Run action starts either mode. Analog Explorer combines a map, ranked candidates and filters. Site Evidence shows distributions, pros, cons, source metadata and gaps. Portfolio Builder compares complementary site sets and scenarios. Mission Activity displays phase progress, inspectable artifacts and retry history. An operator-only health view supports diagnosis.

MapLibre GL JS supports 2D maps, globe rendering and terrain. Use one Earth map engine in the MVP to limit integration work. Read imagery tile-matrix definitions before wiring NASA layers. A 3D Earth globe is feasible as a visualization extension. Measured terrain requires a DEM source and suitable encoding. Moon or Mars surfaces require body-aware coordinates, imagery and terrain services. Earth basemap configurations cannot supply planetary geodesy. [MapLibre capabilities](https://maplibre.org/projects/gl-js/) [MapLibre map API](https://maplibre.org/maplibre-gl-js/docs/API/classes/Map/)

CesiumJS is a later choice for richer terrain navigation and 3D Tiles. Cesium ion assets require the relevant token and service entitlement. An Earth terrain layer and lunar or Martian geometry require separate data configuration. The 23-hour plan uses body-labeled coordinate/AOI inputs for Moon and Mars and defers a scientifically accurate planetary 3D terrain viewer. The sample Earth globe displays Earth records only. Resolved planetary reference profiles remain available in the result and evidence report. [Cesium terrain](https://cesium.com/learn/cesiumjs-learn/cesiumjs-terrain/)

Display source resolution, observation period and units beside every layer. Selection should synchronize the map and evidence panel. Provide keyboard-operable controls, a tabular alternative, readable color scales and explicit missing-data styles. Use date sliders only when the layer actually has multiple observations. The visual hierarchy should prioritize mission choices, results and evidence.

## 14. Recommended implementation stack

| Layer | Recommendation | Reason |
|---|---|---|
| Frontend | React, TypeScript, Vite, MapLibre | Small deployment surface and reusable map components |
| API | Python 3.12, FastAPI, Pydantic | Typed contracts and proximity to scientific code |
| Processing | NumPy, pandas, Rasterio, pyproj | Mature tabular and geospatial computation |
| Optional formats | xarray, h5netcdf, pyarrow, pds4_tools | Add only for selected products |
| Database | Postgres with PostGIS | Durable jobs, spatial search and evidence relations |
| MVP local data | SQLite plus immutable files | Fast setup for one worker |
| Worker | Dedicated Python process | Predictable memory and task lifecycle |
| Object storage | Host-provided S3-compatible storage or persistent disk | Large artifacts outside database rows |
| Optimization | Python combinations initially | Exact, auditable small-pool enumeration |
| Telemetry | JSON events initially, OpenTelemetry later | Shared correlation identifiers |

Use lockfiles generated for the target environment and test them before freezing. Geospatial binary wheels and system libraries are common installation risks. The dependency inventory distinguishes the tested standard-library skeleton from recommended integrations. Free hosting still needs persistent disk, worker uptime, sufficient memory, egress and appropriate execution duration. Verify those capabilities on the actual host during the first hour.

## 15. Detailed 23-hour delivery roadmap

| Elapsed hours | Data/science owner | Backend owner | UI/demo owner | Gate |
|---|---|---|---|---|
| 0–1 | Select small locations, bodies and objective | Verify runtime, storage and accounts | Define screens and demo story | Selection and explicit-request contract |
| 1–3 | Fetch bounded source snapshots | Persist jobs, snapshots and events | Build setup and results shell | Raw NASA data retained |
| 3–5 | Decode, clean and extract features | Implement validators and quarantine | Connect progress and evidence panels | One valid feature table |
| 5–8 | Compare Earth/planetary descriptors | Implement scoring and constraints | Map candidate areas and score cards | One reproducible ranked result |
| 8–11 | Evaluate missingness and controls | Enumerate portfolios and alternatives | Add portfolio comparison | Feasible complementary portfolio |
| 11–14 | Validate claims and citations | Custom mission, CSV and report export | Filters, weights and report links | Both user journeys demonstrated |
| 14–16 | Sensitivity and failure cases | Retry, recovery and health view | Optional Earth globe toggle | Restart and missing-data checks |
| 16–19 | Review evidence and limitations | Deployment and smoke tests | Accessibility and coherent demo | Deployed end-to-end run |
| 19–21 | Final scientific claims review | Freeze data and dependencies | Record presentation and fallback | Submission assets ready |
| 21–23 | Reserve for fixes | Reserve for integration failures | Submit and verify receipt | Submission confirmed |

At hour 3, unresolved authentication triggers a documented cached-public-data path. At hour 5, missing raster features narrows the demonstration to evidence-backed comparison with discovery marked pending. At hour 8, a working deterministic result takes priority over optional LLM roles. At hour 14, optional 3D and document ingestion are removed if core acceptance is incomplete. At hour 19, freeze features and preserve a local recording plus downloadable report.

Use coding assistants to accelerate separately owned tasks with reviewable contracts. The two Claude accounts, Codex access, Gemini and Copilot resources described in the prior conversation can support coding and research where their terms and entitlements permit. Their availability does not replace engineering review or verified runtime API access.

## 16. Demonstration and acceptance

A compelling demonstration starts from a mission objective, shows the NASA source evidence, runs the pipeline, explains one strong candidate and one rejection, then presents a complementary portfolio and its unresolved gaps. Change a mission weight to demonstrate a reproducible alternative. Display a missing observation to demonstrate uncertainty handling. Open the event timeline and inspect a source reference.

The acceptance checklist includes genuine NASA measurements with product identifiers, at least one planetary reference, unit and coordinate validation, bounded cleaning, explicit unknowns, deterministic scoring, portfolio constraints, reproducible output, 2D navigation, an evidence report, failure status, and a working deployment. The sample implementation supplies engineering examples for these interfaces. Final scientific and deployment acceptance belongs to the implementation team.

Current public API validation, dependency checks and package tests are summarized in `validation/validation_report.md`. Model inference and account-specific limits remain unverified because credentials were unavailable. The official challenge resource list was verified after retrying access. Actual account entitlement and deployment capacity remain hour-zero checks in the risk register.

## 17. Decisions that shape the build

Use immutable raw snapshots and versioned cleaned features. Let deterministic rules control scientific gates and calculations. Treat language models as bounded evidence processors. Keep mission preferences, hard eligibility, and evidence quality as separate fields. Deduplicate evidence before aggregation. Limit repair loops and publish unresolved limitations. Reuse cached upstream artifacts for portfolio alternatives. Implement one Earth map engine first. Use authorized quota-aware provider routing. Freeze a working end-to-end path before expanding the swarm.

These decisions are documented with consequences and revisit triggers in `docs/design_decisions.md`. The technical specification and contracts extend this report into an implementable handoff.
