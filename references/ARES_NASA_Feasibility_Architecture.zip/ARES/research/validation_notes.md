# Research verification notes

All checks were performed on 14 November 2026. `api_live_validation.json` retains requested URLs, response status, retrieval times, payload sizes and available content hashes. Probe successes establish endpoint behavior for the recorded requests. They provide a starting point for integration testing on the team's host.

## Public source results

- NASA POWER returned the requested two-parameter, seven-day point series.
- Earthdata CMR returned SRTMGL1 V003 collection metadata, including a collection concept ID and coverage information.
- PDS general search and the specific MOLA 128-pixels-per-degree collection request returned JSON. Both used a provider redirect to `pds.mcp.nasa.gov`.
- GIBS capabilities returned valid XML with 1,330 layer definitions. Layer identifiers, dates and matrices need selection for each map overlay.
- Copernicus STAC collections returned catalog JSON. Authentication-dependent download and processing services were not exercised.
- The official challenge page was recovered after an initial web-reader error. Its 11 resource links are listed in `challenge_resources.csv`.

## AI provider verification

Official documentation was checked for current endpoints, model discovery, quota scopes and retirement information. No user inference credentials were available. Actual account quotas, free-tier eligibility, model entitlement, response latency, credits and spend limits remain deployment checks. The sample routes are policy demonstrations with deterministic report fallback.

GitHub's current official page states that GitHub Models has been retired. Gemini's documented quota scope is the project. OpenAI and Claude expose broader organization/project or workspace quota controls. The main report cites the relevant provider pages.

## Dependency verification

Sixteen package metadata records were retrieved from official npm or PyPI registries. Published versions and runtime requirements appear in `dependency_inventory.csv` and the original selected metadata in `dependency_registry_validation.json`. Registry metadata alone does not establish compatibility among packages.

The npm registry reported MapLibre 6.18.0 as the current package, while the attempted unpkg and jsDelivr `dist/maplibre-gl.js` browser URLs for that version returned 404. The sample therefore pins MapLibre 5.6.2, whose browser distribution returned 200 and passed the 2D/globe workflow check. Production should use its frontend bundler and verify the selected package's current export paths. This is an explicit sample implementation choice.

The Python sample uses the standard library and was tested with Python 3.9 and 3.12. Production scientific dependencies require a target-environment lockfile and integration tests. Their registry versions are recorded as research observations.

## Scientific verification boundary

The package validates software behavior using labeled synthetic observations. Real raw responses are supplied as source-access evidence. No claimed site ranking is derived from those raw responses. Validated raster extraction, target-profile definition, source-level uncertainty, geographic holdouts and domain review remain prerequisites for scientific suitability claims.

## Source licensing and attribution

Retain product citation, license URL and attribution in each AssetManifest. NASA and partner catalog entries can link to products with distinct use conditions. Map libraries and basemap services also carry their own licenses and attribution requirements. This package cites primary sources and includes small retrieved metadata/time-series samples for reproducible access checks.
