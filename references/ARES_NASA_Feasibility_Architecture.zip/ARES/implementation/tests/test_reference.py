import copy
import json
import tempfile
import unittest
import itertools
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from ares.__main__ import work_once
from ares.engine import analyze, clean, score_site, validate, weights_for, expand_comparisons
from ares.router import Route, Router, retry_delay
from ares.store import Conflict, Store

FIXTURE = Path(__file__).resolve().parents[1] / "examples" / "mission.json"


class EngineTests(unittest.TestCase):
    def setUp(self):
        self.payload = json.loads(FIXTURE.read_text())

    def test_reproducible(self):
        self.assertEqual(analyze(self.payload), analyze(self.payload))

    def test_hand_calculated_score(self):
        expanded = expand_comparisons(self.payload)
        mission = expanded["mission"]
        score = score_site(expanded["sites"][0], mission, weights_for(mission))
        expected = 0.45 + 0.35 * (1 - 4/6) + 0.2 * (1 - 0.3/0.5)
        self.assertAlmostEqual(score["lower_utility"], expected)
        self.assertAlmostEqual(score["coverage"], 1)

    def test_missingness_and_access(self):
        sites = {row["id"]: row for row in analyze(self.payload)["sites"]}
        for site_id in ["D", "E", "F"]:
            self.assertFalse(sites[site_id]["eligible"])
        self.assertAlmostEqual(sites["D"]["coverage"], 0.45)
        self.assertGreater(sites["D"]["upper_utility"], sites["D"]["lower_utility"])

    def test_unknown_cost_under_budget_excluded(self):
        self.payload["sites"][0]["cost"] = None
        result = analyze(self.payload)
        self.assertTrue(all("A" not in portfolio["site_ids"] for portfolio in result["portfolios"]))

    def test_unknown_operational_status_without_budget(self):
        self.payload["mission"]["budget"] = None
        self.payload["mission"]["allow_unknown_access"] = True
        result = analyze(self.payload)
        candidates = [row for row in result["portfolios"] if "F" in row["site_ids"]]
        self.assertTrue(candidates)
        self.assertTrue(all(row["operational_status"] == "unknown" for row in candidates))

    def test_budget_and_alternative(self):
        result = analyze(self.payload)
        self.assertTrue(all(portfolio["cost"] <= 900 for portfolio in result["portfolios"]))
        best = result["portfolios"][0]["site_ids"]
        self.payload["mission"]["exclude_portfolios"] = [best]
        self.assertTrue(all(portfolio["site_ids"] != best for portfolio in analyze(self.payload)["portfolios"]))

    def test_no_feasible_portfolio(self):
        self.payload["mission"]["budget"] = 0
        self.assertEqual(analyze(self.payload)["status"], "no_feasible_portfolio")

    def test_bad_unit_nan_duplicate_and_zero_weights(self):
        for mutation in ("unit", "nan", "duplicate", "weights"):
            payload = copy.deepcopy(self.payload)
            if mutation == "unit": payload["sites"][0]["observations"]["slope_deg"]["unit"] = "radian"
            if mutation == "nan": payload["sites"][0]["cost"] = float("nan")
            if mutation == "duplicate": payload["sites"][1]["id"] = "A"
            if mutation == "weights":
                for feature in payload["mission"]["features"].values(): feature["weight"] = 0
            with self.assertRaises(ValueError): validate(payload)

    def test_sentinel_repair_preserves_raw(self):
        observation = self.payload["sites"][0]["observations"]["roughness_m"]
        observation.update(value=-999, missing_sentinel=-999)
        cleaned, ledger = clean(self.payload)
        self.assertIsNone(cleaned["sites"][0]["observations"]["roughness_m"]["value"])
        self.assertEqual(observation["value"], -999)
        self.assertEqual(len(ledger), 1)

    def test_location_selection_required(self):
        self.payload["mission"]["scope"]["locations"] = []
        with self.assertRaises(ValueError):
            analyze(self.payload)

    def test_earth_anchor_limits_candidate_processing(self):
        self.payload["mission"]["scope"] = {"locations": [{"id":"earth-A", "body":"Earth", "coordinate_system":"WGS84_lonlat", "bbox":[-6.1,30.9,-5.9,31.1]}], "compare_with":["Mars"]}
        self.payload["sites"][1]["observations"]["slope_deg"]["unit"] = "incompatible-outside-scope"
        result = analyze(self.payload)
        self.assertEqual([site["id"] for site in result["sites"]], ["A"])
        self.assertEqual(result["excluded_outside_scope"], ["B", "C", "D", "E", "F"])

    def test_planetary_selection_automatically_searches_earth(self):
        for filename, body in (("mission.json", "Mars"), ("moon_mission.json", "Moon")):
            for mode in ("auto", "custom"):
                payload = json.loads((FIXTURE.parent / filename).read_text())
                payload["mission"]["mode"] = mode
                payload["mission"]["scope"].pop("compare_with")
                result = analyze(payload, sensitivity_runs=2)
                self.assertEqual(len(result["sites"]), 6)
                self.assertEqual({site["body"] for site in result["sites"]}, {"Earth"})
                self.assertEqual(result["comparison_pairs"], [["Earth",body]])

    def test_earth_requires_explicit_target(self):
        self.payload["mission"]["scope"] = {"locations": [{"id":"earth-A", "body":"Earth", "coordinate_system":"WGS84_lonlat", "bbox":[-6.1,30.9,-5.9,31.1]}]}
        with self.assertRaises(ValueError): analyze(self.payload)

    def test_one_selected_site_per_body(self):
        duplicate = copy.deepcopy(self.payload["mission"]["scope"]["locations"][0])
        duplicate["id"] = "second-mars-site"
        self.payload["mission"]["scope"]["locations"].append(duplicate)
        with self.assertRaises(ValueError): analyze(self.payload)

    def test_direct_moon_mars_comparison_rejected(self):
        self.payload["mission"]["scope"]["compare_with"] = ["Moon"]
        with self.assertRaises(ValueError): analyze(self.payload)

    def test_two_targets_remain_separate_earth_comparisons(self):
        mixed = json.loads((FIXTURE.parent / "three_body_mission.json").read_text())
        result = analyze(mixed)
        self.assertEqual(result["comparison_pairs"], [["Earth","Moon"],["Earth","Mars"]])
        self.assertEqual(len(result["weights"]), 6)
        contributions = result["sites"][0]["contributions"]
        self.assertNotEqual(contributions["Moon/slope_deg"]["similarity"], contributions["Mars/slope_deg"]["similarity"])
        self.assertEqual(contributions["Mars/slope_deg"]["target_source_id"], "synthetic-Mars-slope_deg")
        self.assertAlmostEqual(sum(result["weights"].values()), 1)

    def test_two_planetary_anchors_automatically_compare_with_earth(self):
        mixed = json.loads((FIXTURE.parent / "three_body_mission.json").read_text())
        mixed["mission"]["scope"]["locations"] = [loc for loc in mixed["mission"]["scope"]["locations"] if loc["body"] != "Earth"]
        mixed["mission"]["scope"]["compare_with"] = ["Earth"]
        result = analyze(mixed)
        self.assertEqual(len(result["comparison_pairs"]), 2)
        self.assertEqual(len(result["sites"]), 6)

    def test_missing_target_evidence_never_becomes_a_good_match(self):
        self.payload["target_profiles"][0]["observations"]["slope_deg"]["value"] = None
        self.assertEqual(analyze(self.payload)["status"], "no_feasible_portfolio")

    def test_wrong_or_duplicate_profile_rejected(self):
        for mutation in ("location", "duplicate", "units"):
            payload = copy.deepcopy(self.payload)
            if mutation == "location": payload["target_profiles"][0]["location"]["id"] = "unselected"
            if mutation == "duplicate": payload["target_profiles"].append(payload["target_profiles"][0])
            if mutation == "units": payload["target_profiles"][0]["observations"]["slope_deg"]["unit"] = "radian"
            with self.assertRaises(ValueError): analyze(payload)

    def test_deployment_trigger_rejected(self):
        self.payload["mission"]["start_trigger"] = "deployment"
        with self.assertRaises(ValueError):
            analyze(self.payload)

    def test_body_coordinate_mismatch_rejected(self):
        self.payload["sites"][0]["body"] = "Moon"
        with self.assertRaises(ValueError):
            analyze(self.payload)

    def test_antimeridian_selection(self):
        self.payload["mission"]["scope"]["locations"] = [{"id":"date-line","body":"Earth","coordinate_system":"WGS84_lonlat","bbox":[179.5,30.9,-179.5,31.1]}]
        self.payload["mission"]["scope"]["compare_with"] = ["Mars"]
        self.payload["sites"][0]["longitude"] = -179.9
        result = analyze(self.payload)
        self.assertEqual([site["id"] for site in result["sites"]], ["A"])


class ZoneTests(unittest.TestCase):
    def setUp(self):
        self.payload = json.loads((FIXTURE.parent / "zone_mission.json").read_text())

    def test_zone_multiple_locations_in_both_analysis_modes(self):
        for mode in ("auto", "custom"):
            self.payload["mission"]["mode"] = mode
            result = analyze(self.payload, sensitivity_runs=2)
            self.assertEqual({site["id"] for site in result["sites"]}, {"A", "B", "C"})
            self.assertTrue(result["standalone_portfolios"])
            self.assertTrue(result["combined_portfolios"])
            self.assertEqual(result["excluded_outside_scope"], ["D", "E", "F"])

    def test_requested_portfolio_modes(self):
        for mode, sizes in (("standalone", {1}), ("combined", {2}), ("both", {1,2})):
            self.payload["mission"]["portfolio_mode"] = mode
            result = analyze(self.payload, sensitivity_runs=2)
            self.assertEqual({len(p["site_ids"]) for p in result["portfolios"]}, sizes)
            self.assertTrue(all(p["cost"] <= 900 for p in result["portfolios"]))

    def test_target_locations_preserved_and_body_weights_balanced(self):
        self.payload["target_profiles"] = [p for i,p in enumerate(self.payload["target_profiles"]) if i != 0]
        result = analyze(self.payload, sensitivity_runs=2)
        expanded = expand_comparisons(self.payload)
        weights = weights_for(expanded["mission"])
        by_body = {body:sum(weights[key] for key,spec in expanded["mission"]["features"].items() if spec["target_body"] == body) for body in ("Moon","Mars")}
        self.assertAlmostEqual(by_body["Moon"], .5)
        self.assertAlmostEqual(by_body["Mars"], .5)
        self.assertEqual(len({v["target_location_id"] for v in result["sites"][0]["contributions"].values()}), 3)

    def test_target_outside_zone_rejected(self):
        self.payload["target_profiles"][0]["location"]["bbox"][0] -= 1
        with self.assertRaises(ValueError): analyze(self.payload)

    def test_invalid_selection_kind_rejected(self):
        self.payload["mission"]["scope"]["locations"][0]["kind"] = "anything"
        with self.assertRaises(ValueError): analyze(self.payload)

    def test_combined_needs_two_allowed_members(self):
        self.payload["mission"].update(portfolio_mode="combined", max_sites=1)
        with self.assertRaises(ValueError): analyze(self.payload)

    def test_no_combined_result_with_only_one_eligible_candidate(self):
        self.payload["mission"]["portfolio_mode"] = "combined"
        for site in self.payload["sites"][1:]: site["access"] = "fail"
        result = analyze(self.payload)
        self.assertEqual(result["status"], "no_feasible_portfolio")
        self.assertEqual(result["standalone_portfolios"], [])

    def test_dateline_zone_contains_reference_bounds(self):
        from ares.scope import contains_bounds
        parent = {"body":"Moon", "bbox":[179.5,-1,-179.5,1]}
        self.assertTrue(contains_bounds(parent, {"body":"Moon", "bbox":[179.8,-.5,-179.8,.5]}))
        self.assertFalse(contains_bounds(parent, {"body":"Moon", "bbox":[179.4,-.5,-179.8,.5]}))


class StoreTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.store = Store(Path(self.folder.name) / "jobs.sqlite")
        self.payload = json.loads(FIXTURE.read_text())

    def tearDown(self):
        self.folder.cleanup()

    def test_idempotency(self):
        mission_id = self.store.submit(self.payload, "same")
        self.assertEqual(mission_id, self.store.submit(self.payload, "same"))
        self.payload["mission"]["budget"] += 1
        with self.assertRaises(Conflict): self.store.submit(self.payload, "same")

    def test_startup_has_no_job(self):
        self.assertIsNone(self.store.claim())

    def test_concurrent_initialization(self):
        path = Path(self.folder.name) / "new.sqlite"
        with ThreadPoolExecutor(max_workers=4) as pool:
            stores = list(pool.map(lambda _: Store(path), range(4)))
        self.assertEqual(len(stores), 4)

    def test_concurrent_claim_single_winner(self):
        self.store.submit(self.payload, "claim")
        with ThreadPoolExecutor(max_workers=2) as pool:
            claims = list(pool.map(lambda _: self.store.claim(), range(2)))
        self.assertEqual(sum(claim is not None for claim in claims), 1)

    def test_expired_attempt_fenced(self):
        mission_id = self.store.submit(self.payload, "reclaim")
        stale = self.store.claim(lease_seconds=-1)
        current = self.store.claim()
        with self.assertRaises(Conflict): self.store.finish(stale, result={})
        self.store.finish(current, result={"ok": True})
        self.assertEqual(self.store.get(mission_id)["state"], "succeeded")

    def test_attempt_budget(self):
        mission_id = self.store.submit(self.payload, "budget")
        for _ in range(3): self.assertIsNotNone(self.store.claim(lease_seconds=-1))
        self.assertIsNone(self.store.claim())
        self.assertEqual(self.store.get(mission_id)["state"], "failed")

    def test_worker_and_event_cursor(self):
        mission_id = self.store.submit(self.payload, "worker")
        self.assertTrue(work_once(self.store))
        job = self.store.get(mission_id)
        self.assertEqual(job["state"], "succeeded")
        events = self.store.events(mission_id)
        self.assertEqual(events[-1]["completed"], 5)
        self.assertEqual(self.store.events(mission_id, events[-1]["sequence"]), [])


class RouterTests(unittest.TestCase):
    def test_quota_group_and_capability(self):
        first = Route("first", "shared", "model-a", frozenset({"text"}))
        second = Route("second", "shared", "model-a", frozenset({"text"}))
        third = Route("third", "independent", "model-b", frozenset({"text"}))
        router = Router([first, second, third])
        router.record_failure(first, 429, 100, "20")
        self.assertEqual(router.select({"text"}, 101), third)
        self.assertEqual(router.select({"text"}, 121), first)
        self.assertIsNone(router.select({"vision"}, 121))

    def test_invalid_credential_and_retry_header(self):
        route = Route("first", "scope", "model", frozenset({"text"}))
        router = Router([route])
        router.record_failure(route, 401, 0)
        self.assertIsNone(router.select({"text"}, 1))
        self.assertEqual(retry_delay("bad"), 30)


if __name__ == "__main__":
    unittest.main()
