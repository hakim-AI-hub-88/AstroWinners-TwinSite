# Runnable ARES reference

Requires Python 3.9 or later. Python 3.12 is recommended for the implementation team. The core, API, CLI, connector and tests use the standard library. The web map loads MapLibre GL JS 5.6.2 and its demonstration basemap over the internet. The selected browser distribution was verified through a live CDN request and a browser workflow check.

Every run requires explicit selected locations in mission.scope and start_trigger=user_request. Startup creates no jobs. `examples/mission.json` selects one Mars target and compares six Earth catalog candidates. `examples/moon_mission.json` selects one Moon target. `examples/three_body_mission.json` selects one site-or-zone selection per body and computes separate Earth–Moon and Earth–Mars comparisons.

## Offline calculation

From this directory run the following commands.

```bash
python3 -m ares run examples/mission.json --output run-output
python3 -m unittest discover -s tests -v
```

Open `run-output/report.html`. Input measurements and costs are explicitly synthetic. The score result and input/cleaned hashes are in `run-output/result.json`.

## Local interface

Start the API in one terminal and the worker in another, both from this directory.

```bash
python3 -m ares serve --db ares.sqlite --port 8080
```

```bash
python3 -m ares worker --db ares.sqlite
```

Open `http://127.0.0.1:8080`. Choose an entry body and one site or zone. For Earth, also choose Moon, Mars or both. Then request analysis in auto or custom mode. Inspect results, request an alternative, and toggle Earth 2D/globe navigation. The Earth map displays only Earth records. Planetary reference profiles and both permitted comparison edges appear in the result/report. The table and reports work when basemap resources are unavailable. Stop the processes with Ctrl+C. The SQLite file retains missions and events. A crashed attempt can be reclaimed after its lease expires. A task has three claim attempts.

## CSV custom input

Body and coordinate_system columns are mandatory. The CSV adapter accepts the columns in `examples/sites.csv`. Feature units are explicitly supplied by the template. Review those units before importing.

```bash
python3 -m ares import-csv examples/mission.json examples/sites.csv imported.json
python3 -m ares run imported.json --output imported-output
```

## Real NASA source request

This command retrieves one historical Earth environmental series and records its raw bytes and provenance.

```bash
python3 -m ares power --longitude -6 --latitude 31 --start 20240101 --end 20240107 --output raw-power
```

The connector's result needs scientific interpretation before joining the scoring feature table. It never mixes real climate responses into synthetic terrain measurements automatically. It requests only the fixed NASA POWER host, two parameters and a bounded time window. The production connector still needs shared caching, rate limiting, retry policy and redirect egress controls.

## Implemented behavior

- One selected site or zone per body, automatic Earth analog comparison for planetary selections, explicit Earth target choice, separate target profiles, body/coordinate matching, dateline-aware bounds, out-of-scope exclusion, units, finite values, required-feature and access validation.
- Declared missing-sentinel repair with a transformation ledger.
- Weighted observed similarity, coverage and missingness bounds.
- Exact enumeration for up to 12 sites and portfolios of at most three sites.
- Budget and duration constraints, unknown feasibility, redundancy penalty and excluded alternatives.
- Fifty deterministic weight-perturbation scenarios with recorded seed.
- SQLite jobs, idempotency conflict detection, atomic claims, attempt limits and fenced commits.
- Phase events, local HTTP API, safe HTML report and a lightweight map interface.
- Provider-routing policy example with shared quota-group cooldown and capability filtering.

## Remaining integration work

The sample has no authenticated multi-tenant deployment, automatic source refresh, production upload endpoint, raster/planetary decoding, learned vision, PDF/DOCX extraction, real model inference, distributed quota reservation, calibrated scientific uncertainty, cancellation endpoint, route-dependent logistics, or scientifically validated discovery. It exposes a compact reference API listed in `../contracts/api_contract.md`. The larger design's phase and agent inventory is implemented progressively through the roadmap.

The local server binds to loopback. Production should use the documented FastAPI/authentication stack and a dedicated worker supervisor. The sample lease is refreshed at phase boundaries and assumes each bounded phase finishes within 60 seconds. Large processing tasks require independent heartbeat renewal and chunk cancellation. Exact dependency versions for the production stack need a target-environment lockfile.

## Extension points

Add source adapters before `clean`, product-aware feature extraction before `analyze`, and evidence-limited narration after scoring. Retain the immutable snapshot and unit contracts. Replace the SQLite Store with the Postgres contract when deploying multiple workers. Replace the simple local HTTP adapter with authenticated FastAPI routes while preserving idempotency and response shapes.

The sample uses a separate supplied observation profile for each reference location and scores Earth candidates per target-location-feature criterion. Automatic source extraction and body-specific map layers remain integration work. Selected bounds are limited to two degrees per axis in the sample. Production should budget physical area and processing workload.

## Zone example and output choices

`examples/zone_mission.json` selects one zone on each body, includes three Earth candidate locations inside the Earth zone and two reference locations inside each planetary zone. Run it with `python3 -m ares run examples/zone_mission.json --output zone-output`. All observations are synthetic.

Select **Zone with multiple locations** in the browser, choose the example zone, choose planetary targets for Earth entry, and set **Portfolio results** to standalone, combined or both. Both analysis modes use the same engine. `mission.portfolio_mode` defaults to `both`. `max_sites` limits each portfolio; it does not limit the zone to one candidate. The API/CLI accepts custom bounds and records. The UI currently provides example selectors rather than a polygon-drawing tool.

Planetary zone reference profiles must be wholly inside the selected zone. Their feature contributions retain location IDs. Equal weighting applies first by body, then by reference location within that body, so reference counts cannot silently bias body priorities. Scientific sampling, polygon intersection, canonical field-site consolidation and correlated uncertainty remain production integrations.
