/* The server is the authority for scoring. All user-supplied text uses textContent. */
let map;
let lastResult;
let markers = [];
let availableLocations = [];
let availableProfiles = [];
const statusElement = document.getElementById('status');
const configElement = document.getElementById('config');

async function request(url, options) {
  const response = await fetch(url, options);
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || `Request failed (${response.status})`);
  return data;
}

function cell(row, text, tag = 'td') {
  const element = document.createElement(tag);
  element.textContent = text;
  row.append(element);
}

function showResult(result, id) {
  lastResult = result;
  const host = document.getElementById('results');
  host.replaceChildren();
  const table = document.createElement('table');
  const heading = document.createElement('tr');
  ['Site', 'Lower utility', 'Evidence coverage', 'Eligibility'].forEach(text => cell(heading, text, 'th'));
  table.append(heading);
  markers.forEach(marker => marker.remove());
  markers = [];
  for (const site of result.sites) {
    const row = document.createElement('tr');
    cell(row, `${site.name} (${site.body})`);
    cell(row, site.lower_utility.toFixed(2));
    cell(row, `${Math.round(site.coverage * 100)}%`);
    cell(row, site.eligible ? 'Eligible in scenario' : site.failures.join(', '));
    table.append(row);
    if (map && site.body === 'Earth') {
      const text = document.createElement('p');
      text.textContent = `${site.name} · ${site.lower_utility.toFixed(2)} lower utility`;
      const marker = new maplibregl.Marker({color: site.eligible ? '#008c95' : '#b35037'})
        .setLngLat([site.longitude, site.latitude])
        .setPopup(new maplibregl.Popup().setDOMContent(text)).addTo(map);
      markers.push(marker);
    }
  }
  host.append(table);
  const summary = document.createElement('p');
  const best = result.portfolios[0];
  summary.textContent = best ? `Selected portfolio ${best.site_ids.join(', ')}. Test coverage utility ${best.test_coverage_utility.toFixed(2)}. Scenario cost ${best.cost}. Operational status ${best.operational_status}.` : 'No feasible portfolio under these constraints.';
  host.append(summary);
  for (const [title, portfolios] of [['Standalone candidates', result.standalone_portfolios], ['Combined portfolios', result.combined_portfolios]]) {
    if (!portfolios.length) continue;
    const heading = document.createElement('h3'); heading.textContent = title; host.append(heading);
    const list = document.createElement('ul');
    for (const portfolio of portfolios.slice(0, 3)) {
      const item = document.createElement('li');
      item.textContent = `${portfolio.site_ids.join(' + ')} · objective ${portfolio.objective.toFixed(3)} · cost ${portfolio.cost}`;
      list.append(item);
    }
    host.append(list);
  }
  const scopeSummary = document.createElement('p');
  scopeSummary.textContent = `Selected anchors ${result.scope.locations.map(location => `${location.id} (${location.body})`).join(', ')}. Comparisons ${result.comparison_pairs.map(pair => pair.join("–")).join(", ")}. Excluded records ${result.excluded_outside_scope.length}.`;
  host.append(scopeSummary);
  const link = document.createElement('a');
  link.href = `/v1/missions/${id}/report`;
  link.textContent = 'Open full evidence report';
  document.getElementById('report').replaceChildren(link);
  document.getElementById('alternative').disabled = !best;
}

async function run(alternative = false) {
  document.getElementById('run').disabled = true;
  document.getElementById('alternative').disabled = true;
  statusElement.textContent = 'Submitting mission…';
  document.querySelectorAll('#bodySet, #selectionKind, #portfolioMode, #mode, #locations input, #comparePanel input').forEach(control => { control.disabled = true; });
  try {
    const payload = JSON.parse(configElement.value);
    const selected = new Set(Array.from(document.querySelectorAll('#locations input:checked')).map(input => input.value));
    if (!selected.size) throw new Error('Select at least one bounded location before requesting analysis.');
    payload.mission.scope.locations = availableLocations.filter(location => selected.has(location.id));
    const earthEntry = document.getElementById('bodySet').value === 'earth';
    const targets = earthEntry ? Array.from(document.querySelectorAll('#comparePanel input:checked')).map(input => input.value)
      : [payload.mission.scope.locations[0].body];
    if (!targets.length) throw new Error('Choose Moon, Mars, or both for an Earth selection.');
    payload.mission.scope.compare_with = earthEntry ? targets : ['Earth'];
    // Preserve edited target measurements, including profiles retained from the draft.
    const profileKey = profile => JSON.stringify([profile.body, profile.location.id]);
    const profileByLocation = new Map(availableProfiles.map(profile => [profileKey(profile), profile]));
    for (const profile of payload.target_profiles) profileByLocation.set(profileKey(profile), profile);
    payload.target_profiles = Array.from(profileByLocation.values()).filter(profile => targets.includes(profile.body));
    payload.mission.portfolio_mode = document.getElementById('portfolioMode').value;
    payload.mission.mode = document.getElementById('mode').value;
    payload.mission.start_trigger = 'user_request';
    payload.mission.budget = Number(document.getElementById('budget').value);
    payload.mission.max_sites = Number(document.getElementById('maxSites').value);
    if (alternative && lastResult?.portfolios[0]) {
      payload.mission.exclude_portfolios ||= [];
      payload.mission.exclude_portfolios.push(lastResult.portfolios[0].site_ids);
    }
    configElement.value = JSON.stringify(payload, null, 2);
    const mission = await request('/v1/missions', {
      method: 'POST',
      headers: {'Content-Type': 'application/json', 'Idempotency-Key': crypto.randomUUID()},
      body: JSON.stringify(payload)
    });
    let cursor = 0;
    document.getElementById('events').textContent = '';
    for (let attempt = 0; attempt < 120; attempt++) {
      const job = await request(mission.status_url);
      const events = await request(`${mission.status_url}/events?after=${cursor}`);
      for (const event of events) {
        cursor = event.sequence;
        document.getElementById('events').textContent += `${event.phase} · ${event.completed}/5 units · ${event.summary}\n`;
      }
      if (job.state === 'failed') throw new Error(job.error || 'Mission failed');
      if (job.state === 'succeeded') {
        showResult(await request(`${mission.status_url}/result`), mission.id);
        statusElement.textContent = `Mission succeeded · attempt ${job.attempt}`;
        return;
      }
      statusElement.textContent = `Mission ${job.state} · attempt ${job.attempt}`;
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
    throw new Error('Still pending. Check that the worker is running and inspect the mission API.');
  } catch (error) {
    statusElement.textContent = error.message;
  } finally {
    updateReady();
    document.querySelectorAll('#bodySet, #selectionKind, #portfolioMode, #mode, #locations input, #comparePanel input').forEach(control => { control.disabled = false; });
  }
}

document.getElementById('run').addEventListener('click', () => run());
document.getElementById('alternative').addEventListener('click', () => run(true));
document.getElementById('flat').addEventListener('click', () => map?.setProjection({type: 'mercator'}));
document.getElementById('globe').addEventListener('click', () => map?.setProjection({type: 'globe'}));

if (window.maplibregl) {
  try {
    map = new maplibregl.Map({container: 'map', style: 'https://demotiles.maplibre.org/style.json', center: [-10, 25], zoom: 1.3});
    map.addControl(new maplibregl.NavigationControl());
    map.on('error', () => { document.getElementById('mapStatus').textContent = 'Some map resources could not load. The evidence table remains available.'; });
  } catch (error) {
    document.getElementById('mapStatus').textContent = error.message;
  }
}

function updateReady() {
  const selected = !!document.querySelector('#locations input:checked');
  const earth = document.getElementById('bodySet').value === 'earth';
  const targets = !!document.querySelector('#comparePanel input:checked');
  document.getElementById('run').disabled = !(selected && (!earth || targets));
}

async function loadLocations() {
  document.getElementById('run').disabled = true;
  document.getElementById('alternative').disabled = true;
  lastResult = undefined;
  document.getElementById('results').textContent = 'Choose a site or zone, then request comparison.';
  document.getElementById('report').replaceChildren();
  markers.forEach(marker => marker.remove());
  markers = [];
  try {
    const entry = document.getElementById('bodySet').value;
    const selectionKind = document.getElementById('selectionKind').value;
    const payload = await request(`/v1/example?case=${entry}&selection=${selectionKind}`);
    availableProfiles = payload.target_profiles;
    availableLocations = entry === 'earth' && selectionKind === 'site' ? payload.sites.map(site => ({
      id: `earth-area-${site.id}`, body: 'Earth', coordinate_system: 'WGS84_lonlat',
      bbox: [site.longitude-.05, site.latitude-.05, site.longitude+.05, site.latitude+.05]
    })) : payload.mission.scope.locations;
    document.getElementById('comparePanel').hidden = entry !== 'earth';
    document.querySelectorAll('#comparePanel input').forEach(input => {input.checked = false;});
    document.getElementById('comparisonHint').textContent = entry === 'earth'
      ? 'Choose Moon, Mars, or both. Each comparison uses disclosed planetary reference locations.'
      : 'This planetary site automatically compares with Earth analog candidates from the demonstration catalog.';
    configElement.value = JSON.stringify(payload, null, 2);
    const host = document.getElementById('locations');
    host.replaceChildren();
    for (const location of availableLocations) {
      const label = document.createElement('label');
      const input = document.createElement('input');
      input.type = 'radio'; input.name = 'selected-site'; input.value = location.id;
      input.addEventListener('change', () => {
        updateReady(); document.getElementById('alternative').disabled = true;
        statusElement.textContent = 'Selection updated. Request a run when ready.';
      });
      label.append(input, document.createTextNode(`${location.id} · ${location.body} · bounded example ${location.kind || "site"}`));
      host.append(label);
    }
    statusElement.textContent = 'Choose a site or zone, then request analysis. Startup creates no analysis jobs.';
    document.getElementById('mapStatus').textContent = 'Earth analog candidates appear here. Planetary targets retain separate coordinates in the evidence report.';
  } catch (error) { statusElement.textContent = error.message; }
}

document.querySelectorAll('#comparePanel input').forEach(input => input.addEventListener('change', () => {
  updateReady(); document.getElementById('alternative').disabled = true;
}));
document.getElementById('bodySet').addEventListener('change', loadLocations);
document.getElementById('selectionKind').addEventListener('change', loadLocations);
loadLocations();
