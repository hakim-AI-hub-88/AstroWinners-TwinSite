"""Quota-scope routing policy example. This module performs no model requests."""

from dataclasses import dataclass
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime


@dataclass
class Route:
    alias: str
    quota_group: str
    model: str
    capabilities: frozenset
    disabled: bool = False


def retry_delay(value, now=None):
    if value is None:
        return 30.0
    try:
        return max(0.0, float(value))
    except (TypeError, ValueError):
        try:
            timestamp = parsedate_to_datetime(value)
            if timestamp.tzinfo is None:
                timestamp = timestamp.replace(tzinfo=timezone.utc)
            return max(0.0, (timestamp - (now or datetime.now(timezone.utc))).total_seconds())
        except (TypeError, ValueError, OverflowError):
            return 30.0


class Router:
    def __init__(self, routes):
        self.routes = routes
        self.cooldowns = {}

    def select(self, required, now):
        for route in self.routes:
            if not route.disabled and required <= route.capabilities and self.cooldowns.get(route.quota_group, 0) <= now:
                return route
        return None

    def record_failure(self, route, status, now, retry_after=None):
        if status in {401, 403, 404}:
            route.disabled = True
            return "disable_route_and_alert"
        if status == 429:
            self.cooldowns[route.quota_group] = now + retry_delay(retry_after)
            return "cooldown_quota_group"
        if status >= 500 or status in {408, 0}:
            return "bounded_retry_then_capability_checked_fallback"
        return "caller_error"
