"""Safe deterministic report rendering."""

import html
import json


def render_report(result):
    def escape(value):
        return html.escape(str(value))
    rows = []
    for site in result["sites"]:
        rows.append("<tr>" + "".join(f"<td>{escape(value)}</td>" for value in
                    (site["name"] + " (" + site["body"] + ")", round(site["lower_utility"], 3), round(site["coverage"], 3),
                     site["eligible"], ", ".join(site["failures"]))) + "</tr>")
    portfolios = ""
    for title, rows_ in (("Standalone candidates", result["standalone_portfolios"]), ("Combined portfolios", result["combined_portfolios"])):
        if not rows_:
            continue
        items = "".join(f"<li>{escape(', '.join(item['site_ids']))} — utility {item['test_coverage_utility']:.3f}, "
                        f"scenario cost {escape(item['cost'])}, status {escape(item['operational_status'])}</li>" for item in rows_[:3])
        portfolios += f"<h3>{title}</h3><ol>{items}</ol>"
    limits = "".join(f"<li>{escape(item)}</li>" for item in result["limitations"])
    return f"""<!doctype html><html lang="en"><meta charset="utf-8"><title>ARES mission result</title>
<style>body{{font:16px system-ui;max-width:1050px;margin:40px auto;padding:20px;color:#18304a}}td,th{{padding:10px;border-bottom:1px solid #ccd4dd;text-align:left}}pre{{white-space:pre-wrap;overflow-wrap:anywhere}}.notice{{background:#fff1cd;padding:16px}}</style>
<h1>ARES mission result</h1><p class="notice">Data status · {escape(result['data_status'])}. Synthetic inputs are demonstration measurements.</p>
<p>Mission {escape(result['mission_id'])} · Result {escape(result['status'])}</p><p>Snapshot {escape(result['input_sha256'])}</p>
<p>Selected locations · {escape(', '.join(item['id'] + ' (' + item['body'] + ')' for item in result['scope']['locations']))}</p>
<p>Comparisons · {escape("; ".join(" – ".join(pair) for pair in result["comparison_pairs"]))}</p>
<p>Outside-scope records excluded · {escape(', '.join(result['excluded_outside_scope']) or 'None')}</p>
<h2>Site evidence</h2><table><tr><th>Site</th><th>Lower utility</th><th>Coverage</th><th>Eligible</th><th>Findings</th></tr>{''.join(rows)}</table>
<h2>Portfolio alternatives · {escape(result["portfolio_mode"])}</h2>{portfolios}<h2>Limitations</h2><ul>{limits}</ul>
<details><summary>Complete evidence and calculations</summary><pre>{escape(json.dumps(result,indent=2))}</pre></details></html>"""
