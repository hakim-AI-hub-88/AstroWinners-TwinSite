"""ARES reference implementation for bounded, reproducible mission scoring."""

VERSION = "0.4.0"
