"""Small fixed-host NASA POWER connector with immutable raw response capture."""

import hashlib
import json
import math
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path


def fetch_power(longitude, latitude, start, end, output):
    if not math.isfinite(longitude) or not math.isfinite(latitude) or not -180 <= longitude <= 180 or not -90 <= latitude <= 90:
        raise ValueError("invalid Earth coordinates")
    first = datetime.strptime(start, "%Y%m%d")
    last = datetime.strptime(end, "%Y%m%d")
    if not 0 <= (last - first).days <= 366:
        raise ValueError("sample connector requires an ordered interval of at most 367 days")
    parameters = {"parameters": "T2M,PRECTOTCORR", "community": "AG", "longitude": longitude,
                  "latitude": latitude, "start": start, "end": end, "format": "JSON", "time-standard": "UTC"}
    url = "https://power.larc.nasa.gov/api/temporal/daily/point?" + urllib.parse.urlencode(parameters)
    request = urllib.request.Request(url, headers={"User-Agent": "ARES-reference/0.1"})
    with urllib.request.urlopen(request, timeout=45) as response:
        raw = response.read(5_000_001)
        if len(raw) > 5_000_000:
            raise ValueError("response exceeds connector byte budget")
    data = json.loads(raw)
    series = data["properties"]["parameter"]
    if not {"T2M", "PRECTOTCORR"} <= set(series):
        raise ValueError("unexpected POWER response schema")
    digest = hashlib.sha256(raw).hexdigest()
    folder = Path(output)
    folder.mkdir(parents=True, exist_ok=True)
    target = folder / (digest + ".json")
    if not target.exists():
        with target.open("xb") as stream:
            stream.write(raw)
    manifest = {"schema_version": "1.0", "source": "NASA POWER", "url": url, "sha256": digest,
                "retrieved_at": datetime.now(timezone.utc).isoformat(), "raw_file": target.name,
                "parameters": data.get("parameters"), "header": data.get("header"),
                "purpose": "Earth environmental context; requires feature interpretation before scoring"}
    (folder / (digest + ".manifest.json")).write_text(json.dumps(manifest, indent=2))
    return manifest
