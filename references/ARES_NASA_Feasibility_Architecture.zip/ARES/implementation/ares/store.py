"""SQLite job store with atomic claims, idempotency and fenced completion."""

import json
import sqlite3
import time
import uuid
from contextlib import contextmanager

from .engine import canonical_hash


class Conflict(ValueError):
    pass


class CapacityError(ValueError):
    pass


class Store:
    def __init__(self, path):
        self.path = str(path)
        with self.connection() as db:
            db.executescript("""
                CREATE TABLE IF NOT EXISTS jobs (
                    id TEXT PRIMARY KEY, idem TEXT UNIQUE NOT NULL, input_hash TEXT NOT NULL,
                    payload TEXT NOT NULL, state TEXT NOT NULL, attempt INTEGER NOT NULL DEFAULT 0,
                    lease REAL, token TEXT, result TEXT, error TEXT, created REAL NOT NULL
                );
                CREATE TABLE IF NOT EXISTS events (
                    sequence INTEGER PRIMARY KEY AUTOINCREMENT, mission_id TEXT NOT NULL,
                    at REAL NOT NULL, phase TEXT NOT NULL, completed INTEGER NOT NULL,
                    summary TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS events_mission ON events(mission_id, sequence);
            """)

    @contextmanager
    def connection(self):
        db = sqlite3.connect(self.path, timeout=10)
        db.row_factory = sqlite3.Row
        try:
            with db:
                yield db
        finally:
            db.close()

    @staticmethod
    def event(db, mission_id, phase, completed, summary):
        db.execute("INSERT INTO events(mission_id,at,phase,completed,summary) VALUES(?,?,?,?,?)",
                   (mission_id, time.time(), phase, completed, summary))

    def submit(self, payload, idempotency_key):
        digest = canonical_hash(payload)
        with self.connection() as db:
            db.execute("BEGIN IMMEDIATE")
            old = db.execute("SELECT id,input_hash FROM jobs WHERE idem=?", (idempotency_key,)).fetchone()
            if old:
                if old["input_hash"] != digest:
                    raise Conflict("idempotency key already belongs to a different request")
                return old["id"]
            count = db.execute("SELECT count(*) FROM jobs WHERE state IN ('queued','running')").fetchone()[0]
            if count >= 20:
                raise CapacityError("local queue is full")
            mission_id = str(uuid.uuid4())
            db.execute("INSERT INTO jobs(id,idem,input_hash,payload,state,created) VALUES(?,?,?,?,?,?)",
                       (mission_id, idempotency_key, digest, json.dumps(payload, allow_nan=False), "queued", time.time()))
            self.event(db, mission_id, "P00_REGISTER", 0, "Mission queued")
            return mission_id

    def claim(self, lease_seconds=60):
        now = time.time()
        with self.connection() as db:
            db.execute("BEGIN IMMEDIATE")
            exhausted = db.execute("SELECT id FROM jobs WHERE state='running' AND lease<? AND attempt>=3", (now,)).fetchall()
            for row in exhausted:
                db.execute("UPDATE jobs SET state='failed',error='attempt budget exhausted' WHERE id=?", (row["id"],))
                self.event(db, row["id"], "FAILED", 0, "Expired attempt budget exhausted")
            row = db.execute("""SELECT * FROM jobs WHERE state='queued' OR
                (state='running' AND lease<? AND attempt<3) ORDER BY created LIMIT 1""", (now,)).fetchone()
            if row is None:
                return None
            token = str(uuid.uuid4())
            db.execute("UPDATE jobs SET state='running',attempt=attempt+1,lease=?,token=? WHERE id=?",
                       (now + lease_seconds, token, row["id"]))
            self.event(db, row["id"], "STARTED", 0, f"Attempt {row['attempt'] + 1} claimed")
            return {"id": row["id"], "token": token, "payload": json.loads(row["payload"])}

    def progress(self, job, phase, completed):
        with self.connection() as db:
            db.execute("BEGIN IMMEDIATE")
            updated = db.execute("UPDATE jobs SET lease=? WHERE id=? AND token=? AND state='running' AND lease>?",
                                 (time.time() + 60, job["id"], job["token"], time.time())).rowcount
            if updated != 1:
                raise Conflict("worker lease expired or superseded")
            self.event(db, job["id"], phase, completed, "Phase transition")

    def finish(self, job, result=None, error=None):
        with self.connection() as db:
            db.execute("BEGIN IMMEDIATE")
            state = "failed" if error else "succeeded"
            updated = db.execute("""UPDATE jobs SET state=?,result=?,error=?,lease=NULL WHERE id=?
                AND token=? AND state='running' AND lease>?""",
                                 (state, json.dumps(result, allow_nan=False) if result is not None else None,
                                  error, job["id"], job["token"], time.time())).rowcount
            if updated != 1:
                raise Conflict("worker cannot publish after losing its lease")
            self.event(db, job["id"], state.upper(), 5 if result is not None else 0,
                       "Result committed" if result is not None else "Mission failed")

    def get(self, mission_id):
        with self.connection() as db:
            row = db.execute("SELECT id,state,attempt,input_hash,error,result FROM jobs WHERE id=?", (mission_id,)).fetchone()
            if row is None:
                return None
            result = dict(row)
            result["result"] = json.loads(result["result"]) if result["result"] else None
            return result

    def events(self, mission_id, after=0):
        with self.connection() as db:
            return [dict(row) for row in db.execute("SELECT * FROM events WHERE mission_id=? AND sequence>? ORDER BY sequence LIMIT 200",
                                                    (mission_id, after))]
