import argparse
import csv
import json
import time
from pathlib import Path

from .engine import analyze, clean
from .power import fetch_power
from .report import render_report
from .server import serve
from .store import Conflict, Store


def work_once(store):
    job = store.claim()
    if job is None:
        return False
    try:
        result = analyze(job["payload"], lambda phase, complete: store.progress(job, phase, complete))
        store.finish(job, result=result)
    except Conflict:
        # A superseded attempt cannot commit or overwrite the current attempt.
        return True
    except Exception as error:
        try:
            store.finish(job, error=f"{type(error).__name__}: {error}")
        except Conflict:
            pass
    return True


def import_csv(template, csv_path):
    payload = json.loads(Path(template).read_text())
    sites = []
    with Path(csv_path).open(newline="") as stream:
        for row in csv.DictReader(stream):
            observations = {}
            for name, spec in payload["mission"]["features"].items():
                observations[name] = {"value": float(row[name]) if row.get(name) else None,
                                      "unit": spec["unit"], "source_id": row["source_id"]}
            sites.append({"id": row["id"], "name": row["name"], "longitude": float(row["longitude"]),
                          "body": row["body"], "coordinate_system": row["coordinate_system"],
                          "latitude": float(row["latitude"]), "access": row["access"],
                          "cost": float(row["cost"]) if row["cost"] else None,
                          "days": float(row["days"]) if row["days"] else None,
                          "observations": observations})
    payload["sites"] = sites
    clean(payload)
    return payload


def main():
    parser = argparse.ArgumentParser(description="ARES reference implementation")
    sub = parser.add_subparsers(dest="command", required=True)
    run = sub.add_parser("run")
    run.add_argument("input")
    run.add_argument("--output", default="run-output")
    api = sub.add_parser("serve")
    api.add_argument("--db", default="ares.sqlite")
    api.add_argument("--port", type=int, default=8080)
    worker = sub.add_parser("worker")
    worker.add_argument("--db", default="ares.sqlite")
    worker.add_argument("--once", action="store_true")
    power = sub.add_parser("power")
    power.add_argument("--longitude", type=float, required=True)
    power.add_argument("--latitude", type=float, required=True)
    power.add_argument("--start", required=True)
    power.add_argument("--end", required=True)
    power.add_argument("--output", default="raw-power")
    importer = sub.add_parser("import-csv")
    importer.add_argument("template")
    importer.add_argument("csv")
    importer.add_argument("output")
    args = parser.parse_args()
    if args.command == "run":
        result = analyze(json.loads(Path(args.input).read_text()))
        folder = Path(args.output)
        folder.mkdir(parents=True, exist_ok=True)
        (folder / "result.json").write_text(json.dumps(result, indent=2, allow_nan=False))
        (folder / "report.html").write_text(render_report(result))
        print(result["status"])
    elif args.command == "serve":
        serve(args.db, args.port)
    elif args.command == "worker":
        store = Store(args.db)
        while True:
            claimed = work_once(store)
            if args.once:
                break
            if not claimed:
                time.sleep(1)
    elif args.command == "power":
        print(json.dumps(fetch_power(args.longitude, args.latitude, args.start, args.end, args.output), indent=2))
    elif args.command == "import-csv":
        Path(args.output).write_text(json.dumps(import_csv(args.template, args.csv), indent=2))


if __name__ == "__main__":
    main()
