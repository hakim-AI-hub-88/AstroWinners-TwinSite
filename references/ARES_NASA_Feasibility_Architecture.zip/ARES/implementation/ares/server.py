"""Loopback-only reference HTTP API. Production authentication is a separate integration."""

import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

from .engine import clean
from .report import render_report
from .store import CapacityError, Conflict, Store

ROOT = Path(__file__).resolve().parents[1]


def serve(db_path, port=8080):
    store = Store(db_path)

    class Handler(BaseHTTPRequestHandler):
        def send(self, status, value, media="application/json"):
            body = json.dumps(value, allow_nan=False).encode() if media == "application/json" else value.encode()
            self.send_response(status)
            self.send_header("Content-Type", media + "; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            route = urlsplit(self.path)
            files = {"/": ("index.html", "text/html"), "/app.js": ("app.js", "text/javascript")}
            if route.path in files:
                name, media = files[route.path]
                return self.send(200, (ROOT / "web" / name).read_text(), media)
            if route.path == "/v1/example":
                case = parse_qs(route.query).get("case", ["mars"])[0]
                if case not in {"earth", "moon", "mars"}:
                    return self.send(400, {"error": "choose Earth, Moon or Mars as the entry body"})
                selection = parse_qs(route.query).get("selection", ["site"])[0]
                if selection not in {"site", "zone"}:
                    return self.send(400, {"error": "selection must be site or zone"})
                filename = "zone_mission.json" if selection == "zone" else {"mars": "mission.json", "moon": "moon_mission.json", "earth": "three_body_mission.json"}[case]
                payload = json.loads((ROOT / "examples" / filename).read_text())
                if selection == "zone":
                    body = case.capitalize()
                    payload["mission"]["scope"]["locations"] = [item for item in payload["mission"]["scope"]["locations"] if item["body"] == body]
                    if body != "Earth":
                        payload["target_profiles"] = [p for p in payload["target_profiles"] if p["body"] == body]
                    payload["mission"]["scope"]["compare_with"] = [] if body == "Earth" else ["Earth"]
                elif case == "earth":
                    payload["mission"]["scope"] = {"locations": [], "compare_with": []}
                return self.send(200, payload)
            if route.path == "/v1/health":
                return self.send(200, {"status": "ready", "mode": "local_reference"})
            pieces = route.path.strip("/").split("/")
            if len(pieces) >= 3 and pieces[:2] == ["v1", "missions"]:
                job = store.get(pieces[2])
                if job is None:
                    return self.send(404, {"error": "unknown mission"})
                if len(pieces) == 3:
                    return self.send(200, {key: value for key, value in job.items() if key != "result"})
                if len(pieces) == 4 and pieces[3] == "events":
                    try:
                        after = int(parse_qs(route.query).get("after", ["0"])[0])
                    except ValueError:
                        return self.send(400, {"error": "after must be an integer"})
                    return self.send(200, store.events(job["id"], after))
                if len(pieces) == 4 and pieces[3] in {"result", "report"}:
                    if job["result"] is None:
                        return self.send(409, {"error": "result unavailable", "state": job["state"]})
                    if pieces[3] == "report":
                        return self.send(200, render_report(job["result"]), "text/html")
                    return self.send(200, job["result"])
            self.send(404, {"error": "unknown endpoint"})

        def do_POST(self):
            if self.path != "/v1/missions":
                return self.send(404, {"error": "unknown endpoint"})
            expected_hosts = {f"127.0.0.1:{port}", f"localhost:{port}"}
            if self.headers.get("Host") not in expected_hosts:
                return self.send(403, {"error": "local host required"})
            origin = self.headers.get("Origin")
            if origin and origin not in {"http://" + host for host in expected_hosts}:
                return self.send(403, {"error": "same origin required"})
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if length <= 0 or length > 1_000_000:
                    return self.send(413, {"error": "request must contain 1 to 1000000 bytes"})
                if self.headers.get("Content-Type", "").split(";")[0] != "application/json":
                    return self.send(415, {"error": "application/json required"})
                payload = json.loads(self.rfile.read(length))
                clean(payload)
                key = self.headers.get("Idempotency-Key")
                if not key or len(key) > 128:
                    return self.send(400, {"error": "Idempotency-Key of 1 to 128 characters required"})
                mission_id = store.submit(payload, key)
                self.send(202, {"id": mission_id, "status_url": f"/v1/missions/{mission_id}"})
            except Conflict as error:
                self.send(409, {"error": str(error)})
            except CapacityError as error:
                self.send(429, {"error": str(error)})
            except (ValueError, KeyError, TypeError, AttributeError) as error:
                self.send(422, {"error": str(error)})

    print(f"ARES local reference at http://127.0.0.1:{port}", flush=True)
    ThreadingHTTPServer(("127.0.0.1", port), Handler).serve_forever()
